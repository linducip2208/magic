-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.4.9 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.8.0.6908
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping structure for table magicai.account_deletion_reqs
CREATE TABLE IF NOT EXISTS `account_deletion_reqs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `account_deletion_reqs_user_id_foreign` (`user_id`),
  CONSTRAINT `account_deletion_reqs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.account_deletion_reqs: ~0 rows (approximately)

-- Dumping structure for table magicai.activity
CREATE TABLE IF NOT EXISTS `activity` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `url` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `activity_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activity_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activity_user_id_foreign` (`user_id`),
  CONSTRAINT `activity_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.activity: ~0 rows (approximately)

-- Dumping structure for table magicai.ads
CREATE TABLE IF NOT EXISTS `ads` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.ads: ~0 rows (approximately)
INSERT INTO `ads` (`id`, `type`, `code`, `status`, `created_at`, `updated_at`) VALUES
	(1, 'landing-header-section', '', 0, '2023-08-30 06:10:37', '2023-08-30 06:10:37'),
	(2, 'landing-features-section-728x90', '', 0, '2023-08-30 06:10:37', '2023-08-30 06:10:37'),
	(3, 'landing-templates-section-728x90', '', 0, '2023-08-30 06:10:37', '2023-08-30 06:10:37'),
	(4, 'landing-tools-section-728x90', '', 0, '2023-08-30 06:10:37', '2023-08-30 06:10:37'),
	(5, 'landing-how-it-works-section-728x90', '', 0, '2023-08-30 06:10:37', '2023-08-30 06:10:37'),
	(6, 'landing-testimonials-section-728x90', '', 0, '2023-08-30 06:10:37', '2023-08-30 06:10:37'),
	(7, 'landing-pricing-section-728x90', '', 0, '2023-08-30 06:10:37', '2023-08-30 06:10:37'),
	(8, 'landing-faq-section-728x90', '', 0, '2023-08-30 06:10:37', '2023-08-30 06:10:37'),
	(9, 'chat-pro-top-header-section-728x90', '', 0, '2026-07-24 11:21:25', '2026-07-24 11:21:25');

-- Dumping structure for table magicai.advanced_features_section
CREATE TABLE IF NOT EXISTS `advanced_features_section` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.advanced_features_section: ~0 rows (approximately)
INSERT INTO `advanced_features_section` (`id`, `title`, `description`, `image`, `created_at`, `updated_at`) VALUES
	(1, 'Article Wizard', 'Create a social media post and schedule it to be published directly on Linkedin or X.', '/themes/default/assets/landing-page/advanced-feature-1.png', NULL, NULL),
	(2, 'Intelligent AI Assistant', 'Create a social media post and schedule it to be published directly on Linkedin or X.', '/themes/default/assets/landing-page/advanced-feature-1.png', NULL, NULL),
	(3, 'Publish on Social Media', 'Create a social media post and schedule it to be published directly on Linkedin or X.', '/themes/default/assets/landing-page/advanced-feature-1.png', NULL, NULL),
	(4, 'SEO Tool', 'Create a social media post and schedule it to be published directly on Linkedin or X.', '/themes/default/assets/landing-page/advanced-feature-1.png', NULL, NULL),
	(5, 'Real-Time Data', 'Create a social media post and schedule it to be published directly on Linkedin or X.', '/themes/default/assets/landing-page/advanced-feature-1.png', NULL, NULL),
	(6, 'AI Photo Editor', 'Create a social media post and schedule it to be published directly on Linkedin or X.', '/themes/default/assets/landing-page/advanced-feature-1.png', NULL, NULL);

-- Dumping structure for table magicai.advertis
CREATE TABLE IF NOT EXISTS `advertis` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tracking_code` longtext COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.advertis: ~0 rows (approximately)

-- Dumping structure for table magicai.ai_chat_model_plans
CREATE TABLE IF NOT EXISTS `ai_chat_model_plans` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `plan_id` int NOT NULL,
  `entity_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ai_chat_model_plans_entity_id_foreign` (`entity_id`),
  CONSTRAINT `ai_chat_model_plans_entity_id_foreign` FOREIGN KEY (`entity_id`) REFERENCES `entities` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.ai_chat_model_plans: ~0 rows (approximately)

-- Dumping structure for table magicai.ai_realtime_images
CREATE TABLE IF NOT EXISTS `ai_realtime_images` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `prompt` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `style` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'public',
  `payload` json DEFAULT NULL,
  `response` json DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.ai_realtime_images: ~0 rows (approximately)

-- Dumping structure for table magicai.announcements
CREATE TABLE IF NOT EXISTS `announcements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL,
  `type` enum('new','maintenance','update','info') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.announcements: ~0 rows (approximately)

-- Dumping structure for table magicai.app_settings
CREATE TABLE IF NOT EXISTS `app_settings` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `app_settings_key_index` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.app_settings: ~0 rows (approximately)
INSERT INTO `app_settings` (`id`, `key`, `value`) VALUES
	(1, 'frontend_additional_url_type', 'default'),
	(2, 'front_theme', 'default'),
	(3, 'dash_theme', 'default'),
	(4, 'ai_realtime_image', '1');

-- Dumping structure for table magicai.article_wizard
CREATE TABLE IF NOT EXISTS `article_wizard` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `keywords` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_keywords` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `topic_keywords` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_titles` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `topic_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `language` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image_style` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image_count` int NOT NULL DEFAULT '0',
  `outline` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_outlines` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `topic_outline` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `current_step` int NOT NULL DEFAULT '0',
  `result` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_images` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `topic_image` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `generated_count` int NOT NULL DEFAULT '0',
  `creativity` double(8,2) NOT NULL DEFAULT '0.50',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.article_wizard: ~0 rows (approximately)

-- Dumping structure for table magicai.automations
CREATE TABLE IF NOT EXISTS `automations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `custom` longtext COLLATE utf8mb4_unicode_ci,
  `value` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.automations: ~0 rows (approximately)

-- Dumping structure for table magicai.automation_campaigns
CREATE TABLE IF NOT EXISTS `automation_campaigns` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_audience` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.automation_campaigns: ~0 rows (approximately)

-- Dumping structure for table magicai.automation_platforms
CREATE TABLE IF NOT EXISTS `automation_platforms` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `platform` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `credentials` json DEFAULT NULL,
  `connected_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.automation_platforms: ~0 rows (approximately)

-- Dumping structure for table magicai.bad_words
CREATE TABLE IF NOT EXISTS `bad_words` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `words` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.bad_words: ~0 rows (approximately)

-- Dumping structure for table magicai.banner_bottom_texts
CREATE TABLE IF NOT EXISTS `banner_bottom_texts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `text` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.banner_bottom_texts: ~0 rows (approximately)
INSERT INTO `banner_bottom_texts` (`id`, `text`, `created_at`, `updated_at`) VALUES
	(1, 'No Credit Card Required', NULL, NULL),
	(2, 'Free Trial', NULL, NULL),
	(3, '30 Day Money Back Guarentee', NULL, NULL);

-- Dumping structure for table magicai.blogs
CREATE TABLE IF NOT EXISTS `blogs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `feature_image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seo_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8mb4_unicode_ci,
  `category` text COLLATE utf8mb4_unicode_ci,
  `tag` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `user_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `blogs_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.blogs: ~0 rows (approximately)

-- Dumping structure for table magicai.cache
CREATE TABLE IF NOT EXISTS `cache` (
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.cache: ~0 rows (approximately)

-- Dumping structure for table magicai.cache_locks
CREATE TABLE IF NOT EXISTS `cache_locks` (
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.cache_locks: ~0 rows (approximately)

-- Dumping structure for table magicai.chatbot
CREATE TABLE IF NOT EXISTS `chatbot` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_message` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instructions` text COLLATE utf8mb4_unicode_ci,
  `chatbot_interests` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `width` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `height` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'not-trained',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.chatbot: ~0 rows (approximately)
INSERT INTO `chatbot` (`id`, `user_id`, `title`, `role`, `model`, `first_message`, `instructions`, `chatbot_interests`, `image`, `color`, `width`, `height`, `status`, `created_at`, `updated_at`) VALUES
	(1, 1, 'Default', 'Support', 'gpt-3.5-turbo-16k', 'I am AI Assistant. How can I help you?', 'Your name is John Doe. Remember that you are an assistant who only gives information about wordpress and don\'t give any other information.', NULL, NULL, NULL, NULL, NULL, 'not-trained', NULL, '2026-07-24 10:49:49');

-- Dumping structure for table magicai.chatbot_data
CREATE TABLE IF NOT EXISTS `chatbot_data` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `chatbot_id` bigint DEFAULT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type_value` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `path` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.chatbot_data: ~0 rows (approximately)

-- Dumping structure for table magicai.chatbot_data_vectors
CREATE TABLE IF NOT EXISTS `chatbot_data_vectors` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `chatbot_id` bigint DEFAULT NULL,
  `chatbot_data_id` bigint DEFAULT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `embedding` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.chatbot_data_vectors: ~0 rows (approximately)

-- Dumping structure for table magicai.chatbot_history
CREATE TABLE IF NOT EXISTS `chatbot_history` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `ip` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_openai_chat_id` int DEFAULT NULL,
  `openai_chat_category_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.chatbot_history: ~0 rows (approximately)
INSERT INTO `chatbot_history` (`id`, `user_id`, `ip`, `user_openai_chat_id`, `openai_chat_category_id`, `created_at`, `updated_at`) VALUES
	(1, 1, '127.0.0.1', 1, 1, '2026-07-24 10:56:42', '2026-07-24 10:56:42');

-- Dumping structure for table magicai.chat_category
CREATE TABLE IF NOT EXISTS `chat_category` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.chat_category: ~0 rows (approximately)

-- Dumping structure for table magicai.clients
CREATE TABLE IF NOT EXISTS `clients` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'assets/img/auth/default-avatar.png',
  `alt` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.clients: ~0 rows (approximately)
INSERT INTO `clients` (`id`, `avatar`, `alt`, `title`, `created_at`, `updated_at`) VALUES
	(1, '1c.svg', 'Envato', 'Envato', '2023-06-02 10:09:35', '2023-06-02 10:09:35'),
	(2, '2c.svg', 'Envato', 'Envato', '2023-06-02 10:09:35', '2023-06-02 10:09:35'),
	(3, '4c.svg', 'Envato', 'Envato', '2023-06-02 10:09:35', '2023-06-02 10:09:35'),
	(4, '5c.svg', 'Envato', 'Envato', '2023-06-02 10:09:35', '2023-06-02 10:09:35'),
	(5, '6c.svg', 'Envato', 'Envato', '2023-06-02 10:09:35', '2023-06-02 10:09:35');

-- Dumping structure for table magicai.companies
CREATE TABLE IF NOT EXISTS `companies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `industry` text COLLATE utf8mb4_unicode_ci,
  `description` text COLLATE utf8mb4_unicode_ci,
  `target_audience` text COLLATE utf8mb4_unicode_ci,
  `website` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tagline` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brand_color` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `specific_instructions` text COLLATE utf8mb4_unicode_ci,
  `user_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `tone_of_voice` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `companies_user_id_foreign` (`user_id`),
  CONSTRAINT `companies_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.companies: ~0 rows (approximately)

-- Dumping structure for table magicai.comparison_section_items
CREATE TABLE IF NOT EXISTS `comparison_section_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `label` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `others` tinyint(1) NOT NULL DEFAULT '0',
  `ours` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.comparison_section_items: ~0 rows (approximately)
INSERT INTO `comparison_section_items` (`id`, `label`, `others`, `ours`, `created_at`, `updated_at`) VALUES
	(1, 'Multiple AI Tools', 0, 1, NULL, NULL),
	(2, 'Custom Templates and Chatbot Personas', 0, 1, NULL, NULL),
	(3, 'All-in-one Platform', 0, 1, NULL, NULL),
	(4, 'Knows Your Brand', 0, 1, NULL, NULL),
	(5, 'Intelligent AI Assistant', 0, 1, NULL, NULL),
	(6, 'PrePaid', 0, 1, NULL, NULL),
	(7, 'Lifetime Access', 0, 1, NULL, NULL);

-- Dumping structure for table magicai.coupons
CREATE TABLE IF NOT EXISTS `coupons` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `discount` decimal(5,2) NOT NULL,
  `is_offer` tinyint(1) NOT NULL DEFAULT '0',
  `is_offer_fixed_price` tinyint(1) NOT NULL DEFAULT '0',
  `limit` int DEFAULT NULL,
  `duration` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'once',
  `created_by` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `offer_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `coupons_created_by_foreign` (`created_by`),
  CONSTRAINT `coupons_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.coupons: ~0 rows (approximately)

-- Dumping structure for table magicai.coupon_users
CREATE TABLE IF NOT EXISTS `coupon_users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `coupon_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `coupon_users_coupon_id_foreign` (`coupon_id`),
  KEY `coupon_users_user_id_foreign` (`user_id`),
  CONSTRAINT `coupon_users_coupon_id_foreign` FOREIGN KEY (`coupon_id`) REFERENCES `coupons` (`id`) ON DELETE CASCADE,
  CONSTRAINT `coupon_users_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.coupon_users: ~0 rows (approximately)

-- Dumping structure for table magicai.currencies
CREATE TABLE IF NOT EXISTS `currencies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `symbol` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `thousand_separator` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `decimal_separator` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.currencies: ~0 rows (approximately)
INSERT INTO `currencies` (`id`, `country`, `currency`, `code`, `symbol`, `thousand_separator`, `decimal_separator`) VALUES
	(1, 'Albania', 'Leke', 'ALL', 'Lek', ',', '.'),
	(2, 'America', 'Dollars', 'USD', '$', ',', '.'),
	(3, 'Afghanistan', 'Afghanis', 'AFN', '؋', ',', '.'),
	(4, 'Argentina', 'Pesos', 'ARS', '$', ',', '.'),
	(5, 'Aruba', 'Guilders', 'AWG', 'ƒ', ',', '.'),
	(6, 'Australia', 'Dollars', 'AUD', '$', ',', '.'),
	(7, 'Azerbaijan', 'New Manats', 'AZN', 'ман', ',', '.'),
	(8, 'Bahamas', 'Dollars', 'BSD', '$', ',', '.'),
	(9, 'Barbados', 'Dollars', 'BBD', '$', ',', '.'),
	(10, 'Belarus', 'Rubles', 'BYR', 'p.', ',', '.'),
	(11, 'Belgium', 'Euro', 'EUR', '€', ',', '.'),
	(12, 'Beliz', 'Dollars', 'BZD', 'BZ$', ',', '.'),
	(13, 'Bermuda', 'Dollars', 'BMD', '$', ',', '.'),
	(14, 'Bolivia', 'Bolivianos', 'BOB', '$b', ',', '.'),
	(15, 'Bosnia and Herzegovina', 'Convertible Marka', 'BAM', 'KM', ',', '.'),
	(16, 'Botswana', 'Pula\'s', 'BWP', 'P', ',', '.'),
	(17, 'Bulgaria', 'Leva', 'BGN', 'лв', ',', '.'),
	(18, 'Brazil', 'Reais', 'BRL', 'R$', ',', '.'),
	(19, 'Britain (United Kingdom)', 'Pounds', 'GBP', '£', ',', '.'),
	(20, 'Brunei Darussalam', 'Dollars', 'BND', '$', ',', '.'),
	(21, 'Cambodia', 'Riels', 'KHR', '៛', ',', '.'),
	(22, 'Canada', 'Dollars', 'CAD', '$', ',', '.'),
	(23, 'Cayman Islands', 'Dollars', 'KYD', '$', ',', '.'),
	(24, 'Chile', 'Pesos', 'CLP', '$', ',', '.'),
	(25, 'China', 'Yuan Renminbi', 'CNY', '¥', ',', '.'),
	(26, 'Colombia', 'Pesos', 'COP', '$', ',', '.'),
	(27, 'Costa Rica', 'Colón', 'CRC', '₡', ',', '.'),
	(28, 'Croatia', 'Kuna', 'HRK', 'kn', ',', '.'),
	(29, 'Cuba', 'Pesos', 'CUP', '₱', ',', '.'),
	(30, 'Cyprus', 'Euro', 'EUR', '€', ',', '.'),
	(31, 'Czech Republic', 'Koruny', 'CZK', 'Kč', ',', '.'),
	(32, 'Denmark', 'Kroner', 'DKK', 'kr', ',', '.'),
	(33, 'Dominican Republic', 'Pesos', 'DOP ', 'RD$', ',', '.'),
	(34, 'East Caribbean', 'Dollars', 'XCD', '$', ',', '.'),
	(35, 'Egypt', 'Pounds', 'EGP', '£', ',', '.'),
	(36, 'El Salvador', 'Colones', 'SVC', '$', ',', '.'),
	(37, 'England (United Kingdom)', 'Pounds', 'GBP', '£', ',', '.'),
	(38, 'Euro', 'Euro', 'EUR', '€', ',', '.'),
	(39, 'Falkland Islands', 'Pounds', 'FKP', '£', ',', '.'),
	(40, 'Fiji', 'Dollars', 'FJD', '$', ',', '.'),
	(41, 'France', 'Euro', 'EUR', '€', ',', '.'),
	(42, 'Ghana', 'Cedis', 'GHS', '¢', ',', '.'),
	(43, 'Gibraltar', 'Pounds', 'GIP', '£', ',', '.'),
	(44, 'Greece', 'Euro', 'EUR', '€', ',', '.'),
	(45, 'Guatemala', 'Quetzales', 'GTQ', 'Q', ',', '.'),
	(46, 'Guernsey', 'Pounds', 'GGP', '£', ',', '.'),
	(47, 'Guyana', 'Dollars', 'GYD', '$', ',', '.'),
	(48, 'Holland (Netherlands)', 'Euro', 'EUR', '€', ',', '.'),
	(49, 'Honduras', 'Lempiras', 'HNL', 'L', ',', '.'),
	(50, 'Hong Kong', 'Dollars', 'HKD', '$', ',', '.'),
	(51, 'Hungary', 'Forint', 'HUF', 'Ft', ',', '.'),
	(52, 'Iceland', 'Kronur', 'ISK', 'kr', ',', '.'),
	(53, 'India', 'Rupees', 'INR', '₹', ',', '.'),
	(54, 'Indonesia', 'Rupiahs', 'IDR', 'Rp', ',', '.'),
	(55, 'Iran', 'Rials', 'IRR', '﷼', ',', '.'),
	(56, 'Ireland', 'Euro', 'EUR', '€', ',', '.'),
	(57, 'Isle of Man', 'Pounds', 'IMP', '£', ',', '.'),
	(58, 'Israel', 'New Shekels', 'ILS', '₪', ',', '.'),
	(59, 'Italy', 'Euro', 'EUR', '€', ',', '.'),
	(60, 'Jamaica', 'Dollars', 'JMD', 'J$', ',', '.'),
	(61, 'Japan', 'Yen', 'JPY', '¥', ',', '.'),
	(62, 'Jersey', 'Pounds', 'JEP', '£', ',', '.'),
	(63, 'Kazakhstan', 'Tenge', 'KZT', 'лв', ',', '.'),
	(64, 'Korea (North)', 'Won', 'KPW', '₩', ',', '.'),
	(65, 'Korea (South)', 'Won', 'KRW', '₩', ',', '.'),
	(66, 'Kyrgyzstan', 'Soms', 'KGS', 'лв', ',', '.'),
	(67, 'Laos', 'Kips', 'LAK', '₭', ',', '.'),
	(68, 'Latvia', 'Lati', 'LVL', 'Ls', ',', '.'),
	(69, 'Lebanon', 'Pounds', 'LBP', '£', ',', '.'),
	(70, 'Liberia', 'Dollars', 'LRD', '$', ',', '.'),
	(71, 'Liechtenstein', 'Switzerland Francs', 'CHF', 'CHF', ',', '.'),
	(72, 'Lithuania', 'Litai', 'LTL', 'Lt', ',', '.'),
	(73, 'Luxembourg', 'Euro', 'EUR', '€', ',', '.'),
	(74, 'Macedonia', 'Denars', 'MKD', 'ден', ',', '.'),
	(75, 'Malaysia', 'Ringgits', 'MYR', 'RM', ',', '.'),
	(76, 'Malta', 'Euro', 'EUR', '€', ',', '.'),
	(77, 'Mauritius', 'Rupees', 'MUR', '₨', ',', '.'),
	(78, 'Mexico', 'Pesos', 'MXN', '$', ',', '.'),
	(79, 'Mongolia', 'Tugriks', 'MNT', '₮', ',', '.'),
	(80, 'Mozambique', 'Meticais', 'MZN', 'MT', ',', '.'),
	(81, 'Namibia', 'Dollars', 'NAD', '$', ',', '.'),
	(82, 'Nepal', 'Rupees', 'NPR', '₨', ',', '.'),
	(83, 'Netherlands Antilles', 'Guilders', 'ANG', 'ƒ', ',', '.'),
	(84, 'Netherlands', 'Euro', 'EUR', '€', ',', '.'),
	(85, 'New Zealand', 'Dollars', 'NZD', '$', ',', '.'),
	(86, 'Nicaragua', 'Cordobas', 'NIO', 'C$', ',', '.'),
	(87, 'Nigeria', 'Nairas', 'NGN', '₦', ',', '.'),
	(88, 'North Korea', 'Won', 'KPW', '₩', ',', '.'),
	(89, 'Norway', 'Krone', 'NOK', 'kr', ',', '.'),
	(90, 'Oman', 'Rials', 'OMR', '﷼', ',', '.'),
	(91, 'Pakistan', 'Rupees', 'PKR', '₨', ',', '.'),
	(92, 'Panama', 'Balboa', 'PAB', 'B/.', ',', '.'),
	(93, 'Paraguay', 'Guarani', 'PYG', 'Gs', ',', '.'),
	(94, 'Peru', 'Nuevos Soles', 'PEN', 'S/.', ',', '.'),
	(95, 'Philippines', 'Pesos', 'PHP', 'Php', ',', '.'),
	(96, 'Poland', 'Zlotych', 'PLN', 'zł', ',', '.'),
	(97, 'Qatar', 'Rials', 'QAR', '﷼', ',', '.'),
	(98, 'Romania', 'New Lei', 'RON', 'lei', ',', '.'),
	(99, 'Russia', 'Rubles', 'RUB', 'руб', ',', '.'),
	(100, 'Saint Helena', 'Pounds', 'SHP', '£', ',', '.'),
	(101, 'Saudi Arabia', 'Riyals', 'SAR', '﷼', ',', '.'),
	(102, 'Serbia', 'Dinars', 'RSD', 'Дин.', ',', '.'),
	(103, 'Seychelles', 'Rupees', 'SCR', '₨', ',', '.'),
	(104, 'Singapore', 'Dollars', 'SGD', '$', ',', '.'),
	(105, 'Slovenia', 'Euro', 'EUR', '€', ',', '.'),
	(106, 'Solomon Islands', 'Dollars', 'SBD', '$', ',', '.'),
	(107, 'Somalia', 'Shillings', 'SOS', 'S', ',', '.'),
	(108, 'South Africa', 'Rand', 'ZAR', 'R', ',', '.'),
	(109, 'South Korea', 'Won', 'KRW', '₩', ',', '.'),
	(110, 'Spain', 'Euro', 'EUR', '€', ',', '.'),
	(111, 'Sri Lanka', 'Rupees', 'LKR', '₨', ',', '.'),
	(112, 'Sweden', 'Kronor', 'SEK', 'kr', ',', '.'),
	(113, 'Switzerland', 'Francs', 'CHF', 'CHF', ',', '.'),
	(114, 'Suriname', 'Dollars', 'SRD', '$', ',', '.'),
	(115, 'Syria', 'Pounds', 'SYP', '£', ',', '.'),
	(116, 'Taiwan', 'New Dollars', 'TWD', 'NT$', ',', '.'),
	(117, 'Thailand', 'Baht', 'THB', '฿', ',', '.'),
	(118, 'Trinidad and Tobago', 'Dollars', 'TTD', 'TT$', ',', '.'),
	(119, 'Turkey', 'Lira', 'TRY', 'TL', ',', '.'),
	(120, 'Turkey', 'Liras', 'TRL', '£', ',', '.'),
	(121, 'Tuvalu', 'Dollars', 'TVD', '$', ',', '.'),
	(122, 'Ukraine', 'Hryvnia', 'UAH', '₴', ',', '.'),
	(123, 'United Kingdom', 'Pounds', 'GBP', '£', ',', '.'),
	(124, 'United States of America', 'Dollars', 'USD', '$', ',', '.'),
	(125, 'Uruguay', 'Pesos', 'UYU', '$U', ',', '.'),
	(126, 'Uzbekistan', 'Sums', 'UZS', 'лв', ',', '.'),
	(127, 'Vatican City', 'Euro', 'EUR', '€', ',', '.'),
	(128, 'Venezuela', 'Bolivares Fuertes', 'VEF', 'Bs', ',', '.'),
	(129, 'Vietnam', 'Dong', 'VND', '₫', ',', '.'),
	(130, 'Yemen', 'Rials', 'YER', '﷼', ',', '.'),
	(131, 'Zimbabwe', 'Zimbabwe Dollars', 'ZWD', 'Z$', ',', '.'),
	(132, 'West African CFA franc', 'Francs', 'XOF', 'CFA', ',', '.');

-- Dumping structure for table magicai.customsettings
CREATE TABLE IF NOT EXISTS `customsettings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value_str` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value_text` text COLLATE utf8mb4_unicode_ci,
  `value_longtext` longtext COLLATE utf8mb4_unicode_ci,
  `value_html` text COLLATE utf8mb4_unicode_ci,
  `value_int` int NOT NULL DEFAULT '0',
  `value_bigint` bigint DEFAULT NULL,
  `value_ubigint` bigint unsigned DEFAULT NULL,
  `value_double` double NOT NULL DEFAULT '0',
  `value_bool` tinyint(1) NOT NULL DEFAULT '0',
  `value_date` date DEFAULT NULL,
  `value_timestamp` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.customsettings: ~0 rows (approximately)
INSERT INTO `customsettings` (`id`, `key`, `title`, `value_str`, `value_text`, `value_longtext`, `value_html`, `value_int`, `value_bigint`, `value_ubigint`, `value_double`, `value_bool`, `value_date`, `value_timestamp`, `created_at`, `updated_at`) VALUES
	(1, 'howitworks_bottomline', 'Used in How it Works section bottom line. Controls visibility and HTML value of line.', NULL, NULL, NULL, 'Want to see? <a class="text-[#FCA7FF]" href="https://codecanyon.net/item/magicai-openai-content-text-image-chat-code-generator-as-saas/45408109">Join Magic</a>', 1, NULL, NULL, 0, 0, NULL, NULL, '2026-07-24 09:01:22', '2026-07-24 09:01:22');

-- Dumping structure for table magicai.custom_biling_plans
CREATE TABLE IF NOT EXISTS `custom_biling_plans` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `gateway` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `plan_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `main_plan_price_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_plan_price_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.custom_biling_plans: ~0 rows (approximately)

-- Dumping structure for table magicai.dashboard_widgets
CREATE TABLE IF NOT EXISTS `dashboard_widgets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `order` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.dashboard_widgets: ~0 rows (approximately)
INSERT INTO `dashboard_widgets` (`id`, `name`, `enabled`, `order`, `created_at`, `updated_at`) VALUES
	(1, 'premium-advantages', 1, 0, '2026-07-24 08:58:25', '2026-07-24 08:58:25'),
	(2, 'what-is-new', 1, 1, '2026-07-24 08:58:25', '2026-07-24 08:58:25'),
	(3, 'usage-overview', 1, 2, '2026-07-24 08:58:25', '2026-07-24 08:58:25'),
	(4, 'finance', 1, 3, '2026-07-24 08:58:25', '2026-07-24 08:58:25'),
	(5, 'revenue-source', 1, 4, '2026-07-24 08:58:25', '2026-07-24 08:58:25'),
	(6, 'api-cost-distribution', 1, 5, '2026-07-24 08:58:25', '2026-07-24 08:58:25'),
	(7, 'top-countries', 1, 6, '2026-07-24 08:58:25', '2026-07-24 08:58:25'),
	(8, 'cost-management', 1, 7, '2026-07-24 08:58:25', '2026-07-24 08:58:25'),
	(9, 'new-customers', 1, 8, '2026-07-24 08:58:25', '2026-07-24 08:58:25'),
	(10, 'recent-transactions', 1, 9, '2026-07-24 08:58:25', '2026-07-24 08:58:25'),
	(11, 'users-and-platform', 1, 10, '2026-07-24 08:58:25', '2026-07-24 08:58:25'),
	(12, 'user-traffic', 1, 11, '2026-07-24 08:58:25', '2026-07-24 08:58:25'),
	(13, 'popular-ai-tools', 1, 12, '2026-07-24 08:58:25', '2026-07-24 08:58:25'),
	(14, 'generated-content', 1, 13, '2026-07-24 08:58:25', '2026-07-24 08:58:25'),
	(15, 'users', 1, 14, '2026-07-24 08:58:25', '2026-07-24 08:58:25'),
	(16, 'user-client', 1, 15, '2026-07-24 08:58:25', '2026-07-24 08:58:25'),
	(17, 'recent-activity', 1, 16, '2026-07-24 08:58:25', '2026-07-24 08:58:25'),
	(18, 'system-status', 1, 17, '2026-07-24 08:58:25', '2026-07-24 08:58:25');

-- Dumping structure for table magicai.domains
CREATE TABLE IF NOT EXISTS `domains` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `domain` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `app_key` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chatbot_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `domains_chatbot_id_domain_unique` (`chatbot_id`,`domain`),
  UNIQUE KEY `domains_uuid_unique` (`uuid`),
  KEY `domains_chatbot_id_index` (`chatbot_id`),
  CONSTRAINT `domains_chatbot_id_foreign` FOREIGN KEY (`chatbot_id`) REFERENCES `chatbot` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.domains: ~0 rows (approximately)

-- Dumping structure for table magicai.elevenlab_voices
CREATE TABLE IF NOT EXISTS `elevenlab_voices` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `voice_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `language` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `path` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.elevenlab_voices: ~0 rows (approximately)

-- Dumping structure for table magicai.email_templates
CREATE TABLE IF NOT EXISTS `email_templates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `system` tinyint(1) NOT NULL DEFAULT '1',
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.email_templates: ~0 rows (approximately)
INSERT INTO `email_templates` (`id`, `system`, `title`, `subject`, `content`, `created_at`, `updated_at`, `slug`) VALUES
	(1, 1, 'Successful Subscription', 'Successful Subscription Email', '<div style="padding: 0 19px">\r\n    <h1>Hello, {user_name}!</h1>\r\n    <h2>You have successfully subscribed to {site_name}!</h2>\r\n\r\n    <p>Thank you for subscribing to our {plan_name} plan. Your subscription is now active.</p>\r\n      <p>Thank you for choosing {site_name}.</p>\r\n    <p>Click <a href="{login_url}">here</a> to login to your account.</p>\r\n    <p>Click <a href="{site_url}">here</a> to visit our site.</p>\r\n</div>\r\n\r\n<br>\r\n\r\n<a href="{login_url}" class="btn btn-lg btn-block btn-round">\r\n    Login to Your Account\r\n</a>\r\n\r\n<p class="need-help-p">Need help? <a href="{site_url}">Contact us.</a></p>', NULL, NULL, 'subscription-successful'),
	(2, 1, 'Successful Payment', 'Successful Payment Email', '<div style="padding: 0 19px">\r\n    <h1>Hello, {user_name}!</h1>\r\n    <h2>Your payment was successful!</h2>\r\n\r\n    <p>Thank you for your payment. Your payment has been successfully processed for our {plan_name} plan.</p>\r\n    <ul>\r\n    <p>Thank you for choosing {site_name}.</p>\r\n    <p>Click <a href="{login_url}">here</a> to login to your account.</p>\r\n    <p>Click <a href="{site_url}">here</a> to visit our site.</p>\r\n</div>\r\n\r\n<br>\r\n\r\n<a href="{login_url}" class="btn btn-lg btn-block btn-round">\r\n    Login to Your Account\r\n</a>\r\n\r\n<p class="need-help-p">Need help? <a href="{site_url}">Contact us.</a></p>', NULL, NULL, 'payment-successful');

-- Dumping structure for table magicai.engines
CREATE TABLE IF NOT EXISTS `engines` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'enabled',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_engines_key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.engines: ~0 rows (approximately)
INSERT INTO `engines` (`id`, `key`, `status`, `created_at`, `updated_at`) VALUES
	(1, 'openai', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(2, 'piapi', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(3, 'deep_seek', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(4, 'stable_diffusion', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(5, 'anthropic', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(6, 'gemini', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(7, 'unsplash', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(8, 'pexels', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(9, 'pixabay', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(10, 'elevenlabs', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(11, 'google', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(12, 'azure', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(13, 'speechify', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(14, 'serper', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(15, 'perplexity', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(16, 'clipdrop', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(17, 'novita', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(18, 'freepik', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(19, 'plagiarism_check', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(20, 'synthesia', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(21, 'heygen', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(22, 'pebblely', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(23, 'fal_ai', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(24, 'gamma_ai', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(25, 'x_ai', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(26, 'minimax', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(27, 'open_router', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(28, 'together', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(29, 'creatify', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(30, 'topview', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(31, 'vizard', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(32, 'klap', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(33, 'captions', 'enabled', '2026-07-24 08:58:21', '2026-07-24 08:58:21');

-- Dumping structure for table magicai.entities
CREATE TABLE IF NOT EXISTS `entities` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `engine` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'openai',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `selected_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_selected` tinyint(1) NOT NULL DEFAULT '0',
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'enabled',
  `effort` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=242 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.entities: ~0 rows (approximately)
INSERT INTO `entities` (`id`, `key`, `title`, `image`, `engine`, `created_at`, `updated_at`, `selected_title`, `is_selected`, `status`, `effort`) VALUES
	(1, 'claude-fable-5', 'Claude Fable 5', NULL, 'anthropic', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'Claude Fable 5', 0, 'enabled', NULL),
	(2, 'claude-sonnet-4-5-20250929', 'Claude Sonnet 4.5', NULL, 'anthropic', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'Claude Sonnet 4.5', 0, 'enabled', NULL),
	(3, 'claude-sonnet-4-6', 'Claude Sonnet 4.6', NULL, 'anthropic', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'Claude Sonnet 4.6', 0, 'enabled', NULL),
	(4, 'claude-sonnet-4-20250514', 'Claude Sonnet 4', NULL, 'anthropic', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'Claude Sonnet 4', 0, 'enabled', NULL),
	(5, 'claude-3-7-sonnet-20250219', 'Claude 3.7 Sonnet', NULL, 'anthropic', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'Claude 3.7 Sonnet', 0, 'enabled', NULL),
	(6, 'claude-3-5-sonnet-20241022', 'Claude 3.5 Sonnet V2', NULL, 'anthropic', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'Claude 3.5 Sonnet V2', 0, 'enabled', NULL),
	(7, 'claude-3-5-sonnet-20240620', 'Claude 3.5 Sonnet', NULL, 'anthropic', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'Claude 3.5 Sonnet', 0, 'enabled', NULL),
	(8, 'claude-3-sonnet-20240229', 'Claude 3 Sonnet', NULL, 'anthropic', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'Claude 3 Sonnet', 0, 'enabled', NULL),
	(9, 'claude-opus-4-8', 'Claude Opus 4.8', NULL, 'anthropic', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'Claude Opus 4.8', 0, 'enabled', NULL),
	(10, 'claude-opus-4-7', 'Claude Opus 4.7', NULL, 'anthropic', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'Claude Opus 4.7', 0, 'enabled', NULL),
	(11, 'claude-opus-4-6', 'Claude Opus 4.6', NULL, 'anthropic', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'Claude Opus 4.6', 0, 'enabled', NULL),
	(12, 'claude-opus-4-5-20251101', 'Claude Opus 4.5', NULL, 'anthropic', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'Claude Opus 4.5', 0, 'enabled', NULL),
	(13, 'claude-opus-4-1-20250805', 'Claude Opus 4.1', NULL, 'anthropic', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'Claude Opus 4.1', 0, 'enabled', NULL),
	(14, 'claude-opus-4-20250514', 'Claude Opus 4', NULL, 'anthropic', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'Claude Opus 4', 0, 'enabled', NULL),
	(15, 'claude-3-opus-20240229', 'Claude 3 Opus', NULL, 'anthropic', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'Claude 3 Opus', 0, 'enabled', NULL),
	(16, 'claude-3-haiku-20241022', 'Claude 3.5 Haiku', NULL, 'anthropic', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'Claude 3.5 Haiku', 0, 'enabled', NULL),
	(17, 'claude-3-haiku-20240307', 'Claude 3 Haiku', NULL, 'anthropic', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'Claude 3 Haiku', 0, 'enabled', NULL),
	(18, 'claude-2.1', 'Claude 2.1', NULL, 'anthropic', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'Claude 2.1', 0, 'enabled', NULL),
	(19, 'claude-2.0', 'Claude 2', NULL, 'anthropic', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'Claude 2', 0, 'enabled', NULL),
	(20, 'voyage-2', 'Voyage 2', NULL, 'anthropic', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'Voyage 2', 0, 'enabled', NULL),
	(21, 'voyage-large-2', 'Voyage Large 2', NULL, 'anthropic', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'Voyage Large 2', 0, 'enabled', NULL),
	(22, 'voyage-code-2', 'Voyage Code 2', NULL, 'anthropic', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'Voyage Code 2', 0, 'enabled', NULL),
	(23, 'davinci-002', 'Davinci 002 (Expensive &amp; Capable)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'Davinci 002 (Expensive &amp; Capable)', 0, 'enabled', NULL),
	(24, 'text-davinci-003', 'Davinci 003 (Expensive &amp; Capable)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'Davinci 003 (Expensive &amp; Capable)', 0, 'enabled', NULL),
	(25, 'gpt-3.5-turbo', 'GPT 3.5-turbo (Most Expensive & Fastest & Most Capable)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT 3.5-turbo (Most Expensive & Fastest & Most Capable)', 0, 'enabled', NULL),
	(26, 'gpt-3.5-turbo-0125', 'GTP 3.5-turbo-0125 (Updated Knowleddge cutoff of Sep 2021, 16k)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GTP 3.5-turbo-0125 (Updated Knowleddge cutoff of Sep 2021, 16k)', 0, 'enabled', NULL),
	(27, 'gpt-3.5-turbo-1106', 'GTP 3.5-turbo-1106 (Updated Knowleddge cutoff of Nov 2021, 16k)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GTP 3.5-turbo-1106 (Updated Knowleddge cutoff of Nov 2021, 16k)', 0, 'enabled', NULL),
	(28, 'gpt-4', 'GPT-4 (Most Expensive & Fastest & Most Capable)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT-4 (Most Expensive & Fastest & Most Capable)', 0, 'enabled', NULL),
	(29, 'gpt-4-turbo', 'GPT-4 Turbo (Most Expensive & Fastest & Most Capable)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT-4 Turbo (Most Expensive & Fastest & Most Capable)', 0, 'enabled', NULL),
	(30, 'gpt-4-1106-preview', 'GPT-4-1106 Turbo (Updated Knowleddge cutoff of April 2023, 128k)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT-4-1106 Turbo (Updated Knowleddge cutoff of April 2023, 128k)', 0, 'enabled', NULL),
	(31, 'gpt-4-0125-preview', 'GPT-4-0125 Turbo (Updated Knowleddge cutoff of Dec 2023, 128k)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT-4-0125 Turbo (Updated Knowleddge cutoff of Dec 2023, 128k)', 0, 'enabled', NULL),
	(32, 'gpt-4o', 'GPT-4o Most advanced works for Vision, multimodal flagship model that’s cheaper and faster than GPT-4 Turbo.  (Updated Knowleddge cutoff of Oct 2023, 128k)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT-4o Most advanced works for Vision, multimodal flagship model that’s cheaper and faster than GPT-4 Turbo.  (Updated Knowleddge cutoff of Oct 2023, 128k)', 0, 'enabled', NULL),
	(33, 'gpt-4o-mini', 'GPT-4o mini Our affordable and intelligent small model for fast, lightweight tasks. GPT-4o mini is cheaper and more capable than GPT-3.5 Turbo.', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT-4o mini Our affordable and intelligent small model for fast, lightweight tasks. GPT-4o mini is cheaper and more capable than GPT-3.5 Turbo.', 0, 'enabled', NULL),
	(34, 'gpt-4o-search-preview', 'GPT-4o Search Preview', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT-4o Search Preview', 0, 'enabled', NULL),
	(35, 'gpt-4o-mini-search-preview', 'GPT-4o Mini Search Preview', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT-4o Mini Search Preview', 0, 'enabled', NULL),
	(36, 'o1-preview', 'GPT o1-preview (Updated Knowledge cutoff of Dec 2023, 128k)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT o1-preview (Updated Knowledge cutoff of Dec 2023, 128k)', 0, 'enabled', NULL),
	(37, 'o1-mini', 'GPT o1-mini (Updated Knowledge cutoff of Dec 2023, 128k)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT o1-mini (Updated Knowledge cutoff of Dec 2023, 128k)', 0, 'enabled', NULL),
	(38, 'o1', 'GPT o1 (Updated Knowledge cutoff of Dec 2023, 128k)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT o1 (Updated Knowledge cutoff of Dec 2023, 128k)', 0, 'enabled', NULL),
	(39, 'o3-mini', 'GPT o3-mini (Updated Knowledge cutoff of October 2023, 200k)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT o3-mini (Updated Knowledge cutoff of October 2023, 200k)', 0, 'enabled', NULL),
	(40, 'gpt-4o-realtime-preview-2024-12-17', 'GPT-4o Realtime Preview (Updated Knowledge cutoff of December 2024, 128k)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT-4o Realtime Preview (Updated Knowledge cutoff of December 2024, 128k)', 0, 'enabled', NULL),
	(41, 'gpt-realtime', 'GPT Realtime (GA, 32k)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT Realtime (GA, 32k)', 0, 'enabled', NULL),
	(42, 'gpt-4.1', 'GPT-4.1 (Jun 01, 2024 knowledge cutoff, 32k max output tokens.)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT-4.1 (Jun 01, 2024 knowledge cutoff, 32k max output tokens.)', 0, 'enabled', NULL),
	(43, 'gpt-4.1-mini', 'GPT-4.1 Mini (Jun 01, 2024 knowledge cutoff, 32k max output tokens.)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT-4.1 Mini (Jun 01, 2024 knowledge cutoff, 32k max output tokens.)', 0, 'enabled', NULL),
	(44, 'gpt-4.1-nano', 'GPT-4.1 Nano (Jun 01, 2024 knowledge cutoff, 32k max output tokens.)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT-4.1 Nano (Jun 01, 2024 knowledge cutoff, 32k max output tokens.)', 0, 'enabled', NULL),
	(45, 'o4-mini', 'GPT o4-mini (Jun 01, 2024 knowledge cutoff, 100k max output tokens.)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT o4-mini (Jun 01, 2024 knowledge cutoff, 100k max output tokens.)', 0, 'enabled', NULL),
	(46, 'o3', 'GPT o3 (Jun 01, 2024 knowledge cutoff, 100k max output tokens.)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT o3 (Jun 01, 2024 knowledge cutoff, 100k max output tokens.)', 0, 'enabled', NULL),
	(47, 'gpt-5', 'GPT-5 (Oct 01, 2024 knowledge cutoff, 128k max output tokens.)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT-5 (Oct 01, 2024 knowledge cutoff, 128k max output tokens.)', 0, 'enabled', NULL),
	(48, 'gpt-5-mini', 'GPT-5 Mini (May 31, 2024 knowledge cutoff, 128k max output tokens.)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT-5 Mini (May 31, 2024 knowledge cutoff, 128k max output tokens.)', 0, 'enabled', NULL),
	(49, 'gpt-5-nano', 'GPT-5 Nano (May 31, 2024 knowledge cutoff, 128k max output tokens.)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT-5 Nano (May 31, 2024 knowledge cutoff, 128k max output tokens.)', 0, 'enabled', NULL),
	(50, 'gpt-5-chat-latest', 'GPT-5 Chat (Sep 30, 2024 knowledge cutoff, 128k max output tokens.)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT-5 Chat (Sep 30, 2024 knowledge cutoff, 128k max output tokens.)', 0, 'enabled', NULL),
	(51, 'gpt-5-pro', 'GPT-5 Pro (Sep 30, 2024 knowledge cutoff, 272k max output tokens.)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT-5 Pro (Sep 30, 2024 knowledge cutoff, 272k max output tokens.)', 0, 'enabled', NULL),
	(52, 'gpt-5.1', 'GPT-5.1 (Sep 30, 2024 knowledge cutoff, 128k max output tokens.)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT-5.1 (Sep 30, 2024 knowledge cutoff, 128k max output tokens.)', 0, 'enabled', NULL),
	(53, 'gpt-5.1-chat-latest', 'GPT-5.1 Chat (Sep 30, 2024 knowledge cutoff, 16k max output tokens.)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT-5.1 Chat (Sep 30, 2024 knowledge cutoff, 16k max output tokens.)', 0, 'enabled', NULL),
	(54, 'gpt-5.2', 'GPT-5.2 (Aug 31, 2025 knowledge cutoff, 128k max output tokens.)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT-5.2 (Aug 31, 2025 knowledge cutoff, 128k max output tokens.)', 0, 'enabled', NULL),
	(55, 'gpt-5.2-pro', 'GPT-5.2 Pro (Aug 31, 2025 knowledge cutoff, 128k max output tokens.)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT-5.2 Pro (Aug 31, 2025 knowledge cutoff, 128k max output tokens.)', 0, 'enabled', NULL),
	(56, 'gpt-5.3-chat-latest', 'GPT-5.3 Instant (Aug 31, 2025 knowledge cutoff, 16k max output tokens.)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT-5.3 Instant (Aug 31, 2025 knowledge cutoff, 16k max output tokens.)', 0, 'enabled', NULL),
	(57, 'gpt-5.4', 'GPT-5.4 (Aug 31, 2025 knowledge cutoff, 128k max output tokens, 1.05M context.)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT-5.4 (Aug 31, 2025 knowledge cutoff, 128k max output tokens, 1.05M context.)', 0, 'enabled', NULL),
	(58, 'gpt-5.4-mini', 'GPT-5.4 Mini (Aug 31, 2025 knowledge cutoff, 128k max output tokens, 1.05M context.)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT-5.4 Mini (Aug 31, 2025 knowledge cutoff, 128k max output tokens, 1.05M context.)', 0, 'enabled', NULL),
	(59, 'gpt-5.4-nano', 'GPT-5.4 Nano (Aug 31, 2025 knowledge cutoff, 128k max output tokens, 1.05M context.)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT-5.4 Nano (Aug 31, 2025 knowledge cutoff, 128k max output tokens, 1.05M context.)', 0, 'enabled', NULL),
	(60, 'gpt-5.5', 'GPT-5.5 (Dec 01, 2025 knowledge cutoff, 128k max output tokens, 1.05M context.)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'GPT-5.5 (Dec 01, 2025 knowledge cutoff, 128k max output tokens, 1.05M context.)', 0, 'enabled', NULL),
	(61, 'o3-deep-research', 'o3 Deep Research (Multi-step web research with detailed reports)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'o3 Deep Research (Multi-step web research with detailed reports)', 0, 'enabled', NULL),
	(62, 'o4-mini-deep-research', 'o4-mini Deep Research (Fast multi-step web research with reports)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'o4-mini Deep Research (Fast multi-step web research with reports)', 0, 'enabled', NULL),
	(63, 'sora-2', 'Sora 2 (Flagship video generation with synced audio)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'Sora 2 (Flagship video generation with synced audio)', 0, 'enabled', NULL),
	(64, 'sora-2-pro', 'Sora 2 Pro (Most advanced synced-audio video generation)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'Sora 2 Pro (Most advanced synced-audio video generation)', 0, 'enabled', NULL),
	(65, 'text-embedding-ada-002', 'Text Embedding Ada (Expensive &amp; Capable)', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'Text Embedding Ada (Expensive &amp; Capable)', 0, 'enabled', NULL),
	(66, 'text-embedding-3-small', 'Text Embedding Small', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'Text Embedding Small', 0, 'enabled', NULL),
	(67, 'text-embedding-3-large', 'Text Embedding Large', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'Text Embedding Large', 0, 'enabled', NULL),
	(68, 'image-to-video', 'AI Video', NULL, 'stable_diffusion', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'AI Video', 0, 'enabled', NULL),
	(69, 'stable-diffusion-xl-1024-v1-0', 'Stable Diffusion XL 1.0', NULL, 'stable_diffusion', '2026-07-24 08:58:21', '2026-07-24 08:58:23', 'Stable Diffusion XL 1.0', 0, 'enabled', NULL),
	(70, 'stable-diffusion-v1-6', 'Stable Diffusion 1.6', NULL, 'stable_diffusion', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Stable Diffusion 1.6', 0, 'enabled', NULL),
	(71, 'sd3', 'Stable Diffusion 3', NULL, 'stable_diffusion', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Stable Diffusion 3', 0, 'enabled', NULL),
	(72, 'sd3-turbo', 'Stable Diffusion 3 turbo', NULL, 'stable_diffusion', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Stable Diffusion 3 turbo', 0, 'enabled', NULL),
	(73, 'sd3-medium', 'Stable Diffusion 3 Medium', NULL, 'stable_diffusion', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Stable Diffusion 3 Medium', 0, 'enabled', NULL),
	(74, 'sd3-large', 'Stable Diffusion 3 Large', NULL, 'stable_diffusion', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Stable Diffusion 3 Large', 0, 'enabled', NULL),
	(75, 'sd3-large-turbo', 'Stable Diffusion 3 Large Turbo', NULL, 'stable_diffusion', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Stable Diffusion 3 Large Turbo', 0, 'enabled', NULL),
	(76, 'sd3.5-large', 'Stable Diffusion 3.5 Large', NULL, 'stable_diffusion', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Stable Diffusion 3.5 Large', 0, 'enabled', NULL),
	(77, 'sd3.5-large-turbo', 'Stable Diffusion 3.5 Large Turbo', NULL, 'stable_diffusion', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Stable Diffusion 3.5 Large Turbo', 0, 'enabled', NULL),
	(78, 'sd3.5-medium', 'Stable Diffusion 3.5 Medium', NULL, 'stable_diffusion', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Stable Diffusion 3.5 Medium', 0, 'enabled', NULL),
	(79, 'core', 'Core', NULL, 'stable_diffusion', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Core', 0, 'enabled', NULL),
	(80, 'ultra', 'Ultra', NULL, 'stable_diffusion', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Ultra', 0, 'enabled', NULL),
	(81, 'aws_bedrock', 'AWS Bedrock', NULL, 'stable_diffusion', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'AWS Bedrock', 0, 'enabled', NULL),
	(82, 'gemini-2.5-flash-preview-05-20', 'Gemini 2.5 Flash Preview 05-20 Adaptive thinking, cost efficiency', NULL, 'gemini', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Gemini 2.5 Flash Preview 05-20 Adaptive thinking, cost efficiency', 0, 'enabled', NULL),
	(83, 'gemini-3-pro-preview', 'Gemini 3 Pro Preview The most intelligent model family to date, built on a foundation of state-of-the-art reasoning.', NULL, 'gemini', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Gemini 3 Pro Preview The most intelligent model family to date, built on a foundation of state-of-the-art reasoning.', 0, 'enabled', NULL),
	(84, 'gemini-3.1-pro-preview', 'Gemini 3.1 Pro Preview Refined performance and reliability, thinking, multimodal, function calling, structured outputs.', NULL, 'gemini', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Gemini 3.1 Pro Preview Refined performance and reliability, thinking, multimodal, function calling, structured outputs.', 0, 'enabled', NULL),
	(85, 'gemini-2.5-pro', 'Gemini 2.5 Pro Preview Enhanced thinking and reasoning, multimodal understanding, advanced coding, and more', NULL, 'gemini', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Gemini 2.5 Pro Preview Enhanced thinking and reasoning, multimodal understanding, advanced coding, and more', 0, 'enabled', NULL),
	(86, 'gemini-deep-research', 'Gemini Deep Research (Multi-step web research with detailed reports)', NULL, 'gemini', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Gemini Deep Research (Multi-step web research with detailed reports)', 0, 'enabled', NULL),
	(87, 'gemini-2.0-flash', 'Gemini 2.0 Flash Next generation features, speed, thinking, realtime streaming, and multimodal generation', NULL, 'gemini', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Gemini 2.0 Flash Next generation features, speed, thinking, realtime streaming, and multimodal generation', 0, 'enabled', NULL),
	(88, 'gemini-2.0-flash-lite', 'Gemini 2.0 Flash-Lite Cost efficiency and low latency', NULL, 'gemini', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Gemini 2.0 Flash-Lite Cost efficiency and low latency', 0, 'enabled', NULL),
	(89, 'gemini-1.5-pro', 'Gemini 1.5 Pro Complex reasoning tasks requiring more intelligence', NULL, 'gemini', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Gemini 1.5 Pro Complex reasoning tasks requiring more intelligence', 0, 'enabled', NULL),
	(90, 'gemini-embedding-exp', 'Gemini Embedding Measuring the relatedness of text strings', NULL, 'gemini', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Gemini Embedding Measuring the relatedness of text strings', 0, 'enabled', NULL),
	(91, 'gemini-1.5-flash', 'Gemini 1.5 Flash Fast and versatile performance across a diverse variety of tasks', NULL, 'gemini', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Gemini 1.5 Flash Fast and versatile performance across a diverse variety of tasks', 0, 'enabled', NULL),
	(92, 'gemini-3-flash-preview', 'Gemini 3 Flash Advanced reasoning, coding, and multimodal capabilities with high speed', NULL, 'gemini', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Gemini 3 Flash Advanced reasoning, coding, and multimodal capabilities with high speed', 0, 'enabled', NULL),
	(93, 'gemini-3.1-flash-live-preview', 'Gemini 3.1 Flash Live Preview Low-latency audio-to-audio model for real-time dialogue', NULL, 'gemini', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Gemini 3.1 Flash Live Preview Low-latency audio-to-audio model for real-time dialogue', 0, 'enabled', NULL),
	(94, 'text-embedding-004', 'Gemini Text Embeding 004', NULL, 'gemini', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Gemini Text Embeding 004', 0, 'enabled', NULL),
	(95, 'clipdrop', 'Clipdrop for Photo Studio', NULL, 'clipdrop', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Clipdrop for Photo Studio', 0, 'enabled', NULL),
	(96, 'novita', 'Novita for Photo Studio', NULL, 'novita', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Novita for Photo Studio', 0, 'enabled', NULL),
	(97, 'freepik', 'Novita for Image Editor', NULL, 'freepik', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Novita for Image Editor', 0, 'enabled', NULL),
	(98, 'plagiarismcheck', 'Plagiarism Check', NULL, 'plagiarism_check', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Plagiarism Check', 0, 'enabled', NULL),
	(99, 'synthesia', 'Synthesia', NULL, 'synthesia', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Synthesia', 0, 'enabled', NULL),
	(100, 'heygen', 'Heygen', NULL, 'heygen', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Heygen', 0, 'enabled', NULL),
	(101, 'video-dubbing', 'Video Dubbing', NULL, 'heygen', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Video Dubbing', 0, 'enabled', NULL),
	(102, 'ai-captions', 'AI Captions', NULL, 'captions', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'AI Captions', 0, 'enabled', NULL),
	(103, 'pebblely', 'Pebblely', NULL, 'pebblely', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Pebblely', 0, 'enabled', NULL),
	(104, 'deepseek-chat', 'Deepseek Chat', NULL, 'deep_seek', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Deepseek Chat', 0, 'enabled', NULL),
	(105, 'deepseek-reasoner', 'Deepseek DeepSeek-R1', NULL, 'deep_seek', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Deepseek DeepSeek-R1', 0, 'enabled', NULL),
	(106, 'unsplash', 'Unsplash for AI Article Wizard', NULL, 'unsplash', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Unsplash for AI Article Wizard', 0, 'enabled', NULL),
	(107, 'pexels', 'Pexels for AI Article Wizard', NULL, 'pexels', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Pexels for AI Article Wizard', 0, 'enabled', NULL),
	(108, 'pixabay', 'Pixabay for AI Article Wizard', NULL, 'pixabay', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Pixabay for AI Article Wizard', 0, 'enabled', NULL),
	(109, 'elevenlabs', 'Elevenlabs for TTS', NULL, 'elevenlabs', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Elevenlabs for TTS', 0, 'enabled', NULL),
	(110, 'eleven_v3', 'ElevenLabs v3 for TTS', NULL, 'elevenlabs', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'ElevenLabs v3 for TTS', 0, 'enabled', NULL),
	(111, 'elevenlabs-voice-chatbot', 'Elevenlabs Voice Chatbots', NULL, 'elevenlabs', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Elevenlabs Voice Chatbots', 0, 'enabled', NULL),
	(112, 'isolator', 'Voice Isolator (1 word = 5 used characters of elevenlabs) X 1 token', NULL, 'elevenlabs', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Voice Isolator (1 word = 5 used characters of elevenlabs) X 1 token', 0, 'enabled', NULL),
	(113, 'elevenlabs-ai-music', 'Elevenlabs for AI Music Pro', NULL, 'elevenlabs', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Elevenlabs for AI Music Pro', 0, 'enabled', NULL),
	(114, 'lyria-3-clip', 'Google Lyria 3 Clip for AI Music Pro', NULL, 'gemini', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Google Lyria 3 Clip for AI Music Pro', 0, 'enabled', NULL),
	(115, 'lyria-3-pro', 'Google Lyria 3 Pro for AI Music Pro', NULL, 'gemini', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Google Lyria 3 Pro for AI Music Pro', 0, 'enabled', NULL),
	(116, 'google', 'Google for TTS', NULL, 'google', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Google for TTS', 0, 'enabled', NULL),
	(117, 'azure', 'Azure for TTS', NULL, 'azure', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Azure for TTS', 0, 'enabled', NULL),
	(118, 'azure-openai', 'Azure OpenAI Model', NULL, 'azure', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Azure OpenAI Model', 0, 'enabled', NULL),
	(119, 'speechify', 'Speechify for TTS', NULL, 'speechify', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Speechify for TTS', 0, 'enabled', NULL),
	(120, 'serper', 'Serper for Realtime Data', NULL, 'serper', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Serper for Realtime Data', 0, 'enabled', NULL),
	(121, 'perplexity', 'Perplexity for Realtime Data', NULL, 'perplexity', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Perplexity for Realtime Data', 0, 'enabled', NULL),
	(122, 'whisper-1', 'WHISPER 1 The latest text to speech model, optimized for speed.', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'WHISPER 1 The latest text to speech model, optimized for speed.', 0, 'enabled', NULL),
	(123, 'dall-e-2', 'DALL-E 2 The previous DALL·E model released in Nov 2022.', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'DALL-E 2 The previous DALL·E model released in Nov 2022.', 0, 'enabled', NULL),
	(124, 'dall-e-3', 'DALL-E 3 The latest DALL·E model released in Nov 2023.', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'DALL-E 3 The latest DALL·E model released in Nov 2023.', 0, 'enabled', NULL),
	(125, 'gpt-image-1', 'GPT-IMAGE-1 The latest image model released in Nov 2025.', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'GPT-IMAGE-1 The latest image model released in Nov 2025.', 0, 'enabled', NULL),
	(126, 'gpt-image-1.5', 'GPT-IMAGE-1.5 The latest image model released in Dec 2025.', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'GPT-IMAGE-1.5 The latest image model released in Dec 2025.', 0, 'enabled', NULL),
	(127, 'gpt-image-2', 'GPT-IMAGE-2 The latest image model with flexible resolutions and high-fidelity inputs.', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'GPT-IMAGE-2 The latest image model with flexible resolutions and high-fidelity inputs.', 0, 'enabled', NULL),
	(128, 'tts-1', 'TTS 1 The latest text to speech model, optimized for speed.', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'TTS 1 The latest text to speech model, optimized for speed.', 0, 'enabled', NULL),
	(129, 'tts-1-hd', 'TTS 1 HD The latest text to speech model, optimized for quality.', NULL, 'openai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'TTS 1 HD The latest text to speech model, optimized for quality.', 0, 'enabled', NULL),
	(130, 'grok-2-1212', 'Grok 2 1212', NULL, 'x_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Grok 2 1212', 0, 'enabled', NULL),
	(131, 'grok-2-vision-1212', 'Grok 2 Vision 1212', NULL, 'x_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Grok 2 Vision 1212', 0, 'enabled', NULL),
	(132, 'grok-3', 'Grok 3', NULL, 'x_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Grok 3', 0, 'enabled', NULL),
	(133, 'grok-3-mini', 'Grok 3 Mini', NULL, 'x_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Grok 3 Mini', 0, 'enabled', NULL),
	(134, 'grok-3-fast', 'Grok 3 Fast', NULL, 'x_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Grok 3 Fast', 0, 'enabled', NULL),
	(135, 'grok-3-mini-fast', 'Grok 3 Mini Fast', NULL, 'x_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Grok 3 Mini Fast', 0, 'enabled', NULL),
	(136, 'grok-4-0709', 'Grok 4', NULL, 'x_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Grok 4', 0, 'enabled', NULL),
	(137, 'grok-4-fast-reasoning', 'Grok 4 Fast', NULL, 'x_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Grok 4 Fast', 0, 'enabled', NULL),
	(138, 'grok-4-1-fast-reasoning', 'Grok 4.1 Fast Reasoning', NULL, 'x_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Grok 4.1 Fast Reasoning', 0, 'enabled', NULL),
	(139, 'grok-4-1-fast-non-reasoning', 'Grok 4.1 Fast Non-Reasoning', NULL, 'x_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Grok 4.1 Fast Non-Reasoning', 0, 'enabled', NULL),
	(140, 'gamma-ai', 'Gamma AI', NULL, 'gamma_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Gamma AI', 0, 'enabled', NULL),
	(141, 'veed', 'Veed', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Veed', 0, 'enabled', NULL),
	(142, 'veed/fabric-1.0', 'Veed Fabric 1.0', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Veed Fabric 1.0', 0, 'enabled', NULL),
	(143, 'veo2', 'Veo 2', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Veo 2', 0, 'enabled', NULL),
	(144, 'veo3', 'Veo 3', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Veo 3', 0, 'enabled', NULL),
	(145, 'veo3.1/text-to-video', 'Veo 3.1 Text To Video', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Veo 3.1 Text To Video', 0, 'enabled', NULL),
	(146, 'veo3.1/fast/text-to-video', 'Fast Veo 3.1 Text To Video', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Fast Veo 3.1 Text To Video', 0, 'enabled', NULL),
	(147, 'veo3.1/first-last-frame-to-video', 'Veo 3.1 First Last Frame To Video', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Veo 3.1 First Last Frame To Video', 0, 'enabled', NULL),
	(148, 'veo3.1/fast/first-last-frame-to-video', 'Fast Veo 3.1 First Last Frame To Video', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Fast Veo 3.1 First Last Frame To Video', 0, 'enabled', NULL),
	(149, 'veo3.1/image-to-video', 'Veo 3.1 Image To Video', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Veo 3.1 Image To Video', 0, 'enabled', NULL),
	(150, 'veo3.1/fast/image-to-video', 'Fast Veo 3.1 Image To Video', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Fast Veo 3.1 Image To Video', 0, 'enabled', NULL),
	(151, 'veo3.1/reference-to-video', 'Veo 3.1 Reference To Video', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Veo 3.1 Reference To Video', 0, 'enabled', NULL),
	(152, 'veo3.1/lite', 'Veo 3.1 Lite Text To Video', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Veo 3.1 Lite Text To Video', 0, 'enabled', NULL),
	(153, 'veo3.1/lite/image-to-video', 'Veo 3.1 Lite Image To Video', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Veo 3.1 Lite Image To Video', 0, 'enabled', NULL),
	(154, 'veo3.1/lite/first-last-frame-to-video', 'Veo 3.1 Lite First Last Frame To Video', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Veo 3.1 Lite First Last Frame To Video', 0, 'enabled', NULL),
	(155, 'veo3-fast', 'Fast Veo 3', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Fast Veo 3', 0, 'enabled', NULL),
	(156, 'nano-banana', 'Nano Banana', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Nano Banana', 0, 'enabled', NULL),
	(157, 'nano-banana/edit', 'Nano Banana Edit', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Nano Banana Edit', 0, 'enabled', NULL),
	(158, 'nano-banana-pro', 'Nano Banana Pro', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Nano Banana Pro', 0, 'enabled', NULL),
	(159, 'nano-banana-pro/edit', 'Nano Banana Pro Edit', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Nano Banana Pro Edit', 0, 'enabled', NULL),
	(160, 'nano-banana-2', 'Nano Banana 2', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Nano Banana 2', 0, 'enabled', NULL),
	(161, 'nano-banana-2/edit', 'Nano Banana 2 Edit', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Nano Banana 2 Edit', 0, 'enabled', NULL),
	(162, 'xai/grok-imagine-image', 'Grok Imagine Image', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Grok Imagine Image', 0, 'enabled', NULL),
	(163, 'xai/grok-imagine-image/edit', 'Grok Imagine Image Edit', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Grok Imagine Image Edit', 0, 'enabled', NULL),
	(164, 'xai/grok-imagine-video/text-to-video', 'Grok Imagine Video Text-to-Video', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Grok Imagine Video Text-to-Video', 0, 'enabled', NULL),
	(165, 'xai/grok-imagine-video/image-to-video', 'Grok Imagine Video Image-to-Video', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Grok Imagine Video Image-to-Video', 0, 'enabled', NULL),
	(166, 'seedream/v4/text-to-image', 'SeeDream v4 ', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'SeeDream v4 ', 0, 'enabled', NULL),
	(167, 'seedream/v4/edit', 'SeeDream v4 Edit', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'SeeDream v4 Edit', 0, 'enabled', NULL),
	(168, 'bytedance/seedance-2.0/text-to-video', 'Seedance 2.0 Text-to-Video', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Seedance 2.0 Text-to-Video', 0, 'enabled', NULL),
	(169, 'bytedance/seedance-2.0/image-to-video', 'Seedance 2.0 Image-to-Video', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Seedance 2.0 Image-to-Video', 0, 'enabled', NULL),
	(170, 'bytedance/seedance-2.0/reference-to-video', 'Seedance 2.0 Reference-to-Video', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Seedance 2.0 Reference-to-Video', 0, 'enabled', NULL),
	(171, 'bytedance/seedance-2.0/fast/text-to-video', 'Seedance 2.0 Fast Text-to-Video', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Seedance 2.0 Fast Text-to-Video', 0, 'enabled', NULL),
	(172, 'bytedance/seedance-2.0/fast/image-to-video', 'Seedance 2.0 Fast Image-to-Video', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Seedance 2.0 Fast Image-to-Video', 0, 'enabled', NULL),
	(173, 'bytedance/seedance-2.0/fast/reference-to-video', 'Seedance 2.0 Fast Reference-to-Video', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Seedance 2.0 Fast Reference-to-Video', 0, 'enabled', NULL),
	(174, 'flux-pro', 'Flux Pro', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Flux Pro', 0, 'enabled', NULL),
	(175, 'flux-pro/kontext/max/multi', 'Flux Pro Kontext Max Multi', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Flux Pro Kontext Max Multi', 0, 'enabled', NULL),
	(176, 'flux-pro/kontext/text-to-image', 'Flux Pro Kontext Max Text to Image', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Flux Pro Kontext Max Text to Image', 0, 'enabled', NULL),
	(177, 'flux-pro/kontext', 'Flux Pro Kontext Max', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Flux Pro Kontext Max', 0, 'enabled', NULL),
	(178, 'imagen4', 'Google Imagen 4', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Google Imagen 4', 0, 'enabled', NULL),
	(179, 'ideogram-v2', 'Ideogram V2', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Ideogram V2', 0, 'enabled', NULL),
	(180, 'flux-pro/v1.1', 'Flux Pro 1.1', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Flux Pro 1.1', 0, 'enabled', NULL),
	(181, 'flux-realism', 'Flux Realism', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Flux Realism', 0, 'enabled', NULL),
	(182, 'flux/schnell', 'Flux Schnell', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Flux Schnell', 0, 'enabled', NULL),
	(183, 'flux-2-flex', 'Flux 2 Flex', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Flux 2 Flex', 0, 'enabled', NULL),
	(184, 'flux-2-flex/edit', 'Flux 2 Flex Edit', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Flux 2 Flex Edit', 0, 'enabled', NULL),
	(185, 'kling', 'Kling 1.0', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Kling 1.0', 0, 'enabled', NULL),
	(186, 'klingV21', 'Kling 2.1', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Kling 2.1', 0, 'enabled', NULL),
	(187, 'kling-2.5-turbo/pro/text-to-video', 'Kling 2.5 Turbo Pro Text to Video', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Kling 2.5 Turbo Pro Text to Video', 0, 'enabled', NULL),
	(188, 'kling-2.5-turbo/pro/image-to-video', 'Kling 2.5 Turbo Pro Image to Video', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Kling 2.5 Turbo Pro Image to Video', 0, 'enabled', NULL),
	(189, 'kling-2.5-turbo/standard/image-to-video', 'Kling 2.5 Turbo Standard Image to Video', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Kling 2.5 Turbo Standard Image to Video', 0, 'enabled', NULL),
	(190, 'kling-video/v2.6/pro/text-to-video', 'Kling Video v2.6 Pro Text to Video', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Kling Video v2.6 Pro Text to Video', 0, 'enabled', NULL),
	(191, 'kling-video/v2.6/pro/image-to-video', 'Kling Video v2.6 Pro Image to Video', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Kling Video v2.6 Pro Image to Video', 0, 'enabled', NULL),
	(192, 'kling-video/v2.6/pro/motion-control', 'Kling Video v2.6 Pro Motion Control', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Kling Video v2.6 Pro Motion Control', 0, 'enabled', NULL),
	(193, 'kling-video/v2.6/standard/motion-control', 'Kling Video v2.6 Standard Motion Control', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Kling Video v2.6 Standard Motion Control', 0, 'enabled', NULL),
	(194, 'kling-video/v3/pro/text-to-video', 'Kling Video v3 Pro Text to Video', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Kling Video v3 Pro Text to Video', 0, 'enabled', NULL),
	(195, 'kling-video/v3/pro/image-to-video', 'Kling Video v3 Pro Image to Video', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Kling Video v3 Pro Image to Video', 0, 'enabled', NULL),
	(196, 'kling-video/v3/standard/text-to-video', 'Kling Video v3 Standard Text to Video', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Kling Video v3 Standard Text to Video', 0, 'enabled', NULL),
	(197, 'kling-video/v3/standard/image-to-video', 'Kling Video v3 Standard Image to Video', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Kling Video v3 Standard Image to Video', 0, 'enabled', NULL),
	(198, 'klingImage', 'Kling Image to Video', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Kling Image to Video', 0, 'enabled', NULL),
	(199, 'kling-video', 'Kling Video', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Kling Video', 0, 'enabled', NULL),
	(200, 'luma-dream-machine', 'Luma Dream Machine', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Luma Dream Machine', 0, 'enabled', NULL),
	(201, 'haiper', 'Haiper', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Haiper', 0, 'enabled', NULL),
	(202, 'minimax', 'Minimax', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Minimax', 0, 'enabled', NULL),
	(203, 'music-01', 'Music 01', NULL, 'minimax', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Music 01', 0, 'enabled', NULL),
	(204, 'anthropic/claude-3-5-haiku-20241022', 'Anthropic: Claude 3.5 Haiku (2024-10-22)', NULL, 'open_router', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Anthropic: Claude 3.5 Haiku (2024-10-22)', 0, 'enabled', NULL),
	(205, 'anthropic/claude-3-5-haiku-20241022:beta', 'Anthropic: Claude 3.5 Haiku (2024-10-22) (self-moderated)', NULL, 'open_router', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Anthropic: Claude 3.5 Haiku (2024-10-22) (self-moderated)', 0, 'enabled', NULL),
	(206, 'anthropic/claude-3-5-haiku', 'Anthropic: Claude 3.5 Haiku', NULL, 'open_router', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Anthropic: Claude 3.5 Haiku', 0, 'enabled', NULL),
	(207, 'anthropic/claude-3-5-haiku:beta', 'Anthropic: Claude 3.5 Haiku (self-moderated)', NULL, 'open_router', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Anthropic: Claude 3.5 Haiku (self-moderated)', 0, 'enabled', NULL),
	(208, 'neversleep/llama-3.1-lumimaid-70b', 'Lumimaid v0.2 70B', NULL, 'open_router', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Lumimaid v0.2 70B', 0, 'enabled', NULL),
	(209, 'anthracite-org/magnum-v4-72b', 'Magnum v4 72B', NULL, 'open_router', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Magnum v4 72B', 0, 'enabled', NULL),
	(210, 'x-ai/grok-beta', 'xAI: Grok Beta', NULL, 'open_router', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'xAI: Grok Beta', 0, 'enabled', NULL),
	(211, 'mistralai/ministral-8b', 'Ministral 8B', NULL, 'open_router', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Ministral 8B', 0, 'enabled', NULL),
	(212, 'mistralai/ministral-3b', 'Ministral 3B', NULL, 'open_router', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Ministral 3B', 0, 'enabled', NULL),
	(213, 'qwen/qwen-2.5-7b-instruct', 'Qwen2.5 7B Instruct', NULL, 'open_router', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Qwen2.5 7B Instruct', 0, 'enabled', NULL),
	(214, 'nvidia/llama-3.1-nemotron-70b-instruct', 'NVIDIA: Llama 3.1 Nemotron 70B Instruct', NULL, 'open_router', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'NVIDIA: Llama 3.1 Nemotron 70B Instruct', 0, 'enabled', NULL),
	(215, 'inflection/inflection-3-pi', 'Inflection: Inflection 3 Pi', NULL, 'open_router', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Inflection: Inflection 3 Pi', 0, 'enabled', NULL),
	(216, 'inflection/inflection-3-productivity', 'Inflection: Inflection 3 Productivity', NULL, 'open_router', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Inflection: Inflection 3 Productivity', 0, 'enabled', NULL),
	(217, 'liquid/lfm-40b:free', 'Liquid: LFM 40B MoE (free)', NULL, 'open_router', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Liquid: LFM 40B MoE (free)', 0, 'enabled', NULL),
	(218, 'liquid/lfm-40b', 'Liquid: LFM 40B MoE', NULL, 'open_router', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Liquid: LFM 40B MoE', 0, 'enabled', NULL),
	(219, 'thedrummer/rocinante-12b', 'Rocinante 12B', NULL, 'open_router', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Rocinante 12B', 0, 'enabled', NULL),
	(220, 'eva-unit-01/eva-qwen-2.5-14b', 'EVA Qwen2.5 14B', NULL, 'open_router', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'EVA Qwen2.5 14B', 0, 'enabled', NULL),
	(221, 'anthracite-org/magnum-v2-72b', 'Magnum v2 72B', NULL, 'open_router', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Magnum v2 72B', 0, 'enabled', NULL),
	(222, 'meta-llama/llama-3.2-3b-instruct:free', 'Meta: Llama 3.2 3B Instruct (free)', NULL, 'open_router', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Meta: Llama 3.2 3B Instruct (free)', 0, 'enabled', NULL),
	(223, 'meta-llama/llama-3.2-1b-instruct:free', 'Meta: Llama 3.2 1B Instruct (free)', NULL, 'open_router', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Meta: Llama 3.2 1B Instruct (free)', 0, 'enabled', NULL),
	(224, 'meta-llama/llama-3.2-3b-instruct', 'Meta: Llama 3.2 3B Instruct', NULL, 'open_router', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Meta: Llama 3.2 3B Instruct', 0, 'enabled', NULL),
	(225, 'meta-llama/llama-3.2-1b-instruct', 'Meta: Llama 3.2 1B Instruct', NULL, 'open_router', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Meta: Llama 3.2 1B Instruct', 0, 'enabled', NULL),
	(226, 'perplexity/llama-3.1-sonar-huge-128k-online', 'Perplexity: Llama 3.1 Sonar 405B Online', NULL, 'open_router', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Perplexity: Llama 3.1 Sonar 405B Online', 0, 'enabled', NULL),
	(227, 'perplexity/llama-3.1-sonar-large-128k-online', 'Perplexity: Llama 3.1 Sonar 70B Online', NULL, 'open_router', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Perplexity: Llama 3.1 Sonar 70B Online', 0, 'enabled', NULL),
	(228, 'perplexity/llama-3.1-sonar-large-128k-chat', 'Perplexity: Llama 3.1 Sonar 70B', NULL, 'open_router', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Perplexity: Llama 3.1 Sonar 70B', 0, 'enabled', NULL),
	(229, 'perplexity/llama-3.1-sonar-small-128k-online', 'Perplexity: Llama 3.1 Sonar 8B Online', NULL, 'open_router', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Perplexity: Llama 3.1 Sonar 8B Online', 0, 'enabled', NULL),
	(230, 'perplexity/llama-3.1-sonar-small-128k-chat', 'Perplexity: Llama 3.1 Sonar 8B', NULL, 'open_router', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Perplexity: Llama 3.1 Sonar 8B', 0, 'enabled', NULL),
	(231, 'midjourney', 'Midjourney', NULL, 'piapi', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Midjourney', 0, 'enabled', NULL),
	(232, 'video-upscaler', 'Video Upscaler', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Video Upscaler', 0, 'enabled', NULL),
	(233, 'cogvideox-5b/video-to-video', 'Cogvideox 5B', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Cogvideox 5B', 0, 'enabled', NULL),
	(234, 'animatediff-v2v', 'Animatediff V2V', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Animatediff V2V', 0, 'enabled', NULL),
	(235, 'fast-animatediff/turbo/video-to-video', 'Fast Animatediff Turbo', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Fast Animatediff Turbo', 0, 'enabled', NULL),
	(236, 'veed/video-background-removal', 'Video Background Removal', NULL, 'fal_ai', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Video Background Removal', 0, 'enabled', NULL),
	(237, 'black-forest-labs/FLUX.1-schnell', 'Black Forest Labs Flux 1 Schnell', NULL, 'together', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Black Forest Labs Flux 1 Schnell', 0, 'enabled', NULL),
	(238, 'ad-marketing-video', 'Ad Marketing Video', NULL, 'creatify', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Ad Marketing Video', 0, 'enabled', NULL),
	(239, 'ad-marketing-video-topview', 'Topview Ad Video', NULL, 'topview', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Topview Ad Video', 0, 'enabled', NULL),
	(240, 'ai-clip-vizard', 'Vizard AI Clip', NULL, 'vizard', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Vizard AI Clip', 0, 'enabled', NULL),
	(241, 'ai-clip-klap', 'Klap AI Clip', NULL, 'klap', '2026-07-24 08:58:21', '2026-07-24 08:58:24', 'Klap AI Clip', 0, 'enabled', NULL);

-- Dumping structure for table magicai.exported_videos
CREATE TABLE IF NOT EXISTS `exported_videos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `task_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'in_progress',
  `video_url` text COLLATE utf8mb4_unicode_ci,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `used_ai_tool` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'topview',
  `cover_url` text COLLATE utf8mb4_unicode_ci,
  `video_duration` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `exported_videos_task_id_unique` (`task_id`),
  KEY `exported_videos_user_id_foreign` (`user_id`),
  CONSTRAINT `exported_videos_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.exported_videos: ~0 rows (approximately)

-- Dumping structure for table magicai.extensions
CREATE TABLE IF NOT EXISTS `extensions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `installed` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_theme` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.extensions: ~0 rows (approximately)

-- Dumping structure for table magicai.ext_chatbots
CREATE TABLE IF NOT EXISTS `ext_chatbots` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint NOT NULL,
  `interaction_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'automatic_response',
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bubble_message` text COLLATE utf8mb4_unicode_ci,
  `welcome_message` text COLLATE utf8mb4_unicode_ci,
  `connect_message` text COLLATE utf8mb4_unicode_ci,
  `instructions` text COLLATE utf8mb4_unicode_ci,
  `do_not_go_beyond_instructions` tinyint(1) NOT NULL DEFAULT '0',
  `language` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ai_model` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ai_embedding_model` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `limit_per_minute` bigint NOT NULL DEFAULT '2000',
  `show_pre_defined_questions` tinyint(1) NOT NULL DEFAULT '0',
  `pre_defined_questions` json DEFAULT NULL,
  `logo` longtext COLLATE utf8mb4_unicode_ci COMMENT 'base 64',
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trigger_avatar_size` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trigger_background` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trigger_foreground` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color_mode` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `color` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '#017BE5',
  `show_logo` tinyint(1) NOT NULL DEFAULT '1',
  `show_date_and_time` tinyint(1) NOT NULL DEFAULT '1',
  `show_average_response_time` tinyint(1) NOT NULL DEFAULT '1',
  `position` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'right',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `footer_link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_favorite` tinyint(1) NOT NULL DEFAULT '0',
  `is_demo` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ext_chatbots_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.ext_chatbots: ~0 rows (approximately)

-- Dumping structure for table magicai.ext_chatbot_avatars
CREATE TABLE IF NOT EXISTS `ext_chatbot_avatars` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.ext_chatbot_avatars: ~5 rows (approximately)
INSERT INTO `ext_chatbot_avatars` (`id`, `user_id`, `avatar`, `created_at`) VALUES
	(1, NULL, 'uploads/avatars/C0mYx9BENTWPg6dkBFDWpFyqO2t1GNcXi72cfATu.png', '2026-07-24 18:11:12'),
	(2, NULL, 'uploads/avatars/khK3xsVOfDBjXYu12Hxns3oAEPUEBPfyZvM7Up1g.png', '2026-07-24 18:11:12'),
	(3, NULL, 'uploads/avatars/pRqLHXcCIzfnqlRWbpQStKPoZvZgIBbT0bLnvVZL.png', '2026-07-24 18:11:12'),
	(4, NULL, 'uploads/avatars/iecFN2rqHbg9sGZz27p85ctIeMt8cluZYGI8ifhI.png', '2026-07-24 18:11:12'),
	(5, NULL, 'uploads/avatars/TszNKlgCc996WY5Toa8K2GfpKsYNl99ekL4Al5zk.png', '2026-07-24 18:11:12');

-- Dumping structure for table magicai.ext_chatbot_channels
CREATE TABLE IF NOT EXISTS `ext_chatbot_channels` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `chatbot_id` bigint DEFAULT NULL,
  `channel` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `credentials` json DEFAULT NULL,
  `payload` json DEFAULT NULL,
  `connected_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.ext_chatbot_channels: ~0 rows (approximately)

-- Dumping structure for table magicai.ext_chatbot_channel_webhooks
CREATE TABLE IF NOT EXISTS `ext_chatbot_channel_webhooks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `chatbot_id` bigint DEFAULT NULL,
  `chatbot_channel_id` bigint DEFAULT NULL,
  `payload` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.ext_chatbot_channel_webhooks: ~0 rows (approximately)

-- Dumping structure for table magicai.ext_chatbot_conversations
CREATE TABLE IF NOT EXISTS `ext_chatbot_conversations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `chatbot_channel_id` bigint DEFAULT '0',
  `customer_channel_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `chatbot_channel` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'frame',
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `conversation_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'Anonymous User',
  `chatbot_id` bigint unsigned NOT NULL,
  `session_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connect_agent_at` timestamp NULL DEFAULT NULL,
  `customer_payload` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `last_activity_at` timestamp NULL DEFAULT NULL,
  `is_showed_on_history` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `ext_chatbot_conversations_chatbot_id_foreign` (`chatbot_id`),
  CONSTRAINT `ext_chatbot_conversations_chatbot_id_foreign` FOREIGN KEY (`chatbot_id`) REFERENCES `ext_chatbots` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.ext_chatbot_conversations: ~0 rows (approximately)

-- Dumping structure for table magicai.ext_chatbot_embeddings
CREATE TABLE IF NOT EXISTS `ext_chatbot_embeddings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `chatbot_id` bigint unsigned NOT NULL,
  `engine` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `embedding` json DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'text',
  `trained_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ext_chatbot_embeddings_chatbot_id_foreign` (`chatbot_id`),
  CONSTRAINT `ext_chatbot_embeddings_chatbot_id_foreign` FOREIGN KEY (`chatbot_id`) REFERENCES `ext_chatbots` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.ext_chatbot_embeddings: ~0 rows (approximately)

-- Dumping structure for table magicai.ext_chatbot_histories
CREATE TABLE IF NOT EXISTS `ext_chatbot_histories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `chatbot_id` bigint unsigned NOT NULL,
  `conversation_id` bigint unsigned NOT NULL,
  `user_id` bigint DEFAULT NULL,
  `message_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `message_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'text',
  `content_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'text',
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `media_url` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `ext_chatbot_histories_chatbot_id_foreign` (`chatbot_id`),
  KEY `ext_chatbot_histories_conversation_id_foreign` (`conversation_id`),
  CONSTRAINT `ext_chatbot_histories_chatbot_id_foreign` FOREIGN KEY (`chatbot_id`) REFERENCES `ext_chatbots` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ext_chatbot_histories_conversation_id_foreign` FOREIGN KEY (`conversation_id`) REFERENCES `ext_chatbot_conversations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.ext_chatbot_histories: ~0 rows (approximately)

-- Dumping structure for table magicai.failed_jobs
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.failed_jobs: ~0 rows (approximately)

-- Dumping structure for table magicai.faq
CREATE TABLE IF NOT EXISTS `faq` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `question` text COLLATE utf8mb4_unicode_ci,
  `answer` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.faq: ~0 rows (approximately)
INSERT INTO `faq` (`id`, `question`, `answer`, `image`, `created_at`, `updated_at`) VALUES
	(1, 'How does it generate responses?', 'MagicAI uses the most popular AI models such as GPT, Dall-E, Ada to create text, image, code and more within seconds. The process is simple. All you have to do is provide a topic or idea, and our AI-based generator will take care of the rest.', NULL, '2023-06-02 05:14:35', '2023-06-02 05:14:35'),
	(2, 'Can I create templates or chat bots?', 'You can use pre-made templates and examples for various content types and industries to help you get started quickly. You can even create your own chatbot or custom prompt template for further customization.', NULL, '2023-06-02 05:15:43', '2023-06-02 05:15:43'),
	(3, 'Should I buy regular or extended license?', 'If you plan to charge end users for the final product or service, you should buy the extended license in compliance with Envato’s terms of service, same as other projects: https://codecanyon.net/licenses/standard', NULL, '2023-06-02 05:16:02', '2023-06-02 05:16:02'),
	(4, 'Can I translate the script into another language?', 'Yes! MagicAI\'s multilingual capabilities apply to both content generation and dashboard language. You can easily translate it into other languages. A built-in translation tool is coming soon!', NULL, '2023-06-02 05:16:25', '2023-06-02 05:16:25'),
	(5, 'Is there a mobile app for MagicAI?', 'MagicAI provides an almost native-app experience thanks to its mobile-first approach. The entire layout is responsive and works great on any device regardless of the size.', NULL, '2023-06-02 05:16:53', '2023-06-02 05:16:53');

-- Dumping structure for table magicai.favourite_list
CREATE TABLE IF NOT EXISTS `favourite_list` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.favourite_list: ~0 rows (approximately)

-- Dumping structure for table magicai.features_marquees
CREATE TABLE IF NOT EXISTS `features_marquees` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.features_marquees: ~0 rows (approximately)
INSERT INTO `features_marquees` (`id`, `title`, `position`, `created_at`, `updated_at`) VALUES
	(1, 'Designed for mobile', 'top', NULL, NULL),
	(2, 'Easy to use', 'top', NULL, NULL),
	(3, 'Customizable', 'top', NULL, NULL),
	(4, 'No coding required', 'top', NULL, NULL),
	(5, '10 Reasons to use MagicAI', 'bottom', NULL, NULL),
	(6, 'No sign up required', 'bottom', NULL, NULL),
	(7, 'No watermarks', 'bottom', NULL, NULL),
	(8, 'No hidden fees', 'bottom', NULL, NULL);

-- Dumping structure for table magicai.folders
CREATE TABLE IF NOT EXISTS `folders` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `team_id` bigint DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `folders_created_by_foreign` (`created_by`),
  CONSTRAINT `folders_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.folders: ~0 rows (approximately)

-- Dumping structure for table magicai.footer_items
CREATE TABLE IF NOT EXISTS `footer_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `item` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.footer_items: ~0 rows (approximately)
INSERT INTO `footer_items` (`id`, `item`, `created_at`, `updated_at`) VALUES
	(1, 'Premium Support 30-Day', NULL, NULL),
	(2, 'Money Back Guarantee', NULL, NULL),
	(3, 'Instant Access', NULL, NULL),
	(4, 'Free Trial', NULL, NULL),
	(5, 'Lifetime Updates', NULL, NULL);

-- Dumping structure for table magicai.frontend_channel_settings
CREATE TABLE IF NOT EXISTS `frontend_channel_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.frontend_channel_settings: ~4 rows (approximately)
INSERT INTO `frontend_channel_settings` (`id`, `title`, `key`, `description`, `image`, `logo`, `created_at`, `updated_at`) VALUES
	(1, 'Facebook', 'facebook', 'Our AI tool helps you craft compelling content that resonates with your audience Whether it\'s a status update, promotional post, or a simple interaction.', '/themes/social-media-front/assets/landing-page/card-fb.jpg', 'assets/landing-page/logo-fb.png', '2026-07-24 08:57:50', '2026-07-24 08:57:50'),
	(2, 'Twitter / X', 'x', 'Create impactful X posts with our AI tool in seconds! Whether it\'s a quick update, an engaging tweet, or a conversation starter, generate posts that drive conversations and keep your followers engaged on X.', '/themes/social-media-front/assets/landing-page/card-x.jpg', 'assets/landing-page/logo-x.png', '2026-07-24 08:57:50', '2026-07-24 08:57:50'),
	(3, 'Instagram', 'instagram', 'Design eye-catching Instagram posts in no time with our AI-powered generator. From beautiful visuals to captivating captions, create Instagram content that stands out and grabs your followers\' attention.', '/themes/social-media-front/assets/landing-page/card-ig.jpg', 'assets/landing-page/logo-ig.png', '2026-07-24 08:57:50', '2026-07-24 08:57:50'),
	(4, 'LinkedIn', 'linkedin', 'Build your professional presence with polished LinkedIn posts. Our AI helps you write insightful articles, thought-provoking updates, and attention-grabbing headlines that engage with your network.', '/themes/social-media-front/assets/landing-page/card-in.jpg', 'assets/landing-page/logo-in.png', '2026-07-24 08:57:50', '2026-07-24 08:57:50');

-- Dumping structure for table magicai.frontend_content_boxes
CREATE TABLE IF NOT EXISTS `frontend_content_boxes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `emoji` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `background` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `foreground` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.frontend_content_boxes: ~3 rows (approximately)
INSERT INTO `frontend_content_boxes` (`id`, `emoji`, `title`, `description`, `background`, `foreground`, `created_at`, `updated_at`) VALUES
	(1, '😎', 'Partner', 'Invite your colleagues and collaborators to join a team and maximize the benefits of AI.', '#615C5A', '#fff', '2026-07-24 08:57:50', '2026-07-24 08:57:50'),
	(2, '🚀', 'Collaborate', 'Invite your colleagues and collaborators to join a team and maximize the benefits of AI.', '#EB6434', '#fff', '2026-07-24 08:57:50', '2026-07-24 08:57:50'),
	(3, '👥', 'Invite', 'Invite your colleagues and collaborators to join a team and maximize the benefits of AI.', '#3B4F99', '#fff', '2026-07-24 08:57:50', '2026-07-24 08:57:50');

-- Dumping structure for table magicai.frontend_curtains
CREATE TABLE IF NOT EXISTS `frontend_curtains` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sliders` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.frontend_curtains: ~3 rows (approximately)
INSERT INTO `frontend_curtains` (`id`, `title`, `title_icon`, `sliders`, `created_at`, `updated_at`) VALUES
	(1, 'Sarah J.', '', '[{"title": "Sarah J.", "bg_color": "", "bg_image": "", "bg_video": "/themes/social-media-front/assets/landing-page/demo-vid-1.webm", "description": "Translates Podcasts into different languages.", "title_color": "", "description_color": ""}, {"title": "Sarah J.", "bg_color": "", "bg_image": "", "bg_video": "/themes/social-media-front/assets/landing-page/demo-vid-1.webm", "description": "", "title_color": "", "description_color": ""}, {"title": "Sarah J.", "bg_color": "", "bg_image": "", "bg_video": "/themes/social-media-front/assets/landing-page/demo-vid-1.webm", "description": "", "title_color": "", "description_color": ""}]', '2026-07-24 08:57:50', '2026-07-24 08:57:50'),
	(2, 'Jason R.', '', '[{"title": "Jason R.", "bg_color": "#aea397", "bg_image": "", "bg_video": "/themes/social-media-front/assets/landing-page/demo-vid-1.webm", "description": "", "title_color": "", "description_color": ""}, {"title": "Jason R.", "bg_color": "#aea397", "bg_image": "/themes/social-media-front/assets/landing-page/banner-img.jpg", "bg_video": "", "description": "", "title_color": "", "description_color": ""}]', '2026-07-24 08:57:50', '2026-07-24 08:57:50'),
	(3, 'Mary J.', '', '[{"title": "Mary J.", "bg_color": "#496e8f", "bg_image": "", "bg_video": "/themes/social-media-front/assets/landing-page/demo-vid-1.webm", "description": "", "title_color": "", "description_color": ""}]', '2026-07-24 08:57:50', '2026-07-24 08:57:50');

-- Dumping structure for table magicai.frontend_footer_settings
CREATE TABLE IF NOT EXISTS `frontend_footer_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `header_title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Limited Offer',
  `header_text` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sign up and receive 20% bonus discount on checkout.',
  `hero_subtitle` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Unleash the Power of AI',
  `hero_title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Ultimate AI',
  `hero_description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'All-in-one platform to generate AI content and start making money in minutes.',
  `hero_scroll_text` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Discover MagicAI',
  `hero_button` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Start Making Money',
  `hero_button_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hero_image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '/themes/dark/assets/landing-page/banner-img.jpg',
  `hero_button_type` int NOT NULL DEFAULT '1',
  `footer_header` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Start your free trial.',
  `footer_text_small` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pay once, own forever.',
  `footer_text` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Unlock your business potential by letting the AI work and generate money for you.',
  `footer_button_text` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Join our community',
  `footer_button_url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'https://codecanyon.net/item/magicai-openai-content-text-image-chat-code-generator-as-saas/45408109',
  `footer_copyright` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'All images are for demo purposes.',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `hero_title_text_rotator` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'Generator,Chatbot,Assistant',
  `sign_in` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sign In',
  `join_hub` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Join Hub',
  `floating_button_small_text` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `floating_button_bold_text` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `floating_button_link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `floating_button_active` tinyint(1) NOT NULL DEFAULT '0',
  `footer_text_color` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `no_credit_cart_required` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT 'No credit cart required.',
  `faster_content_creation` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '<span class="font-heading text-[1.857em]/[1em] font-bold">10x</span>Faster Content Creation',
  `over_5000_businesses` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT 'over <u>5000+</u> businesses trust us to boost their social media precense',
  `join_the_ranks` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.frontend_footer_settings: ~0 rows (approximately)
INSERT INTO `frontend_footer_settings` (`id`, `header_title`, `header_text`, `hero_subtitle`, `hero_title`, `hero_description`, `hero_scroll_text`, `hero_button`, `hero_button_url`, `hero_image`, `hero_button_type`, `footer_header`, `footer_text_small`, `footer_text`, `footer_button_text`, `footer_button_url`, `footer_copyright`, `created_at`, `updated_at`, `hero_title_text_rotator`, `sign_in`, `join_hub`, `floating_button_small_text`, `floating_button_bold_text`, `floating_button_link`, `floating_button_active`, `footer_text_color`, `no_credit_cart_required`, `faster_content_creation`, `over_5000_businesses`, `join_the_ranks`) VALUES
	(1, 'Limited Offer', 'Sign up and receive 20% bonus discount on checkout.', 'Unleash the Power of AI', 'Ultimate AI', 'All-in-one platform to generate AI content and start making money in minutes.', 'Discover MagicAI', 'Start Making Money', NULL, '/themes/dark/assets/landing-page/banner-img.jpg', 1, 'Start your free trial.', 'Pay once, own forever.', 'Unlock your business potential by letting the AI work and generate money for you.', 'Join our community', 'https://codecanyon.net/item/magicai-openai-content-text-image-chat-code-generator-as-saas/45408109', 'All images are for demo purposes.', '2026-07-24 08:58:18', '2026-07-24 08:58:18', 'Generator,Chatbot,Assistant', 'Sign In', 'Join Hub', NULL, NULL, NULL, 0, NULL, 'No credit cart required.', '<span class="font-heading text-[1.857em]/[1em] font-bold">10x</span>Faster Content Creation', 'over <u>5000+</u> businesses trust us to boost their social media precense', NULL);

-- Dumping structure for table magicai.frontend_future
CREATE TABLE IF NOT EXISTS `frontend_future` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `image` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.frontend_future: ~0 rows (approximately)
INSERT INTO `frontend_future` (`id`, `title`, `description`, `image`, `created_at`, `updated_at`) VALUES
	(1, 'AI Generator', 'Generate <strong>text, image, code, chat</strong> and even more with', ' <svg width="20" height="21" viewBox="0 0 20 21" fill="none" stroke="currentColor" xmlns="http://www.w3.org/2000/svg">\n                                <path d="M2.333 14.204L14.571 1.966C15.0509 1.48609 15.7018 1.21648 16.3805 1.21648C16.7166 1.21648 17.0493 1.28267 17.3598 1.41127C17.6703 1.53988 17.9524 1.72837 18.19 1.966C18.4276 2.20363 18.6161 2.48573 18.7447 2.79621C18.8733 3.10668 18.9395 3.43944 18.9395 3.7755C18.9395 4.11156 18.8733 4.44432 18.7447 4.75479C18.6161 5.06527 18.4276 5.34737 18.19 5.585L5.952 17.823C5.6728 18.1022 5.31719 18.2926 4.93 18.37L1 19.156L1.786 15.226C1.86345 14.8388 2.05378 14.4832 2.333 14.204Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>\n                                <path d="M12.5 4.656L15.5 7.656" stroke-width="2"/>\n                            </svg>', '2023-06-02 08:32:56', '2023-06-02 08:32:56'),
	(2, 'Advanced Dashboard', 'Access to valuable user insight, analytics and activity.', '  <svg width="16" height="18" viewBox="0 0 16 18" fill="currentColor" xmlns="http://www.w3.org/2000/svg">\n                                <path d="M3.46 13.838H5.19V3.46H3.46V13.838ZM6.92 17.298H8.65V0H6.92V17.298ZM0 10.379H1.73V6.919H0V10.379ZM10.379 13.839H12.109V3.46H10.379V13.839ZM13.839 6.92V10.38H15.569V6.92H13.839Z"/>\n                            </svg>', '2023-06-02 08:32:56', '2023-06-02 08:32:56'),
	(3, 'Payment Gateways', 'Securely process credit card, debit card, or other methods.', ' <svg width="19" height="19" viewBox="0 0 19 19" fill="currentColor" xmlns="http://www.w3.org/2000/svg">\n                                <path d="M3.421 -6.80448e-08L3.267 0.643L0.231 14.636L0 15.636H4.013L3.524 17.925L3.293 18.925H9.029L9.158 18.256L10.007 14.295H12.219C13.7458 14.318 15.2324 13.8059 16.4212 12.8475C17.6099 11.8891 18.4257 10.5449 18.727 9.048C18.9117 8.34466 18.9335 7.60848 18.7909 6.89542C18.6483 6.18237 18.345 5.51122 17.904 4.933C17.2726 4.18389 16.4149 3.66026 15.46 3.441C15.303 2.67914 14.9378 1.97574 14.405 1.409C13.9537 0.955562 13.416 0.597241 12.8237 0.355227C12.2315 0.113213 11.5967 -0.00757721 10.957 -6.80448e-08H3.421ZM4.758 1.646H10.958C11.8009 1.63923 12.613 1.96222 13.221 2.546C13.563 2.92723 13.7979 3.39222 13.9019 3.89369C14.0059 4.39516 13.9752 4.91523 13.813 5.401C13.6186 6.54221 13.0154 7.57362 12.116 8.30255C11.2167 9.03148 10.0827 9.40808 8.926 9.362H5.376L5.25 10.006L4.401 13.993H2.058L4.758 1.646ZM6.841 2.855L6.687 3.498L5.839 7.3L5.608 8.3H8.515C9.23308 8.28426 9.92567 8.0308 10.4843 7.57932C11.0429 7.12783 11.436 6.50381 11.602 5.805H11.628C11.628 5.789 11.628 5.77 11.628 5.754C11.7218 5.41549 11.7405 5.06056 11.6828 4.71406C11.6252 4.36756 11.4924 4.03785 11.294 3.748C11.0809 3.46596 10.8048 3.23768 10.4878 3.0814C10.1707 2.92513 9.82147 2.8452 9.468 2.848L6.841 2.855ZM8.15 4.5H9.462C9.55438 4.48894 9.64804 4.50213 9.73378 4.53824C9.81952 4.57436 9.89438 4.63218 9.951 4.706C10.0148 4.80392 10.055 4.91532 10.0683 5.03143C10.0817 5.14753 10.0679 5.26515 10.028 5.375V5.4C9.92453 5.73467 9.72591 6.032 9.45637 6.25573C9.18682 6.47947 8.858 6.61993 8.51 6.66H7.661L8.15 4.5ZM15.506 5.22C15.9416 5.37924 16.3307 5.64457 16.638 5.992C16.9265 6.37171 17.1192 6.81536 17.1998 7.28537C17.2804 7.75537 17.2465 8.23787 17.101 8.692C16.9066 9.83321 16.3034 10.8646 15.404 11.5935C14.5047 12.3225 13.3707 12.6991 12.214 12.653H8.664L8.535 13.296L7.686 17.283H5.35L5.71 15.637H5.736L5.865 14.968L6.714 11.007H8.926C10.4528 11.03 11.9394 10.5179 13.1282 9.55954C14.3169 8.60115 15.1327 7.25692 15.434 5.76C15.472 5.575 15.488 5.4 15.51 5.221L15.506 5.22Z"/>\n                            </svg>', '2023-06-02 08:32:56', '2023-06-02 08:32:56'),
	(4, 'Multi-Lingual', 'Ability to understand and generate content in different languages', ' <svg width="22" height="22" viewBox="0 0 22 22" fill="none" stroke="currentColor" xmlns="http://www.w3.org/2000/svg">\n                                <path d="M10.85 20.85C16.3728 20.85 20.85 16.3728 20.85 10.85C20.85 5.32715 16.3728 0.85 10.85 0.85C5.32715 0.85 0.85 5.32715 0.85 10.85C0.85 16.3728 5.32715 20.85 10.85 20.85Z" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>\n                                <path d="M6.85 10.85C6.85 16.3728 8.64086 20.85 10.85 20.85C13.0591 20.85 14.85 16.3728 14.85 10.85C14.85 5.32715 13.0591 0.85 10.85 0.85C8.64086 0.85 6.85 5.32715 6.85 10.85Z" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>\n                                <path d="M0.85 10.85H20.85" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>\n                            </svg>', '2023-06-02 08:32:56', '2023-06-02 08:32:56'),
	(5, 'Custom Templates', 'Add unlimited number of custom prompts for your customers.', '  <svg width="19" height="16" viewBox="0 0 19 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">\n                                <path d="M14.84 6.509H7.29C6.571 6.509 6.509 7.091 6.509 7.809C6.509 8.527 6.571 9.109 7.29 9.109H14.84C15.559 9.109 15.621 8.527 15.621 7.809C15.621 7.091 15.558 6.509 14.84 6.509ZM17.44 13.018H7.29C6.571 13.018 6.509 13.6 6.509 14.318C6.509 15.036 6.571 15.618 7.29 15.618H17.443C18.162 15.618 18.224 15.036 18.224 14.318C18.224 13.6 18.162 13.018 17.443 13.018H17.44ZM7.29 2.6H17.443C18.162 2.6 18.224 2.018 18.224 1.3C18.224 0.582 18.162 0 17.443 0H7.29C6.571 0 6.509 0.582 6.509 1.3C6.509 2.018 6.571 2.6 7.29 2.6ZM3.124 6.509H0.781C0.0619999 6.509 0 7.091 0 7.809C0 8.527 0.0619999 9.109 0.781 9.109H3.124C3.843 9.109 3.905 8.527 3.905 7.809C3.905 7.091 3.843 6.509 3.124 6.509ZM3.124 13.018H0.781C0.0619999 13.018 0 13.6 0 14.318C0 15.036 0.0619999 15.618 0.781 15.618H3.124C3.843 15.618 3.905 15.036 3.905 14.318C3.905 13.6 3.843 13.018 3.124 13.018ZM3.124 0H0.781C0.0619999 0 0 0.582 0 1.3C0 2.018 0.0619999 2.6 0.781 2.6H3.124C3.843 2.6 3.905 2.018 3.905 1.3C3.905 0.582 3.843 0 3.124 0Z"/>\n                            </svg>', '2023-06-02 08:32:56', '2023-06-02 08:32:56'),
	(6, 'Support Platform', 'Access and manage your support tickets from your dashboard.', '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" xmlns="http://www.w3.org/2000/svg">\n                                <path d="M9.217 1.068L9.635 7.968M13.818 7.968L14.236 1.068M9.217 22.191L9.635 15.291M13.818 15.291L14.236 22.191M22.287 9.121L15.387 9.539M15.387 13.722L22.287 14.14M1.164 9.121L8.064 9.539M8.064 13.722L1.164 14.14M22.85 11.85C22.85 17.9251 17.9251 22.85 11.85 22.85C5.77487 22.85 0.849998 17.9251 0.849998 11.85C0.849998 5.77487 5.77487 0.849998 11.85 0.849998C17.9251 0.849998 22.85 5.77487 22.85 11.85ZM15.85 11.85C15.85 14.0591 14.0591 15.85 11.85 15.85C9.64086 15.85 7.85 14.0591 7.85 11.85C7.85 9.64086 9.64086 7.85 11.85 7.85C14.0591 7.85 15.85 9.64086 15.85 11.85Z" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>\n                            </svg>', '2023-06-02 08:32:56', '2023-06-02 08:32:56');

-- Dumping structure for table magicai.frontend_generators
CREATE TABLE IF NOT EXISTS `frontend_generators` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `menu_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subtitle_one` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subtitle_two` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_subtitle` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `icon` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.frontend_generators: ~0 rows (approximately)
INSERT INTO `frontend_generators` (`id`, `menu_title`, `subtitle_one`, `subtitle_two`, `title`, `text`, `image`, `image_title`, `image_subtitle`, `color`, `created_at`, `updated_at`, `icon`) VALUES
	(1, 'AI Text Generator', 'Say goodbye to writer\'s block', 'AI', 'Intelligent Writing Assistant', 'Writer is designed to help you <strong>generate high-quality texts instantly</strong>, without breaking a sweat. With our intuitive interface and powerful features, you can easily edit, export, or publish your AI-generated result.', 'assets/img/site/text-generator.jpg', 'Generate, edit, export.', 'Powered by OpenAI.', '#EADDF9', '2023-06-02 08:33:09', '2023-06-02 08:33:09', NULL),
	(2, 'AI Image Generator', 'Unleash your creativity', 'AI', 'Create eye-catching images and graphics.', 'Generate high-quality images for a wide range of applications.', 'assets/img/site/image-generator.jpg', 'Imagine, Generate, Publish.', 'Powered by Dall-E.', '#DFE5EB', '2023-06-02 08:33:09', '2023-06-02 08:33:09', NULL),
	(3, 'AI Code Generator', 'The future of development', 'AI', 'Generate high-quality code in no time.', 'MagicAI is designed to make coding faster, easier, and more efficient than ever before. Whether you’re a seasoned developer or a coding newbie, our tool will help you streamline your coding process and get your projects up and running in no time.', 'assets/img/site/code-generator.jpg', 'Fix. Improve. Generate.', 'Powered by OpenAI.', '#DDE6FF', '2023-06-02 08:33:09', '2023-06-02 08:33:09', NULL),
	(4, 'AI Chat Bot', 'Intuitive / Humanlike Chatbot', 'AI', 'Meet your next virtual assistant.', 'Get instant answers to your questions, no matter the topic. Whether you’re looking to book a reservation, get product recommendations, or just chat about the weather, MagicAI is always ready and willing to help.', 'assets/img/site/ai-chat.jpg', 'Chat, Solve, Repeat.', 'Powered by OpenAI.', '#F9DDDF', '2023-06-02 08:33:09', '2023-06-02 08:33:09', NULL),
	(5, 'AI Speech To Text', 'Say goodbye to writer\'s block', 'AI', 'Transcribe your speech into text.', 'Accurately transcribe your recordings in just minutes. With our user-friendly interface, you can upload your files and have them transcribed in a matter of clicks.', 'assets/img/site/ai-speech.jpg', 'Upload, Analyze, Generate.', 'Powered by OpenAI.', '#FFF8EB', '2023-06-02 08:33:09', '2023-06-02 08:33:09', NULL),
	(6, 'Empower Your Message with AI', 'Say goodbye to writer\'s block', 'AI', 'Transcribe your speech into text.', 'From captivating commercials to engaging narrations, our AI voice will bring your words to life. With its seamless delivery, natural intonation, and unrivaled versatility, our AI VoiceOver is the perfect choice for any project. Effortlessly choose from a variety of voices and languages while adjusting the pace to your preference.', 'assets/img/site/voiceover.jpg', 'Upload, Analyze, Generate.', 'Powered by OpenAI.', '#FFF8EB', '2023-06-02 08:33:09', '2023-06-02 08:33:09', NULL);

-- Dumping structure for table magicai.frontend_sections_statuses_titles
CREATE TABLE IF NOT EXISTS `frontend_sections_statuses_titles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `features_active` tinyint(1) NOT NULL DEFAULT '1',
  `features_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'The future of AI.',
  `features_subtitle` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Unleash the Power of AI',
  `features_description` text COLLATE utf8mb4_unicode_ci,
  `generators_active` tinyint(1) NOT NULL DEFAULT '1',
  `who_is_for_active` tinyint(1) NOT NULL DEFAULT '1',
  `custom_templates_active` tinyint(1) NOT NULL DEFAULT '1',
  `custom_templates_subtitle_one` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'Custom',
  `custom_templates_subtitle_two` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'Prompts',
  `custom_templates_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'Custom Templates.',
  `custom_templates_learn_more_link_url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#templates',
  `custom_templates_learn_more_link` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Discover MagicAI',
  `custom_templates_description` text COLLATE utf8mb4_unicode_ci,
  `tools_active` tinyint(1) NOT NULL DEFAULT '1',
  `tools_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'Magic Tools.',
  `tools_subtitle` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Unleash the Power of AI',
  `tools_description` text COLLATE utf8mb4_unicode_ci,
  `how_it_works_active` tinyint(1) NOT NULL DEFAULT '1',
  `how_it_works_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'So, how does it work?',
  `how_it_works_link_label` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Learn More',
  `how_it_works_link` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#',
  `how_it_works_description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'To create content quickly and effectively, <strong>here are the steps you can follow:</strong>',
  `how_it_works_subtitle` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Unleash the Power of AI',
  `testimonials_active` tinyint(1) NOT NULL DEFAULT '1',
  `testimonials_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'Trusted by millions.',
  `testimonials_description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Content and <strong>kickstart your earnings</strong> in minutes  kickstart your earnings in minutes',
  `testimonials_subtitle_one` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Testimonials',
  `testimonials_subtitle_two` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'Trustpilot',
  `pricing_active` tinyint(1) NOT NULL DEFAULT '1',
  `pricing_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'Flexible Pricing.',
  `pricing_subtitle` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Unleash the Power of AI',
  `pricing_description` text COLLATE utf8mb4_unicode_ci,
  `pricing_save_percent` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'Save 30%',
  `faq_active` tinyint(1) NOT NULL DEFAULT '1',
  `faq_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'Have a question?',
  `faq_subtitle` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'Our support team will get assistance from AI-powered suggestions, making it quicker than ever to handle support requests.',
  `faq_text_one` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'FAQ',
  `faq_text_two` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'Help Center',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `preheader_active` tinyint(1) NOT NULL DEFAULT '1',
  `blog_active` tinyint(1) NOT NULL DEFAULT '0',
  `blog_title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Latest News',
  `blog_subtitle` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Stay up-to-date',
  `blog_posts_per_page` int NOT NULL DEFAULT '3',
  `blog_button_text` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Show more',
  `blog_a_title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Blog Posts',
  `blog_a_subtitle` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Latest News',
  `blog_a_description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Welcome to our cozy corner of the internet, where you will find a delightful collection of our heartfelt and thought-provoking blog posts.',
  `blog_a_posts_per_page` int NOT NULL DEFAULT '6',
  `marquee_items` text COLLATE utf8mb4_unicode_ci,
  `generators_subtitle` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `generators_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `generators_description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `plan_footer_text` text COLLATE utf8mb4_unicode_ci,
  `advanced_features_section_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `advanced_features_section_description` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.frontend_sections_statuses_titles: ~0 rows (approximately)
INSERT INTO `frontend_sections_statuses_titles` (`id`, `features_active`, `features_title`, `features_subtitle`, `features_description`, `generators_active`, `who_is_for_active`, `custom_templates_active`, `custom_templates_subtitle_one`, `custom_templates_subtitle_two`, `custom_templates_title`, `custom_templates_learn_more_link_url`, `custom_templates_learn_more_link`, `custom_templates_description`, `tools_active`, `tools_title`, `tools_subtitle`, `tools_description`, `how_it_works_active`, `how_it_works_title`, `how_it_works_link_label`, `how_it_works_link`, `how_it_works_description`, `how_it_works_subtitle`, `testimonials_active`, `testimonials_title`, `testimonials_description`, `testimonials_subtitle_one`, `testimonials_subtitle_two`, `pricing_active`, `pricing_title`, `pricing_subtitle`, `pricing_description`, `pricing_save_percent`, `faq_active`, `faq_title`, `faq_subtitle`, `faq_text_one`, `faq_text_two`, `created_at`, `updated_at`, `preheader_active`, `blog_active`, `blog_title`, `blog_subtitle`, `blog_posts_per_page`, `blog_button_text`, `blog_a_title`, `blog_a_subtitle`, `blog_a_description`, `blog_a_posts_per_page`, `marquee_items`, `generators_subtitle`, `generators_title`, `generators_description`, `plan_footer_text`, `advanced_features_section_title`, `advanced_features_section_description`) VALUES
	(1, 1, 'The future of AI.', 'Unleash the Power of AI', NULL, 1, 1, 1, 'Custom', 'Prompts', 'Custom Templates.', '#templates', 'Discover MagicAI', NULL, 1, 'Magic Tools.', 'Unleash the Power of AI', NULL, 1, 'So, how does it work?', 'Learn More', '#', 'To create content quickly and effectively, <strong>here are the steps you can follow:</strong>', 'Unleash the Power of AI', 1, 'Trusted by millions.', 'Content and <strong>kickstart your earnings</strong> in minutes  kickstart your earnings in minutes', 'Testimonials', 'Trustpilot', 1, 'Flexible Pricing.', 'Unleash the Power of AI', NULL, 'Save 30%', 1, 'Have a question?', 'Our support team will get assistance from AI-powered suggestions, making it quicker than ever to handle support requests.', 'FAQ', 'Help Center', '2026-07-24 08:58:18', '2026-07-24 08:58:24', 1, 0, 'Latest News', 'Stay up-to-date', 3, 'Show more', 'Blog Posts', 'Latest News', 'Welcome to our cozy corner of the internet, where you will find a delightful collection of our heartfelt and thought-provoking blog posts.', 6, 'Cold Email,Newsletter,Summarize,Product Description,Testimonial,Pick an outfit,Study Vocabulary, Create a workout plan,Transcribe my class notes,Create a pros and cons list,Morning Productivity Plan,Experience Tokyo like a local,Translate', NULL, NULL, NULL, NULL, NULL, NULL);

-- Dumping structure for table magicai.frontend_tools
CREATE TABLE IF NOT EXISTS `frontend_tools` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `image` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `buy_link` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Start Making Money',
  `buy_link_url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'https://codecanyon.net/item/magicai-openai-content-text-image-chat-code-generator-as-saas/45408109',
  `learn_more_link` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Discover MagicAI',
  `learn_more_link_url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#templates',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.frontend_tools: ~0 rows (approximately)
INSERT INTO `frontend_tools` (`id`, `title`, `description`, `image`, `created_at`, `updated_at`, `buy_link`, `buy_link_url`, `learn_more_link`, `learn_more_link_url`) VALUES
	(1, 'Advanced Dashboard', 'Track a wide range of data points, including user traffic and sales.', 'upload/images/frontent/tools/v6sP-test.png', '2023-05-29 07:18:13', '2023-05-29 07:18:31', 'Start Making Money', 'https://codecanyon.net/item/magicai-openai-content-text-image-chat-code-generator-as-saas/45408109', 'Discover MagicAI', '#templates'),
	(2, 'Payment Gateways', 'Securely process credit card or other electronic payment methods.', 'upload/images/frontent/tools/Payments100.jpg', '2023-05-29 07:19:49', '2023-05-29 07:19:49', 'Start Making Money', 'https://codecanyon.net/item/magicai-openai-content-text-image-chat-code-generator-as-saas/45408109', 'Discover MagicAI', '#templates'),
	(3, 'Multilingual', 'Ability to understand and generate content in different languages.', 'upload/images/frontent/tools/NZBW-multilingual.png', '2023-05-29 07:20:18', '2023-05-29 07:20:18', 'Start Making Money', 'https://codecanyon.net/item/magicai-openai-content-text-image-chat-code-generator-as-saas/45408109', 'Discover MagicAI', '#templates'),
	(4, 'Affiliate System', 'Ability to invite friends, and earn commission from their first purchase.', 'upload/images/frontent/tools/RAhq-affiliate-system.png', '2023-05-29 07:20:49', '2023-05-29 07:20:49', 'Start Making Money', 'https://codecanyon.net/item/magicai-openai-content-text-image-chat-code-generator-as-saas/45408109', 'Discover MagicAI', '#templates'),
	(5, 'Easy Export', 'Export generated content as plain text, PDF, Word or HTML easily.', 'upload/images/frontent/tools/mPWB-easy-export.png', '2023-05-29 07:21:05', '2023-05-29 07:21:05', 'Start Making Money', 'https://codecanyon.net/item/magicai-openai-content-text-image-chat-code-generator-as-saas/45408109', 'Discover MagicAI', '#templates'),
	(6, 'Support Platform', 'Access and mage support tickets from your dashboard.', 'upload/images/frontent/tools/rIwa-support-platform.png', '2023-05-29 07:21:21', '2023-05-29 07:21:21', 'Start Making Money', 'https://codecanyon.net/item/magicai-openai-content-text-image-chat-code-generator-as-saas/45408109', 'Discover MagicAI', '#templates');

-- Dumping structure for table magicai.frontend_who_is_for
CREATE TABLE IF NOT EXISTS `frontend_who_is_for` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.frontend_who_is_for: ~0 rows (approximately)
INSERT INTO `frontend_who_is_for` (`id`, `title`, `color`, `created_at`, `updated_at`) VALUES
	(1, 'Digital Agencies', 'orange', '2023-06-02 06:16:34', '2023-06-02 03:38:34'),
	(2, 'Product Designers', 'purple', '2023-06-02 06:16:34', '2023-06-02 06:16:34'),
	(3, 'Enterpreneurs', 'teal', '2023-06-02 06:16:34', '2023-06-02 06:16:34'),
	(4, 'Copywriters', 'blue', '2023-06-02 06:16:34', '2023-06-02 06:16:34'),
	(5, 'Digital Marketers', 'green', '2023-06-02 06:16:34', '2023-06-02 06:16:34'),
	(6, 'Developers', 'red', '2023-06-02 06:16:34', '2023-06-02 06:16:34');

-- Dumping structure for table magicai.gatewayproducts
CREATE TABLE IF NOT EXISTS `gatewayproducts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `plan_id` int NOT NULL DEFAULT '0',
  `plan_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gateway_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gateway_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payload` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.gatewayproducts: ~0 rows (approximately)

-- Dumping structure for table magicai.gateways
CREATE TABLE IF NOT EXISTS `gateways` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` int NOT NULL DEFAULT '0',
  `mode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sandbox_client_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sandbox_client_secret` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sandbox_app_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `live_client_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `live_client_secret` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `live_app_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_action` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency_locale` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notify_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sandbox_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `locale` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `validate_ssl` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `webhook_secret` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logger` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `webhook_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `automate_tax` tinyint(1) NOT NULL DEFAULT '0',
  `bank_account_details` text COLLATE utf8mb4_unicode_ci,
  `bank_account_other` text COLLATE utf8mb4_unicode_ci,
  `country_tax_enabled` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.gateways: ~0 rows (approximately)

-- Dumping structure for table magicai.gateway_taxes
CREATE TABLE IF NOT EXISTS `gateway_taxes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `gateway_id` int DEFAULT NULL,
  `country_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax` decimal(8,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.gateway_taxes: ~0 rows (approximately)

-- Dumping structure for table magicai.health_check_result_history_items
CREATE TABLE IF NOT EXISTS `health_check_result_history_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `check_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `check_label` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notification_message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_summary` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta` json NOT NULL,
  `ended_at` timestamp NOT NULL,
  `batch` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `health_check_result_history_items_created_at_index` (`created_at`),
  KEY `health_check_result_history_items_batch_index` (`batch`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.health_check_result_history_items: ~0 rows (approximately)

-- Dumping structure for table magicai.howitworks
CREATE TABLE IF NOT EXISTS `howitworks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order` int NOT NULL DEFAULT '0',
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `bg_color` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bg_image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text_color` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.howitworks: ~0 rows (approximately)
INSERT INTO `howitworks` (`id`, `order`, `title`, `created_at`, `updated_at`, `bg_color`, `bg_image`, `text_color`, `image`, `description`) VALUES
	(1, 1, 'Simply explain what your content is about and adjust settings according to your needs.', '2023-06-02 01:41:26', '2023-06-02 01:41:26', NULL, NULL, NULL, NULL, NULL),
	(2, 2, 'Simply input some basic information or keywords about your brand or product, and let our AI algorithms do the rest.', '2023-06-02 01:41:34', '2023-06-02 01:41:34', NULL, NULL, NULL, NULL, NULL),
	(3, 3, 'View, edit or export your result with a few clicks. And you’re done!', '2023-06-02 01:41:41', '2023-06-02 01:41:41', NULL, NULL, NULL, NULL, NULL);

-- Dumping structure for table magicai.integrations
CREATE TABLE IF NOT EXISTS `integrations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `app` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.integrations: ~0 rows (approximately)
INSERT INTO `integrations` (`id`, `app`, `description`, `image`, `slug`, `status`, `created_at`, `updated_at`) VALUES
	(1, 'Wordpress', 'Wordpress integration', 'images/integrations/wordpress.png', 'wordpress', 0, '2024-03-08 16:28:43', '2024-03-08 16:28:44');

-- Dumping structure for table magicai.introductions
CREATE TABLE IF NOT EXISTS `introductions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `intro` text COLLATE utf8mb4_unicode_ci,
  `order` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `title` text COLLATE utf8mb4_unicode_ci,
  `file_path` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.introductions: ~0 rows (approximately)
INSERT INTO `introductions` (`id`, `key`, `intro`, `order`, `created_at`, `updated_at`, `status`, `title`, `file_path`, `file_url`, `file_type`, `parent_id`) VALUES
	(1, 'initialize', 'Welcome to MagicAI. Let\'s take a quick tour', 1, '2026-07-24 08:58:23', '2026-07-24 08:58:23', 1, NULL, NULL, NULL, NULL, NULL),
	(2, 'ai_writer', 'A great tool for using the Text Generator & AI Copywriting Assistant.', 2, '2026-07-24 08:58:23', '2026-07-24 08:58:23', 1, NULL, NULL, NULL, NULL, NULL),
	(3, 'ai_image', 'Create stunning images with just a few words.', 3, '2026-07-24 08:58:23', '2026-07-24 08:58:23', 1, NULL, NULL, NULL, NULL, NULL),
	(4, 'ai_pdf', 'Simply upload a PDF, find specific information. extract key insights or summarize the entire document.', 4, '2026-07-24 08:58:23', '2026-07-24 08:58:23', 1, NULL, NULL, NULL, NULL, NULL),
	(5, 'ai_code', 'Generate high quality code in seconds.', 5, '2026-07-24 08:58:23', '2026-07-24 08:58:23', 1, NULL, NULL, NULL, NULL, NULL),
	(6, 'select_plan', 'Choose the plan that suits you and start creating right away.', 6, '2026-07-24 08:58:23', '2026-07-24 08:58:23', 1, NULL, NULL, NULL, NULL, NULL),
	(7, 'affiliate_send', 'Invite your friends and start earning commissions.', 7, '2026-07-24 08:58:23', '2026-07-24 08:58:23', 1, NULL, NULL, NULL, NULL, NULL);

-- Dumping structure for table magicai.jobs
CREATE TABLE IF NOT EXISTS `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.jobs: ~0 rows (approximately)

-- Dumping structure for table magicai.linkedin_tokens
CREATE TABLE IF NOT EXISTS `linkedin_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `access_token` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.linkedin_tokens: ~0 rows (approximately)

-- Dumping structure for table magicai.menus
CREATE TABLE IF NOT EXISTS `menus` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int unsigned DEFAULT NULL,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `route` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `route_slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `svg` text COLLATE utf8mb4_unicode_ci,
  `order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `params` longtext COLLATE utf8mb4_unicode_ci,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `badge` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `extension` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bolt_menu` tinyint(1) DEFAULT '0',
  `bolt_background` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bolt_foreground` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `letter_icon` tinyint(1) DEFAULT '0',
  `letter_icon_bg` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `custom_menu` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `menus_key_unique` (`key`),
  KEY `idx_menus_parent_id` (`parent_id`),
  KEY `idx_menus_parent_id_order` (`parent_id`,`order`),
  KEY `idx_menus_is_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=284 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.menus: ~0 rows (approximately)
INSERT INTO `menus` (`id`, `parent_id`, `key`, `route`, `route_slug`, `label`, `icon`, `svg`, `order`, `is_active`, `params`, `type`, `badge`, `extension`, `bolt_menu`, `bolt_background`, `bolt_foreground`, `letter_icon`, `letter_icon_bg`, `created_at`, `updated_at`, `custom_menu`) VALUES
	(1, NULL, 'user_label', NULL, NULL, 'User', NULL, NULL, 1, 1, '[]', 'label', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(2, NULL, 'dashboard', 'dashboard.user.index', NULL, 'Dashboard', 'tabler-layout-2', NULL, 2, 1, '[]', 'item', NULL, NULL, 1, '#9A6FFD', '#fff', NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:24', 0),
	(3, NULL, 'creative_suite', 'dashboard.user.creative-suite.index', NULL, 'Creative Suite', 'tabler-image-in-picture', NULL, 3, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(4, NULL, 'ext_chat_bot', 'dashboard.chatbot.index', NULL, 'AI Chat Bots', 'tabler-message-chatbot', NULL, 4, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(5, NULL, 'ext_chatbot_analytics', 'dashboard.chatbot.analytics.index', NULL, 'AI Bot Analytics', 'tabler-chart-bar', NULL, 4, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(6, NULL, 'ext_chatbot_knowledge_base_article', 'dashboard.chatbot.knowledge-base-article.index', NULL, 'AI Bot Knowledge Base', 'tabler-library', NULL, 5, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(7, NULL, 'ext_chatbot_canned_response', 'dashboard.chatbot.canned-response.index', NULL, 'AI Bot Canned Responses', 'tabler-message-reply', NULL, 5, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(8, NULL, 'ext_chatbot_chatbot_customer_article', 'dashboard.chatbot.chatbot-customer.index', NULL, 'AI Bot Contacts', 'tabler-library', NULL, 5, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(9, NULL, 'ext_voice_chatbot', 'dashboard.chatbot-voice.index', NULL, 'AI Voice Bots', 'tabler-message-chatbot', NULL, 4, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(10, NULL, 'ext_phone_call_agent', 'dashboard.phone-call-agent.index', NULL, 'Phone Call Agent', 'tabler-phone-call', NULL, 4, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(11, 10, 'ext_phone_call_agent_dashboard', 'dashboard.phone-call-agent.index', NULL, 'Dashboard', 'tabler-layout-dashboard', NULL, 1, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(12, 10, 'ext_phone_call_agent_history', 'dashboard.phone-call-agent.history', NULL, 'Call History', 'tabler-history', NULL, 2, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(13, 10, 'ext_phone_call_agent_new', 'dashboard.phone-call-agent.new', NULL, 'Create Agent', 'tabler-plus', NULL, 3, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(14, NULL, 'marketing_bot_dashboard', 'dashboard.user.marketing-bot.dashboard', NULL, 'Marketing Bot', 'tabler-dashboard', NULL, 4, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(15, NULL, 'marketing_bot_settings', 'dashboard.user.marketing-bot.settings.index', NULL, 'Marketing Bot Settings', 'tabler-settings-code', NULL, 4, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(16, NULL, 'marketing_bot', NULL, NULL, 'Marketing bot', NULL, NULL, 4, 1, '[]', 'label', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(17, NULL, 'marketing_bot_inbox', 'dashboard.user.marketing-bot.inbox.index', NULL, 'Inbox', 'tabler-inbox', NULL, 4, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(18, NULL, 'marketing_bot_campaigns', 'dashboard.user.marketing-bot.whatsapp-campaign.index', NULL, 'Campaigns', 'tabler-flag-share', NULL, 4, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(19, 18, 'marketing_bot_campaigns_whatsapp', 'dashboard.user.marketing-bot.whatsapp-campaign.index', NULL, 'Whatsapp', NULL, NULL, 4, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(20, 18, 'marketing_bot_campaigns_telegram', 'dashboard.user.marketing-bot.telegram-campaign.index', NULL, 'Telegram', NULL, NULL, 4, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(21, NULL, 'marketing_bot_telegram', 'dashboard.user.marketing-bot.telegram-group.index', NULL, 'Telegram', 'tabler-brand-telegram', NULL, 4, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(22, 21, 'marketing_bot_telegram_group', 'dashboard.user.marketing-bot.telegram-group.index', NULL, 'Telegram Groups', NULL, NULL, 4, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(23, 21, 'marketing_bot_telegram_subscribers', 'dashboard.user.marketing-bot.telegram-subscriber.index', NULL, 'Telegram Subscribers', NULL, NULL, 4, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(24, NULL, 'marketing_bot_whatsapp', 'dashboard.user.marketing-bot.contact.index', NULL, 'Whatsapp', 'tabler-brand-whatsapp', NULL, 4, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(25, 24, 'marketing_bot_whatsapp_contact', 'dashboard.user.marketing-bot.contact.index', NULL, 'Contact Lists', NULL, NULL, 4, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(26, 24, 'marketing_bot_whatsapp_segment', 'dashboard.user.marketing-bot.segment.index', NULL, 'Segments', NULL, NULL, 4, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(27, 24, 'marketing_bot_whatsapp_contact_list', 'dashboard.user.marketing-bot.contact-list.index', NULL, 'Contacts', NULL, NULL, 4, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(28, NULL, 'ai_agent', 'dashboard.user.ai-agent.dashboard', NULL, 'AI Agent', 'tabler-robot', NULL, 4, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(29, 28, 'ai_agent_dashboard', 'dashboard.user.ai-agent.dashboard', NULL, 'Dashboard', 'tabler-layout-dashboard', NULL, 1, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(30, 28, 'ai_agent_workflows', 'dashboard.user.ai-agent.workflows.index', NULL, 'Agents', 'tabler-git-branch', NULL, 2, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(31, 28, 'ai_agent_messages', 'dashboard.user.ai-agent.messages.index', NULL, 'Channel Messages', 'tabler-messages', NULL, 5, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(32, NULL, 'ext_chat_bot_agent', 'dashboard.chatbot-agent.index', NULL, 'Human Agent', 'tabler-message', NULL, 4, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:21', 0),
	(33, NULL, 'ext_ai_photo_studio_dropdown', 'dashboard.user.ai-photoshoot.index', NULL, 'AI Photoshoot', 'tabler-camera', NULL, 5, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(34, 33, 'ext_ai_photo_studio', 'dashboard.user.ai-photoshoot.index', NULL, 'Dashboard', 'tabler-layout-dashboard', NULL, 1, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(35, 33, 'ext_ai_photo_studio_custom', 'dashboard.user.ai-photoshoot.custom.index', NULL, 'Custom Photoshoot', 'tabler-wand', NULL, 2, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(36, 33, 'ext_ai_photo_studio_templates', 'dashboard.user.ai-photoshoot.templates.index', NULL, 'Template Photoshoot', 'tabler-template', NULL, 3, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(37, 33, 'ext_ai_photo_studio_replace_background', 'dashboard.user.ai-photoshoot.replace-background.index', NULL, 'Replace Background', 'tabler-replace', NULL, 4, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(38, 33, 'ext_ai_photo_studio_edit_image', 'dashboard.user.ai-photoshoot.edit_image.index', NULL, 'Edit Image', 'tabler-pencil', NULL, 5, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(39, 33, 'ext_ai_photo_studio_my_photoshoots', 'dashboard.user.ai-photoshoot.photo_shoots.my', NULL, 'My Photoshoots', 'tabler-photo', NULL, 6, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(40, NULL, 'ext_fashion_studio_dropdown', 'dashboard.user.fashion-studio.index', NULL, 'AI Fashion Studio', 'tabler-tie', NULL, 5, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(41, 40, 'ext_fashion_studio', 'dashboard.user.fashion-studio.index', NULL, 'Dashboard', 'tabler-layout-dashboard', NULL, 1, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(42, 40, 'ext_fashion_studio_photo_shoot', 'dashboard.user.fashion-studio.photo_shoots.index', NULL, 'PhotoShoot', 'tabler-camera', NULL, 1, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(43, 40, 'ext_fashion_studio_virtual_try_on', 'dashboard.user.fashion-studio.virtual_try_on.index', NULL, 'Virtual Try-on', 'tabler-shirt', NULL, 1, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(44, 40, 'ext_fashion_studio_change_model', 'dashboard.user.fashion-studio.change_model.index', NULL, 'Change Model', 'tabler-user-square-rounded', NULL, 1, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(45, 40, 'ext_fashion_studio_edit_image', 'dashboard.user.fashion-studio.edit_image.index', NULL, 'Edit Image', 'tabler-pencil', NULL, 1, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(46, 40, 'ext_fashion_studio_create_video', 'dashboard.user.fashion-studio.create_video.index', NULL, 'Create Video', 'tabler-video', NULL, 1, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(47, 40, 'ext_fashion_studio_photo_shoots', 'dashboard.user.fashion-studio.photo_shoots.my', NULL, 'My Photo Shoots', 'tabler-copy', NULL, 1, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(48, 40, 'ext_fashion_studio_wardrobe', 'dashboard.user.fashion-studio.wardrobe.index', NULL, 'My Wardrobe', 'tabler-hanger-2', NULL, 1, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(49, 40, 'ext_fashion_studio_user_settings', 'dashboard.user.fashion-studio.user_settings.index', NULL, 'Settings', 'tabler-settings', NULL, 99, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(50, NULL, 'ext_ugc_dropdown', 'dashboard.user.ugc-studio.index', NULL, 'UGC', 'tabler-video', NULL, 6, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(51, 50, 'ext_ugc_studio', 'dashboard.user.ugc-studio.index', NULL, 'Studio', 'tabler-layout-dashboard', NULL, 1, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(52, 50, 'ext_ugc_factory', 'dashboard.user.ugc-factory.index', NULL, 'Factory', 'tabler-wand', NULL, 2, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(53, 50, 'ext_ugc_creator', 'dashboard.user.ugc-creator.index', NULL, 'Creator', 'tabler-movie', NULL, 3, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(54, NULL, 'ext_chatbot_customer_tag', 'dashboard.chatbot-customer-tags.index', NULL, 'Customer Tags', 'tabler-tags', NULL, 6, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:22', 0),
	(55, NULL, 'ext_social_media_dropdown', 'dashboard.user.social-media.index', NULL, 'AI Social Media', 'tabler-thumb-up', NULL, 5, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(56, 55, 'ext_social_media', 'dashboard.user.social-media.index', NULL, 'Dashboard', NULL, NULL, 1, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(57, 55, 'ext_social_media_campaign', 'dashboard.user.social-media.campaign.index', NULL, 'Campaigns', NULL, NULL, 3, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(58, 55, 'ext_social_media_platform', 'dashboard.user.social-media.platforms', NULL, 'Platforms', NULL, NULL, 3, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(59, 55, 'ext_social_media_post', 'dashboard.user.social-media.post.index', NULL, 'Social Media Posts', NULL, NULL, 3, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(60, 55, 'ext_social_media_calendar', 'dashboard.user.social-media.calendar', NULL, 'Calendar', NULL, NULL, 3, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(61, 55, 'ext_social_media_automation', 'dashboard.user.social-media.automation.index', NULL, 'Automation', NULL, NULL, 4, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(62, NULL, 'ext_social_media_agent_dropdown', 'dashboard.user.social-media.agent.index', NULL, 'AI Social Media Agent', 'tabler-thumb-up', NULL, 5, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(63, 62, 'ext_social_media_agent_dashboard', 'dashboard.user.social-media.agent.index', NULL, 'Dashboard', NULL, NULL, 1, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(64, 62, 'ext_social_media_agent_agents', 'dashboard.user.social-media.agent.agents', NULL, 'Agents', NULL, NULL, 1, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(65, 62, 'ext_social_media_agent_agents_archived_posts', 'dashboard.user.social-media.agent.posts', NULL, 'Archived Posts', NULL, NULL, 1, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(66, 62, 'ext_social_media_agent_calendar', 'dashboard.user.social-media.agent.calendar', NULL, 'Calendar', NULL, NULL, 2, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(67, 62, 'ext_social_media_agent_analytics', 'dashboard.user.social-media.agent.analytics', NULL, 'Analytics', NULL, NULL, 3, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(68, 62, 'ext_social_media_agent_accounts', 'dashboard.user.social-media.agent.accounts', NULL, 'Accounts', NULL, NULL, 4, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(69, 62, 'ext_social_media_agent_chat', 'dashboard.user.social-media.agent.chat.index', NULL, 'Chat', NULL, NULL, 5, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(70, NULL, 'ext_blogpilot_dropdown', 'dashboard.user.blogpilot.agent.index', NULL, 'AI BlogPilot', 'tabler-file-text-ai', NULL, 5, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(71, 70, 'ext_blogpilot_dashboard', 'dashboard.user.blogpilot.agent.index', NULL, 'Dashboard', NULL, NULL, 1, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(72, 70, 'ext_blogpilot_agents', 'dashboard.user.blogpilot.agent.agents', NULL, 'Agents', NULL, NULL, 2, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(73, 70, 'ext_blogpilot_agents_archived_posts', 'dashboard.user.blogpilot.agent.posts', NULL, 'Posts', NULL, NULL, 3, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(74, 70, 'ext_blogpilot_calendar', 'dashboard.user.blogpilot.agent.calendar', NULL, 'Calendar', NULL, NULL, 4, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(75, 70, 'ext_blogpilot_analytics', 'dashboard.user.blogpilot.agent.analytics', NULL, 'Analytics', NULL, NULL, 5, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(76, NULL, 'ai_influencer', 'dashboard.user.ai-influencer.index', NULL, 'AI Influencer', 'tabler-star', NULL, 10, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:21', 0),
	(77, NULL, 'url_to_video', 'dashboard.user.url-to-video.index', NULL, 'Url To Video', 'tabler-photo-video', NULL, 10, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(78, NULL, 'viral_clips', 'dashboard.user.viral-clips.index', NULL, 'AI Viral Clips', 'tabler-movie', NULL, 10, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(79, NULL, 'influencer_avatar', 'dashboard.user.influencer-avatar.index', NULL, 'Influencer Avatar', 'tabler-device-mobile-star', NULL, 10, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(80, NULL, 'documents', 'dashboard.user.openai.documents.all', NULL, 'Documents', 'tabler-archive', NULL, 3, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(81, NULL, 'ai_editor', 'dashboard.user.generator.index', NULL, 'AI Editor', 'tabler-notebook', NULL, 4, 1, '[]', 'item', NULL, NULL, 1, '#E29CB6', '#fff', NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:24', 0),
	(82, NULL, 'ai_writer', 'dashboard.user.openai.list', NULL, 'AI Writer', 'tabler-notes', NULL, 5, 1, '[]', 'item', NULL, NULL, 1, '#468EA6', '#fff', NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:24', 0),
	(83, NULL, 'ai_video', 'dashboard.user.openai.generator', 'ai_video', 'AI Video', 'tabler-video', NULL, 6, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(84, NULL, 'ai_video_to_video', 'dashboard.user.openai.generator', 'ai_video_to_video', 'AI Video To Video', 'tabler-video', NULL, 7, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(85, NULL, 'ai_image_generator', 'dashboard.user.openai.generator', 'ai_image_generator', 'AI Image', 'tabler-photo', NULL, 7, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(86, NULL, 'ai_article_wizard', 'dashboard.user.openai.articlewizard.new', 'ai_article_wizard', 'AI Article Wizard', 'tabler-ad-2', NULL, 8, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(87, NULL, 'ai_pdf', 'dashboard.user.openai.generator.workbook', 'ai_pdf', 'AI File Chat', 'tabler-file-pencil', NULL, 9, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(88, NULL, 'ai_vision', 'dashboard.user.openai.generator.workbook', 'ai_vision', 'AI Vision', 'tabler-scan-eye', NULL, 10, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(89, NULL, 'ai_realtime_voice_chat', 'dashboard.user.openai.chat.chat', 'ai_realtime_voice_chat', 'AI Realtime Voice Chat', 'tabler-wave-sine', NULL, 10, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(90, NULL, 'ai_realtime_image', 'dashboard.user.ai-realtime-image.index', 'ai_realtime_image', 'AI Realtime Image', 'tabler-image-in-picture', NULL, 10, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(91, NULL, 'ai_rewriter', 'dashboard.user.openai.rewriter', 'ai_rewriter', 'AI ReWriter', 'tabler-ballpen', NULL, 11, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(92, NULL, 'ai_chat_image', 'dashboard.user.openai.generator.workbook', 'ai_chat_image', 'AI Chat Image', 'tabler-photo', NULL, 12, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(93, NULL, 'ai_chat_all', 'dashboard.user.openai.chat.chat', NULL, 'AI Chat', 'tabler-message-dots', NULL, 13, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(94, NULL, 'ai_chat_pro', 'dashboard.user.openai.chat.pro.index', NULL, 'AI Chat Pro', 'tabler-message-plus', NULL, 13, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(95, NULL, 'ai_chat_pro_image_chat', 'ai-chat-image.index', NULL, 'Image Assistant', 'tabler-photo-up', NULL, 13, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(96, NULL, 'ai_image_pro', 'dashboard.user.ai-image-pro.index', NULL, 'AI Image Pro', 'tabler-photo-up', NULL, 13, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(97, NULL, 'ai_image_pro_bookmark', 'dashboard.user.ai-image-pro.index', 'slug=bookmarks', 'Bookmark', 'tabler-bookmark', NULL, 13, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(98, NULL, 'ai_image_pro_real_time', 'dashboard.user.ai-image-pro.realtime', NULL, 'Realtime Image', 'tabler-aperture', NULL, 13, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:25', 0),
	(99, NULL, 'ai_image_pro_edit', 'dashboard.user.ai-image-pro.edit', NULL, 'Smart Edit', 'tabler-vector-bezier', NULL, 13, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(100, NULL, 'ai_image_pro_get_inspired', 'dashboard.user.ai-image-pro.index', 'slug=inspired', 'Get Inspired', 'tabler-wand', NULL, 13, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(101, NULL, 'ai_image_pro_media_library', 'ai-image-pro.media-library', NULL, 'Media Library', 'tabler-inbox', NULL, 13, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(102, NULL, 'ai_code_generator', 'dashboard.user.openai.generator.workbook', 'ai_code_generator', 'AI Code', 'tabler-terminal-2', NULL, 14, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(103, NULL, 'ai_presentation', 'dashboard.user.ai-presentation.index', NULL, 'AI Presentation', 'tabler-presentation', NULL, 14, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(104, NULL, 'ai_youtube', 'dashboard.user.openai.generator.workbook', 'ai_youtube', 'AI YouTube', 'tabler-brand-youtube', NULL, 15, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(105, NULL, 'ai_rss', 'dashboard.user.openai.generator.workbook', 'ai_rss', 'AI RSS', 'tabler-rss', NULL, 15, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(106, NULL, 'ai_speech_to_text', 'dashboard.user.openai.generator', 'ai_speech_to_text', 'AI Speech to Text', 'tabler-microphone', NULL, 16, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(107, NULL, 'ai_voiceover', 'dashboard.user.openai.generator', 'ai_voiceover', 'AI Voiceover', 'tabler-volume', NULL, 17, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(108, NULL, 'ai_voice_isolator', 'dashboard.user.openai.generator', 'ai_voice_isolator', 'AI Voice Isolator', 'tabler-ear-scan', NULL, 18, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(109, NULL, 'ai_voiceover_clone', 'dashboard.user.voice.index', NULL, 'AI Voice Clone', 'tabler-microphone-2', NULL, 18, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:19', '2026-07-24 08:58:19', 0),
	(110, NULL, 'team_menu', 'dashboard.user.team.index', NULL, 'Team', 'tabler-user-plus', NULL, 19, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(111, NULL, 'brand_voice', 'dashboard.user.brand.index', NULL, 'Brand Voice', 'tabler-brand-trello', NULL, 20, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(112, NULL, 'advanced_image', 'dashboard.user.advanced-image.index', NULL, 'AI Image Editor', 'tabler-photo-edit', NULL, 20, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(113, NULL, 'ai_avatar', 'dashboard.user.ai-avatar.index', NULL, 'AI Avatar', 'tabler-slideshow', NULL, 20, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(114, NULL, 'ai_persona', 'dashboard.user.ai-persona.index', NULL, 'AI Persona', 'tabler-camera-star', NULL, 20, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(115, NULL, 'video_studio', 'dashboard.user.video-studio.index', NULL, 'Video Studio', 'tabler-layout-dashboard', NULL, 19, 1, '[]', 'item', NULL, '0', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(116, NULL, 'ai_video_pro', 'dashboard.user.ai-video-pro.index', NULL, 'AI Video Pro', 'tabler-video', NULL, 20, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(117, NULL, 'video_dubbing', 'dashboard.user.video-dubbing.index', NULL, 'Video Dubbing', 'tabler-language', NULL, 20, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(118, NULL, 'ai_captions', 'dashboard.user.ai-captions.index', NULL, 'AI Captions', 'tabler-quote', NULL, 20, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(119, NULL, 'ai_music', 'dashboard.user.ai-music.index', NULL, 'AI Music', 'tabler-slideshow', NULL, 20, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(120, NULL, 'ext_ai_music_pro', 'dashboard.user.ai-music-pro.index', NULL, 'AI Music Pro', 'tabler-music', NULL, 20, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(121, NULL, 'ai_product_shot', 'dashboard.user.ai-product-shot.index', NULL, 'AI Product Photography', 'tabler-photo-star', NULL, 20, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(122, NULL, 'api_keys', 'dashboard.user.apikeys.index', NULL, 'API Keys', 'tabler-key', NULL, 21, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(123, NULL, 'affiliates', 'dashboard.user.affiliates.index', NULL, 'Affiliates', 'tabler-currency-dollar', NULL, 22, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(124, NULL, 'support', 'dashboard.support.list', NULL, 'Support', 'tabler-lifebuoy', NULL, 23, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(125, NULL, 'integration', 'dashboard.user.integration.index', NULL, 'Integration', 'tabler-webhook', NULL, 24, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(126, NULL, 'divider_one', NULL, NULL, NULL, NULL, NULL, 25, 1, '[]', 'divider', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(127, NULL, 'links', NULL, NULL, 'Links', NULL, NULL, 26, 1, '[]', 'label', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(128, NULL, 'favorites', 'dashboard.user.openai.list', 'filter=favorite', 'Favorites', NULL, NULL, 27, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, 1, 'bg-[#7A8193] text-white', '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(129, NULL, 'workbook', 'dashboard.user.openai.documents.all', '?filter=favorites', 'Workbook', NULL, NULL, 28, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, 1, 'bg-[#658C8E] text-white', '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(130, NULL, 'divider_two', NULL, NULL, NULL, NULL, NULL, 29, 1, '[]', 'divider', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(131, NULL, 'admin_label', NULL, NULL, 'Admin', NULL, NULL, 30, 1, '[]', 'label', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(132, NULL, 'admin_dashboard', 'dashboard.admin.index', NULL, 'Dashboard', 'tabler-layout-2', NULL, 31, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(133, NULL, 'marketplace', 'dashboard.admin.marketplace.index', NULL, 'Marketplace', 'tabler-building-store', NULL, 32, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(134, NULL, 'themes', 'dashboard.admin.themes.index', NULL, 'Themes', 'tabler-palette', NULL, 33, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(135, NULL, 'ext_migration', 'migration::welcome', NULL, 'Migration', 'tabler-transfer-in', NULL, 33, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(136, NULL, 'user_management', 'dashboard.admin.users.index', NULL, 'User Management', 'tabler-users', NULL, 34, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(137, 136, 'user_list', 'dashboard.admin.users.index', NULL, 'Users List', NULL, NULL, 34, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(138, 136, 'user_activity', 'dashboard.admin.users.activity', NULL, 'Users Activities', NULL, NULL, 34, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(139, 136, 'user_dashboard', 'dashboard.admin.users.dashboard', NULL, 'Users Dashboard', NULL, NULL, 34, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(140, 136, 'user_deletion', 'dashboard.admin.users.deletion.reqs', NULL, 'User Deletion Requests', NULL, NULL, 34, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(141, 136, 'user_permission', 'dashboard.admin.users.permissions', NULL, 'User Permissions', NULL, NULL, 34, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(142, NULL, 'announcements', 'dashboard.admin.announcements.index', NULL, 'Announcements', 'tabler-speakerphone', NULL, 35, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(143, NULL, 'discount-manager', 'dashboard.admin.discount-manager.index', NULL, 'Discount & Offer Manager', 'tabler-shopping-bag-discount', NULL, 37, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(144, NULL, 'site_promo', 'dashboard.admin.ads.index', NULL, 'Google adsense', 'tabler-ad-circle', NULL, 35, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(145, NULL, 'support_requests', 'dashboard.support.list', NULL, 'Support Requests', 'tabler-lifebuoy', NULL, 36, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(146, NULL, 'templates', 'dashboard.admin.openai.list', NULL, 'Templates', 'tabler-list-details', NULL, 37, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(147, 146, 'built_in_templates', 'dashboard.admin.openai.list', NULL, 'Built-in Templates', NULL, NULL, 38, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(148, 146, 'custom_templates', 'dashboard.admin.openai.custom.list', NULL, 'Custom Templates', NULL, NULL, 39, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(149, 146, 'ai_writer_categories', 'dashboard.admin.openai.categories.list', NULL, 'AI Writer Categories', NULL, NULL, 40, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(150, NULL, 'chat_settings', 'dashboard.admin.openai.chat.category', NULL, 'Chat Settings', 'tabler-message-circle', NULL, 41, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(151, 150, 'chat_categories', 'dashboard.admin.openai.chat.category', NULL, 'Chat Categories', NULL, NULL, 42, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(152, 150, 'chat_templates', 'dashboard.admin.openai.chat.list', NULL, 'Chat Templates', NULL, NULL, 43, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(153, 150, 'chatbot_training', 'dashboard.admin.chatbot.index', NULL, 'Chatbot Training', NULL, NULL, 44, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(154, 150, 'voice_chatbot_training', 'dashboard.admin.voice-chatbot.index', NULL, 'Voice Chatbot Training', NULL, NULL, 44, 1, '[]', 'item', NULL, '0', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(155, 150, 'ai_assistant', 'dashboard.admin.ai-assistant.index', NULL, 'Assistant Training', NULL, NULL, 44, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(156, 227, 'ai_chat_models', 'dashboard.admin.ai-chat-model.index', NULL, 'AI Models', NULL, NULL, 3, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:22', 0),
	(157, 150, 'ai_engines', 'dashboard.admin.ai-chat-model.models.index', NULL, 'AI Engines', NULL, NULL, 45, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(158, 150, 'floating_chat_settings', 'dashboard.admin.chatbot.setting', NULL, 'Floating Chat Settings', NULL, NULL, 45, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(159, 150, 'social_media_agent_chat_settings', 'dashboard.admin.social-media.agent.chat.settings', NULL, 'Social Media Agent Chat', NULL, NULL, 46, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(160, 150, 'external_chat_settings', 'dashboard.admin.chatbot.external_settings', NULL, 'External Chat Settings', NULL, NULL, 47, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(161, NULL, 'frontend', 'dashboard.admin.frontend.settings', NULL, 'Frontend', 'tabler-device-laptop', NULL, 47, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(162, 161, 'frontend_settings', 'dashboard.admin.frontend.settings', NULL, 'Frontend Settings', NULL, NULL, 48, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(163, 161, 'frontend_section_settings', 'dashboard.admin.frontend.sectionsettings', NULL, 'Frontend Section Settings', NULL, NULL, 49, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(164, 161, 'frontend_menu', 'dashboard.admin.frontend.menusettings', NULL, 'Menu', NULL, NULL, 50, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(165, 161, 'social_media_accounts', 'dashboard.admin.frontend.socialmedia', NULL, 'Social Media Accounts', NULL, NULL, 50, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(166, 161, 'auth_settings', 'dashboard.admin.frontend.authsettings', NULL, 'Auth Settings', NULL, NULL, 52, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(167, 161, 'f_a_q', 'dashboard.admin.frontend.faq.index', NULL, 'F.A.Q', NULL, NULL, 53, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(168, 161, 'tools_section', 'dashboard.admin.frontend.tools.index', NULL, 'Tools Section', NULL, NULL, 54, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(169, 161, 'channels_section', 'dashboard.admin.frontend.channel-setting.index', NULL, 'Channels Section', NULL, NULL, 54, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(170, 161, 'content_box', 'dashboard.admin.frontend.content-box.index', NULL, 'Content Box Section', NULL, NULL, 54, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(171, 161, 'curtain_section', 'dashboard.admin.frontend.curtain.index', NULL, 'Curtain Section', NULL, NULL, 54, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(172, 161, 'features_section', 'dashboard.admin.frontend.future.index', NULL, 'Features Section', 'tabler-list-details', NULL, 55, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(173, 161, 'testimonials_section', 'dashboard.admin.testimonials.index', NULL, 'Testimonials Section', NULL, NULL, 56, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(174, 161, 'clients_section', 'dashboard.admin.clients.index', NULL, 'Clients Section', NULL, NULL, 57, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(175, 161, 'how_it_works_section', 'dashboard.admin.howitWorks.index', NULL, 'How it Works Section', NULL, NULL, 58, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(176, 161, 'who_can_use_section', 'dashboard.admin.frontend.whois.index', NULL, 'Who Can Use Section', NULL, NULL, 59, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(177, 161, 'generators_list_section', 'dashboard.admin.frontend.generatorlist.index', NULL, 'Generators List Section', NULL, NULL, 60, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(178, NULL, 'finance', 'dashboard.admin.finance.plans.index', NULL, 'Finance', 'tabler-wallet', NULL, 61, 1, '[]', 'item', NULL, NULL, 1, '#3569F5', '#fff', NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:24', 0),
	(179, 178, 'bank_transactions', 'dashboard.admin.bank.transactions.list', NULL, 'Bank Transactions', NULL, NULL, 62, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(180, 178, 'membership_plans', 'dashboard.admin.finance.plans.index', NULL, 'Membership Plans (old version)', NULL, NULL, 63, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:22', 0),
	(181, 178, 'admin_finance_plan', 'dashboard.admin.finance.plan.index', NULL, 'Pricing Plans', NULL, NULL, 63, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:22', 0),
	(182, 178, 'payment_gateways', 'dashboard.admin.finance.paymentGateways.index', NULL, 'Payment Gateways', NULL, NULL, 64, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(183, 178, 'trial_features', 'dashboard.admin.finance.free.feature', NULL, 'Trial Features', NULL, NULL, 60, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(184, 178, 'mobile_payment', 'dashboard.admin.finance.mobile.index', NULL, 'Mobile Payment', NULL, NULL, 60, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(185, 178, 'shared_credit_costs', 'dashboard.admin.finance.shared-credit-costs.index', NULL, 'Shared Credit Costs', NULL, NULL, 65, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(186, 178, 'shared_credit_migration', 'dashboard.admin.finance.credit-migration.index', NULL, 'Credit Migration', NULL, NULL, 66, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(187, NULL, 'pages', 'dashboard.page.list', NULL, 'Pages', 'tabler-file-description', NULL, 61, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(188, NULL, 'blog', 'dashboard.blog.list', NULL, 'Blog', 'tabler-pencil', NULL, 62, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(189, NULL, 'ai-image-pro-publish-reqs', 'dashboard.admin.ai-image-pro.community-images.index', NULL, 'AI Image Pro Publish Requests', 'tabler-notification', NULL, 63, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(190, NULL, 'affiliates_admin', 'dashboard.admin.affiliates.index', NULL, 'Affiliates', 'tabler-currency-dollar', NULL, 63, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(191, NULL, 'coupons_admin', 'dashboard.admin.coupons.index', NULL, 'Coupons', 'tabler-ticket', NULL, 64, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(192, NULL, 'email_templates', 'dashboard.email-templates.index', NULL, 'Email Templates', 'tabler-mail', NULL, 65, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(193, NULL, 'onboarding_pro_extension', 'dashboard.admin.onboarding-pro.index', NULL, 'Onboarding Pro', 'tabler-message-circle', NULL, 65, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(194, NULL, 'onboarding', 'dashboard.admin.onboarding.index', NULL, 'Onboarding', 'tabler-directions', NULL, 65, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(195, NULL, 'mailchimp_newsletter', 'dashboard.admin.mailchimp-newsletter.index', NULL, 'Mailchimp Newsletter', 'tabler-mailbox', NULL, 65, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(196, NULL, 'hubspot', 'dashboard.admin.hubspot.index', NULL, 'Hubspot', 'tabler-affiliate', NULL, 65, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(197, NULL, 'api_integration', 'default', NULL, 'API Integration', 'tabler-api', NULL, 66, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:22', 0),
	(198, 197, 'api_integration_azure_openai', 'dashboard.admin.settings.azure-openai.index', NULL, 'Azure OpenAI', NULL, NULL, 67, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(199, 197, 'api_integration_openrouter', 'dashboard.admin.settings.open-router.show', NULL, 'Open Router', NULL, NULL, 74, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(200, 197, 'api_integration_ably', 'dashboard.admin.settings.ably', NULL, 'Ably Setting', NULL, NULL, 74, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(201, 197, 'api_integration_llama', 'dashboard.admin.settings.llama', NULL, 'Llama', NULL, NULL, 74, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(202, 197, 'api_integration_searchapi', 'dashboard.admin.settings.searchapi', NULL, 'Search Api', NULL, NULL, 74, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(203, 197, 'api_integration_openai', 'dashboard.admin.settings.openai', NULL, 'OpenAI', NULL, NULL, 67, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(204, 197, 'api_integration_gemini', 'dashboard.admin.settings.gemini', NULL, 'Gemini', NULL, NULL, 67, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(205, 197, 'api_integration_anthropic', 'dashboard.admin.settings.anthropic', NULL, 'Anthropic', NULL, NULL, 68, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(206, 197, 'api_integration_deepseek', 'dashboard.admin.settings.deepseek', NULL, 'Deepseek', NULL, NULL, 68, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(207, 197, 'api_integration_fal_ai', 'dashboard.admin.settings.fal-ai', NULL, 'Fal AI', NULL, NULL, 68, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:22', 0),
	(208, 197, 'api_integration_gamma_ai', 'dashboard.admin.settings.gamma-ai', NULL, 'Gamma AI', NULL, NULL, 68, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(209, 197, 'api_integration_creatify', 'dashboard.admin.settings.creatify', NULL, 'Creatify', NULL, NULL, 68, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(210, 197, 'api_integration_topview', 'dashboard.admin.settings.topview', NULL, 'Topview', NULL, NULL, 68, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(211, 197, 'api_integration_vizard', 'dashboard.admin.settings.vizard', NULL, 'Vizard', NULL, NULL, 68, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(212, 197, 'api_integration_klap', 'dashboard.admin.settings.klap', NULL, 'Klap', NULL, NULL, 68, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(213, 197, 'api_integration_piapi_ai', 'dashboard.admin.settings.piapi-ai', NULL, 'PiAPI', NULL, NULL, 69, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(214, 197, 'api_integration_stablediffusion', 'dashboard.admin.settings.stablediffusion', NULL, 'StableDiffusion', NULL, NULL, 69, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(215, 197, 'api_integration_unsplashapi', 'dashboard.admin.settings.unsplashapi', NULL, 'Unsplash', NULL, NULL, 70, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(216, 197, 'api_integration_pexelsapi', 'dashboard.admin.settings.pexelsapi', NULL, 'Pexels', NULL, NULL, 71, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(217, 197, 'api_integration_pixabayapi', 'dashboard.admin.settings.pixabayapi', NULL, 'Pixabay', NULL, NULL, 72, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(218, 197, 'api_integration_serperapi', 'dashboard.admin.settings.serperapi', NULL, 'Serper', NULL, NULL, 73, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(219, 197, 'api_integration_perplexity', 'dashboard.admin.settings.perplexity', NULL, 'Perplexity', NULL, NULL, 73, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(220, 197, 'api_integration_tts', 'dashboard.admin.settings.tts', NULL, 'TTS', NULL, NULL, 74, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(221, 197, 'api_integration_synthesia', 'dashboard.admin.settings.synthesia', NULL, 'Synthesia', NULL, NULL, 74, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(222, 197, 'api_integration_together', 'dashboard.admin.settings.together', NULL, 'Together', NULL, NULL, 74, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(223, 197, 'api_integration_heygen', 'dashboard.admin.settings.heygen', NULL, 'Heygen', NULL, NULL, 74, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(224, 197, 'api_integration_aimlapi', 'dashboard.admin.settings.aimlapi', NULL, 'Aimlapi', NULL, NULL, 74, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(225, 197, 'api_integration_pebblely', 'dashboard.admin.settings.pebblely', NULL, 'Pebblely', NULL, NULL, 74, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(226, 197, 'plagiarism_extension', 'dashboard.admin.settings.plagiarism', NULL, 'Plagiarism API', NULL, NULL, 77, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(227, NULL, 'settings', 'dashboard.admin.settings.general', NULL, 'Settings', 'tabler-device-laptop', NULL, 75, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(228, 227, 'config', 'dashboard.admin.config.index', NULL, 'General Settings', NULL, NULL, 0, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:21', 0),
	(229, NULL, 'live_customizer', 'dashboard.admin.live-customizer.setting', NULL, 'Live Customizer ', 'tabler-brush', NULL, 69, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(230, 227, 'thumbnail_system', 'dashboard.admin.settings.thumbnail', NULL, 'Thumbnail System', NULL, NULL, 79, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(231, 227, 'premium_advantages', 'dashboard.admin.config.premium-advantages.index', NULL, 'Premium Advantages', NULL, NULL, 79, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(232, 227, 'advanced_image_setting', 'dashboard.admin.settings.advanced-image.index', NULL, 'AI Image Editor Setting', NULL, NULL, 70, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(233, 227, 'privacy', 'dashboard.admin.settings.privacy', NULL, 'Privacy Policy and Terms', NULL, NULL, 82, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(234, NULL, 'site_health', 'dashboard.admin.health.index', NULL, 'Site Health', 'tabler-activity-heartbeat', NULL, 85, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(235, NULL, 'license', 'dashboard.admin.license.index', NULL, 'License', 'tabler-checklist', NULL, 86, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(236, NULL, 'update', 'dashboard.admin.update.index', NULL, 'Update', 'tabler-refresh', NULL, 87, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(237, NULL, 'menu_setting', 'dashboard.admin.menu.index', NULL, 'Menu', 'tabler-menu', NULL, 88, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(238, NULL, 'footer_menu_setting', 'dashboard.admin.footer-menu.index', NULL, 'Footer Menu', 'tabler-menu', NULL, 89, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(239, NULL, 'mega_menu_setting', 'dashboard.admin.mega-menu.index', NULL, 'Mega Menu', 'tabler-menu-2', NULL, 88, 1, '[]', 'item', NULL, NULL, 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(240, NULL, 'openai_generator_extension', 'default', NULL, 'Ai Template', 'tabler-list-details', NULL, 5, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(241, 240, 'custom_templates_extension', 'dashboard.user.ai-template.openai-generator.index', NULL, 'Custom Templates', NULL, NULL, 5, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(242, 240, 'ai_writer_categories_extension', 'dashboard.user.ai-template.openai-generator-filter.index', NULL, 'AI Writer Categories', NULL, NULL, 5, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(243, NULL, 'ai_plagiarism_extension', 'dashboard.user.openai.plagiarism.index', NULL, 'AI Plagiarism', 'tabler-progress-check', NULL, 6, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(244, NULL, 'ai_detector_extension', 'dashboard.user.openai.detectaicontent.index', NULL, 'AI Detector', 'tabler-text-scan-2', NULL, 6, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(245, NULL, 'ai_social_media_extension', 'dashboard.user.automation.index', NULL, 'AI Social Media', 'tabler-share', NULL, 6, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(246, NULL, 'scheduled_posts_extension', 'dashboard.user.automation.list', NULL, 'Social Media Posts', 'tabler-report', NULL, 6, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(247, 227, 'ai_social_media_settings_extension', 'dashboard.admin.automation.settings', NULL, 'AI Social Media Settings', NULL, NULL, 77, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(248, 227, 'ai_chat_pro_settings_extension', 'dashboard.admin.openai.chat.pro.settings', NULL, 'AI Chat Pro Settings', NULL, NULL, 77, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(249, 227, 'video_dubbing_settings_extension', 'dashboard.admin.video-dubbing.settings', NULL, 'Video Dubbing Settings', NULL, NULL, 78, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(250, 197, 'ai_captions_settings_extension', 'dashboard.admin.ai-captions.settings', NULL, 'AI Captions', NULL, NULL, 78, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(251, 227, 'ai_music_pro_settings_extension', 'dashboard.admin.ai-music-pro.settings', NULL, 'AI Music Pro Settings', NULL, NULL, 79, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(252, 227, 'ai_chat_pro_image_chat_settings_extension', 'dashboard.admin.ai-chat-pro-image-chat.settings', NULL, 'AI Chat Pro Image Chat Settings', NULL, NULL, 78, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(253, 227, 'ai_image_pro_settings_extension', 'dashboard.admin.ai-image-pro.settings', NULL, 'AI Image Pro Settings', NULL, NULL, 78, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(254, 227, 'social_media_agent_chat_settings_extension', 'dashboard.admin.social-media.agent.chat.settings', NULL, 'Social Media Agent Chat Settings', NULL, NULL, 78, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(255, 227, 'content_manager_extension', 'content-manager::settings', NULL, 'Content Manager Settings', NULL, NULL, 77, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(256, 227, 'social_media_settings_extension', 'dashboard.admin.social-media.setting.index', NULL, 'Social Media Platform Settings', NULL, NULL, 78, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(257, 227, 'chatbot_instagram_settings_extension', 'dashboard.admin.chatbot-instagram.settings.index', NULL, 'Instagram Chatbot Settings', NULL, NULL, 78, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(258, 227, 'chatbot_voice_call_settings_extension', 'dashboard.admin.settings.voice-call', NULL, 'Voice Call Settings', NULL, NULL, 79, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(259, 227, 'phone_call_agent_settings_extension', 'dashboard.phone-call-agent.admin.settings', NULL, 'Phone Call Agent Settings', NULL, NULL, 80, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(260, NULL, 'chat_settings_extension', 'default', NULL, 'Chat Settings', 'tabler-message-circle', NULL, 7, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(261, 260, 'chat_categories_extension', 'dashboard.user.chat-setting.chat-category.index', NULL, 'Chat Categories', NULL, NULL, 1, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(262, 260, 'chat_template_extension', 'dashboard.user.chat-setting.chat-template.index', NULL, 'Chat Templates', NULL, NULL, 2, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(263, 260, 'chat_training_extension', 'dashboard.user.chat-setting.chatbot.index', NULL, 'Chatbot Training', 'tabler-tags', NULL, 3, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:22', 0),
	(264, 227, 'cloudflare_r2_extension', 'dashboard.admin.settings.cloudflare-r2', NULL, 'Cloudflare R2', NULL, NULL, 1, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:21', 0),
	(265, NULL, 'photo_studio_extension', 'dashboard.user.photo-studio.index', NULL, 'AI Photoshoot', 'tabler-device-laptop', NULL, 8, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(266, NULL, 'seo_tool_extension', 'dashboard.user.seo.index', NULL, 'SEO Tool', 'tabler-seo', NULL, 10, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(267, NULL, 'ai_web_chat_extension', 'dashboard.user.openai.webchat.workbook', NULL, 'AI Web Chat', 'tabler-world-www', NULL, 10, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(268, 197, 'clipdrop_extension', 'dashboard.admin.settings.clipdrop', NULL, 'Clipdrop', NULL, NULL, 10, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(269, 227, 'creative_suite_settings', 'dashboard.admin.creative-suite.settings', NULL, 'Creative Suite Settings', NULL, NULL, 70, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(270, 197, 'novita_extension', 'dashboard.admin.settings.novita', NULL, 'Novita', NULL, NULL, 10, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(271, 197, 'freepik_extension', 'dashboard.admin.settings.freepik', NULL, 'Freepik', NULL, NULL, 10, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(272, 197, 'x_ai', 'dashboard.admin.settings.x-ai', NULL, 'X AI', NULL, NULL, 10, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(273, 197, 'xero_extension', 'dashboard.admin.settings.xero', NULL, 'Xero API', NULL, NULL, 10, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(274, 227, 'maintenance_setting', 'dashboard.admin.settings.maintenance.index', NULL, 'Maintenance', NULL, NULL, 2, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:21', 0),
	(275, 227, 'checkout_registration_extension', 'dashboard.admin.checkout.registration.settings.index', NULL, 'Checkout Registration', NULL, NULL, 9, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(276, 227, 'ext_ai_photo_studio_settings', 'dashboard.admin.ai-photoshoot.settings', NULL, 'AI Photoshoot Settings', NULL, NULL, 78, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(277, 227, 'ext_fashion_studio_settings', 'dashboard.admin.fashion-studio.settings', NULL, 'AI Fashion Studio Settings', NULL, NULL, 79, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(278, 227, 'ext_ugc_factory_settings', 'dashboard.admin.ugc-factory.settings', NULL, 'UGC Factory Settings', NULL, NULL, 80, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(279, 227, 'ext_ugc_creator_settings', 'dashboard.admin.ugc-creator.settings', NULL, 'UGC Creator Settings', NULL, NULL, 81, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(280, 227, 'marketing_bot_admin_settings', 'dashboard.admin.marketing-bot.settings.index', NULL, 'Marketing Bot Settings', NULL, NULL, 79, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(281, 227, 'ext_ai_agent_settings', 'dashboard.admin.ai-agent.settings', NULL, 'AI Agent Settings', NULL, NULL, 80, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(282, 227, 'ext_ai_agent_gmail_settings', 'dashboard.admin.ai-agent.gmail.settings', NULL, 'AI Agent - Gmail Settings', NULL, NULL, 81, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0),
	(283, 227, 'ext_ai_agent_outlook_settings', 'dashboard.admin.ai-agent.outlook.settings', NULL, 'AI Agent - Outlook Settings', NULL, NULL, 82, 1, '[]', 'item', NULL, '1', 0, NULL, NULL, NULL, NULL, '2026-07-24 08:58:20', '2026-07-24 08:58:20', 0);

-- Dumping structure for table magicai.migrations
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=453 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.migrations: ~0 rows (approximately)
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2014_01_01_000001_convert_db_tables_engines_from_myisam_to_innodb', 1),
	(2, '2014_10_12_000000_create_users_table', 1),
	(3, '2014_10_12_100000_create_password_reset_tokens_table', 1),
	(4, '2017_08_24_000000_create_app_settings_table', 1),
	(5, '2018_08_08_100000_create_telescope_entries_table', 1),
	(6, '2019_05_02_122941_create_plans_table', 1),
	(7, '2019_05_03_000001_create_customer_columns', 1),
	(8, '2019_05_03_000002_create_subscriptions_table', 1),
	(9, '2019_05_03_000003_create_subscription_items_table', 1),
	(10, '2019_08_19_000000_create_failed_jobs_table', 1),
	(11, '2019_12_14_000001_create_personal_access_tokens_table', 1),
	(12, '2023_03_01_113559_create_jobs_table', 1),
	(13, '2023_03_01_113611_create_settings_table', 2),
	(14, '2023_03_01_134013_create_user_orders_table', 2),
	(15, '2023_03_01_134144_create_user_support_table', 2),
	(16, '2023_03_01_134254_create_user_support_messages_table', 2),
	(17, '2023_03_10_100433_create_openai_table', 2),
	(18, '2023_03_14_073839_create_user_openai_table', 2),
	(19, '2023_03_20_115202_add_user_id_to_user_orders_table', 2),
	(20, '2023_03_20_134019_add_type_to_user_orders_table', 2),
	(21, '2023_03_21_123416_add_additional_fields_to_user_support_table', 2),
	(22, '2023_03_22_101116_add_paths_to_settings_table', 2),
	(23, '2023_03_22_104952_add_openai_settings_to_settings_table', 2),
	(24, '2023_03_30_000547_add_workbook_items_to_user_openai_table', 2),
	(25, '2023_04_01_235507_add_custom_template_fields_to_openai_table', 2),
	(26, '2023_04_12_223330_add_affiliate_to_users_table', 2),
	(27, '2023_04_13_175439_create_user_affiliates_table', 2),
	(28, '2023_04_13_175939_add_affiliate_to_settings_table', 2),
	(29, '2023_04_13_180614_add_affiliate_to_user_orders_table', 2),
	(30, '2023_04_24_115420_create_cache_table', 2),
	(31, '2023_04_24_144953_create_activity_table', 2),
	(32, '2023_04_28_110404_create_currencies_table', 2),
	(33, '2023_05_01_205543_add_frontend_fields_to_settings_table', 2),
	(34, '2023_05_03_103134_add_color_to_openai_table', 2),
	(35, '2023_05_03_103903_add_additional_fields_to_activity_table', 2),
	(36, '2023_05_03_105011_create_user_favorites_table', 2),
	(37, '2023_05_04_190611_add_version_to_settings_table', 2),
	(38, '2023_05_10_120704_create_openai_filters_table', 2),
	(39, '2023_05_10_120716_add_filters_to_openai_table', 2),
	(40, '2023_05_15_133018_create_openai_chat_category_table', 2),
	(41, '2023_05_15_140015_create_user_openai_chat_table', 2),
	(42, '2023_05_15_145853_create_user_openai_chat_messages_table', 2),
	(43, '2023_05_24_134923_add_collapsed_logo_path_to_settings_table', 2),
	(44, '2023_05_25_182410_add_email_confirmation_to_users_table', 2),
	(45, '2023_05_26_134701_add_stripe_status_for_now_to_settings_table', 2),
	(46, '2023_05_29_122817_create_faq_table', 2),
	(47, '2023_05_29_130259_create_testimonials_table', 2),
	(48, '2023_05_29_165555_create_frontend_tools_table', 2),
	(49, '2023_05_30_110811_create_howitworks_table', 2),
	(50, '2023_05_31_090418_create_customsettings_table', 2),
	(51, '2023_05_31_151447_create_clients_table', 2),
	(52, '2023_05_31_153647_add_new_logo_type_options', 2),
	(53, '2023_06_01_124212_create_frontend_footer_settings_table', 2),
	(54, '2023_06_01_140509_create_frontend_future_table', 2),
	(55, '2023_06_01_145426_create_gateways_table', 2),
	(56, '2023_06_02_124117_create_frontend_sections_statuses_titles_table', 2),
	(57, '2023_06_02_124736_create_frontend_who_is_for_table', 2),
	(58, '2023_06_02_124908_create_frontend_generators_table', 2),
	(59, '2023_06_05_131107_add_settings_columns_to_settings_table', 2),
	(60, '2023_06_06_094535_add_new_logo_options', 2),
	(61, '2023_06_06_100350_add_paid_with_to_subscriptions', 2),
	(62, '2023_06_06_133614_add_new_field_for_chat', 2),
	(63, '2023_06_07_124125_create_gatewayproducts_table', 2),
	(64, '2023_06_08_122900_add_hero_title_text_rotator_to_frontend_footer_settings_table', 2),
	(65, '2023_06_09_091144_add_keywords_columns_to_settings_table', 2),
	(66, '2023_06_09_102154_create_pages_table', 2),
	(67, '2023_06_12_091546_add_gdpr_option_to_settings_table', 2),
	(68, '2023_06_12_135232_add_menu_option_to_settings_table', 2),
	(69, '2023_06_14_104251_add_token_field_to_users_table', 2),
	(70, '2023_06_14_113746_add_google_refresh_token_to_users_table', 2),
	(71, '2023_06_14_114054_add_trial_days_field_to_plans_table', 2),
	(72, '2023_06_15_104503_create_oldgatewayproducts_table', 2),
	(73, '2023_06_15_110436_add_privacy_and_terms_column_to_settings_table', 2),
	(74, '2023_06_19_140133_add_login_without_confirmation_to_settings_table', 2),
	(75, '2023_06_20_084825_add_old_product_id_to_oldgatewayproducts', 2),
	(76, '2023_06_20_125836_add_header_buttons_to_frontend_footer_settings_table', 2),
	(77, '2023_06_21_135415_add_additional_option_to_settings_table', 2),
	(78, '2023_06_22_115805_add_customcode_to_settings_table', 2),
	(79, '2023_06_22_124915_add_free_plan_to_settings_table', 2),
	(80, '2023_06_22_133908_add_webhooks_to_gateways', 2),
	(81, '2023_06_23_091003_create_email_templates_table', 2),
	(82, '2023_06_23_141415_create_webhookhistory_table', 2),
	(83, '2023_06_26_140101_create_bad_words_table', 2),
	(84, '2023_07_01_080909_create_advertis_table', 2),
	(85, '2023_07_03_082326_add_column_to_frontend_sections_statuses_titles_table', 2),
	(86, '2023_07_07_103442_create_blogs_table', 2),
	(87, '2023_07_08_205833_create_settings_two_table', 2),
	(88, '2023_07_11_200235_add_license_type_to_settings_two', 2),
	(89, '2023_07_11_200310_add_liquid_license_domain_key_to_settings_two', 2),
	(90, '2023_07_13_133729_add_stream_server_option_to_settings_two_table', 2),
	(91, '2023_07_13_143413_add_blog_options_to_frontend_sections_statuses_titles', 2),
	(92, '2023_07_18_222043_add_image_storage_field_to_settings_two_table', 2),
	(93, '2023_07_19_105519_add_package_column_to_openai_table', 2),
	(94, '2023_07_21_121324_options_to_settingstwo_table', 2),
	(95, '2023_07_24_103747_create_subscriptions_yokassa_table', 2),
	(96, '2023_08_11_125732_create_paystack_payment_infos_table', 2),
	(97, '2023_08_14_073857_add_storage_to_user_openai_table', 2),
	(98, '2023_08_22_143604_add_iyzico_id_column_to_users', 2),
	(99, '2023_08_30_162502_create_ads_table', 2),
	(100, '2023_08_31_135312_change_facebook_token_type', 2),
	(101, '2023_09_11_130128_change_github_and_google_token_type', 2),
	(102, '2023_09_13_075321_add_stablediffusion_default_model_to_settings_two_table', 2),
	(103, '2023_09_19_064148_create_article_wizard_table', 2),
	(104, '2023_09_19_151726_create_coupons_table', 2),
	(105, '2023_09_20_140329_add_feature_ai_article_wizard_to_settings_table', 2),
	(106, '2023_09_20_174744_create_coupon_users_table', 2),
	(107, '2023_09_26_134837_create_privacy_terms_table', 2),
	(108, '2023_09_28_173820_add_hero_button_type_column_to_frontend_footer_settings', 2),
	(109, '2023_09_29_075552_add_floating_button_to_frontend_footer_settings', 2),
	(110, '2023_10_03_080002_add_unsplash_api_key_to_settings_two', 2),
	(111, '2023_11_17_051523_add_dalle_setting_to_settings_two', 2),
	(112, '2023_11_17_155039_create_folders_table', 2),
	(113, '2023_11_17_155940_add_folder_id_to_user_openai', 2),
	(114, '2023_11_27_052529_create_prompt_library_table', 2),
	(115, '2023_11_28_130925_add_favorite_plan_to_openai_chat_category_table', 2),
	(116, '2023_11_28_141010_create_chat_category_table', 2),
	(117, '2023_11_28_160244_add_category_to_openai_chat_category_table', 2),
	(118, '2023_11_29_060800_create_favourite_list_table', 2),
	(119, '2023_11_29_122715_create_rate_limits_table', 2),
	(120, '2023_11_30_084646_add_user_id_to_prompt_library', 2),
	(121, '2023_12_07_093902_add_display_to_plans', 2),
	(122, '2023_12_12_063333_add_feature_ai_vision_to_settings_table', 2),
	(123, '2023_12_13_071818_add_allowed_images_count_to_settings_two', 2),
	(124, '2023_12_13_124801_add_image_field_to_chat_messages', 2),
	(125, '2023_12_14_075424_change_content_column_in_pages_table', 2),
	(126, '2023_12_14_093837_create_pdf_data_table', 2),
	(127, '2023_12_15_003956_update_users_change_avatar_length', 2),
	(128, '2023_12_18_142047_add_pdf_info_to_chat_messages', 2),
	(129, '2023_12_18_145013_add_ai_pdf_to_chat_to_settings_table', 2),
	(130, '2023_12_19_085351_add_tax_to_gateways_table', 2),
	(131, '2023_12_21_080109_add_type_column_to_rate_limits_table', 2),
	(132, '2023_12_21_080333_add_allowed_voice_count_to_settings_two', 2),
	(133, '2023_12_22_085010_add_bot_output_image', 2),
	(134, '2023_12_25_212630_add_bank_details_to_gateways_table', 2),
	(135, '2023_12_28_021338_add_new_fields_to_subscriptions_table', 2),
	(136, '2023_12_28_040900_add_new_fields_to_user_orders_table', 2),
	(137, '2023_12_28_143354_add_ai_chat_image_field_to_settings_table', 2),
	(138, '2024_01_02_071044_add_auto_renewal_colmn_to_plans_table', 2),
	(139, '2024_01_04_073526_add_mobile_payment_active_column_to_settings_table', 2),
	(140, '2024_01_06_123827_add_revenuecat_id_column_to_users', 2),
	(141, '2024_01_11_091958_create_table_revenuecatproducts', 2),
	(142, '2024_01_15_152651_add_serperapi_colmn_to_settings_two_table', 2),
	(143, '2024_01_16_053948_add_tts_settings_to_settings_two_table', 2),
	(144, '2024_01_16_063552_add_realtime_colmn_to_user_openai_chat_messages_table', 2),
	(145, '2024_01_17_072456_create_extensions_table', 2),
	(146, '2024_01_17_075234_add_image_url_to_extensions', 2),
	(147, '2024_01_18_001456_add_detail_to_extensions', 2),
	(148, '2024_01_18_001457_add_licensed_to_extensions', 2),
	(149, '2024_01_22_074920_add_prize_to_table', 2),
	(150, '2024_01_22_134905_add_columns_to_subscriptions_yokassa_table', 2),
	(151, '2024_01_23_052857_add_ai_rewriter_to_table', 2),
	(152, '2024_01_23_143224_feature_ai_youtube_option', 2),
	(153, '2024_01_24_105005_feature_ai_rss_option', 2),
	(154, '2024_01_25_113135_fine_tune_list_data', 2),
	(155, '2024_01_25_120049_update_helps_with_column_in_openai_chat_category_table', 2),
	(156, '2024_01_26_110443_add_chatbot_table', 2),
	(157, '2024_01_29_081000_chatbot_settings', 2),
	(158, '2024_01_29_110158_add_apple_columns_to_user_table', 2),
	(159, '2024_01_29_143656_create_teams_table', 2),
	(160, '2024_01_29_143721_create_team_members_table', 2),
	(161, '2024_01_29_150757_chatbot_message_data', 2),
	(162, '2024_01_30_063632_add_team_id_to_users_table', 2),
	(163, '2024_01_30_064148_add_is_team_plan_and_plan_allow_seat_to_plans_table', 2),
	(164, '2024_01_30_081601_chatbot_chat_data', 2),
	(165, '2024_01_30_084904_chatbot_history', 2),
	(166, '2024_01_30_130737_add_team_function_add_settings_to_table', 2),
	(167, '2024_01_30_134710_add_team_id_to_user_openai_table', 2),
	(168, '2024_01_30_134807_add_team_id_to_user_openai_chat_table', 2),
	(169, '2024_01_30_135358_add_team_id_to_user_folders_table', 2),
	(170, '2024_02_01_130945_add_user_count_to_settings_table', 2),
	(171, '2024_02_06_095920_create_payment_proofs_table', 2),
	(172, '2024_02_06_172558_add_system_to_email_templates_table', 2),
	(173, '2024_02_08_192853_create_custom_biling_plans_table', 2),
	(174, '2024_02_09_064724_add_ai_advanced_editor_to_settings_table', 2),
	(175, '2024_02_14_085457_add_razorpay_id_column_to_users_table', 2),
	(176, '2024_02_14_124404_add_titlebar_status_to_pages_table', 2),
	(177, '2024_02_15_085457_add_url_to_user_openai_chat', 2),
	(178, '2024_02_15_100430_add_payload_to_gatewayproducts_table', 2),
	(179, '2024_02_15_111859_add_coingate_subscriber_id_to_users_table', 2),
	(180, '2024_02_15_132142_add_payload_to_user_orders_table', 2),
	(181, '2024_02_16_163955_create_elevenlab_voices_table', 2),
	(182, '2024_02_19_074856_add_payload_to_table_user_openai', 2),
	(183, '2024_02_19_172005_add_voice_clone_settings_table', 2),
	(184, '2024_02_19_175115_add_user_id_to_elevenlab_voices_table', 2),
	(185, '2024_02_20_101928_add_open_ai_items_to_plans_table', 2),
	(186, '2024_02_21_051626_add_free_open_ai_items_to_settings_table', 2),
	(187, '2024_02_21_064451_update_apple_token_column_from_user_table', 2),
	(188, '2024_02_21_100405_add_theme_column_to_settings_table', 2),
	(189, '2024_02_21_163100_add_chatbot_interests_to_chatbot_table', 2),
	(190, '2024_02_21_180426_add_status_to_chatbot_table', 2),
	(191, '2024_02_22_065844_create_chatbot_data_table', 2),
	(192, '2024_02_22_120600_create_chatbot_data_vectors_table', 2),
	(193, '2024_02_22_150925_add_chatbot_id_to_openai_chat_category_table', 2),
	(194, '2024_02_23_061429_add_chatbot_id_to_user_openai_chat_table', 2),
	(195, '2024_02_23_111745_add_user_api_option_to_settings_table', 2),
	(196, '2024_02_23_111834_add_api_keys_to_users_table', 2),
	(197, '2024_02_26_013354_add_ai_video_to_settings_two', 2),
	(198, '2024_02_26_184945_create_companies_table', 2),
	(199, '2024_02_26_185155_create_products_table', 2),
	(200, '2024_02_27_080913_add_reference_url_to_user_openai_chat', 2),
	(201, '2024_02_27_120732_add_is_custom_column_to_pages_table', 2),
	(202, '2024_02_27_134353_add_tone_of_voice_to_companies_table', 2),
	(203, '2024_02_28_084232_add_target_audience_column_to_companies_table', 2),
	(204, '2024_02_28_130323_add_user_id_to_chatbot_table', 2),
	(205, '2024_02_29_074747_chatbot_timestamp', 2),
	(206, '2024_03_04_070314_create_usage_table', 2),
	(207, '2024_03_05_085748_add_version_to_extensions_table', 2),
	(208, '2024_03_07_152339_create_intagrations_table', 2),
	(209, '2024_03_08_082441_create_user_integrations_table', 2),
	(210, '2024_03_08_112315_add_face_price_to_extensions_table', 2),
	(211, '2024_03_12_143138_add_auth_view_options_column_to_settings_table', 2),
	(212, '2024_03_14_061720_add_user_id_to_openai_filters_table', 2),
	(213, '2024_03_14_062605_add_user_id_to_openai_table', 2),
	(214, '2024_03_19_142411_add_instructions_to_openai_chat_category_table', 2),
	(215, '2024_03_19_151400_add_first_message_to_openai_chat_category_table', 2),
	(216, '2024_03_25_085453_add_theme_columns_to_extension_table', 2),
	(217, '2024_03_28_002018_create_user_docs_favorite_table', 2),
	(218, '2024_03_28_134851_add_to_token_to_users_table', 2),
	(219, '2024_03_29_212039_delete_column_from_extensions_table', 2),
	(220, '2024_04_02_063345_add_anthropic_api_keys_to_users_table', 2),
	(221, '2024_04_06_014025_change_columns_in_privacy_terms_table', 2),
	(222, '2024_04_09_191525_add_affiliate_status_to_users_table', 2),
	(223, '2024_04_18_121537_add_defi_setting_to_users_table', 2),
	(224, '2024_05_01_082729_add_gemini_api_keys_colmn_to_users_table', 2),
	(225, '2024_05_01_111455_add_google2fa_secret_to_users_table', 2),
	(226, '2024_05_03_094207_add_show_page_on_footer_to_pages_table', 2),
	(227, '2024_05_08_163635_create_photo_studios_table', 2),
	(228, '2024_05_15_100541_create_users_activity_table', 2),
	(229, '2024_05_16_092520_create_menus_table', 2),
	(230, '2024_05_21_091041_create_ai_models_table', 2),
	(231, '2024_05_21_091043_create_tokens_table', 2),
	(232, '2024_05_22_154814_change_integer_to_float_in_team_members', 2),
	(233, '2024_05_22_154827_change_integer_to_float_in_users', 2),
	(234, '2024_06_03_145735_create_gateway_taxes_table', 2),
	(235, '2024_06_04_032206_add_country_tax_enabled_to_gateways_table', 2),
	(236, '2024_06_07_064433_add_state_and_city_columns_to_users_table', 2),
	(237, '2024_06_13_132553_create_social_media_accounts_table', 2),
	(238, '2024_06_13_162318_add_hero_image_column_to_frontend_settings_table', 2),
	(239, '2024_06_14_124938_add_plan_description_column_to_plans_table', 2),
	(240, '2024_06_14_145824_create_account_deletion_reqs_table', 2),
	(241, '2024_06_18_062706_add_tool_subtitle_to_frontend_sections_statuses_titles_table', 2),
	(242, '2024_06_18_080246_add_some_fields_to_frontend_tools_table', 2),
	(243, '2024_06_18_082526_add_some_fields_to_howitworks_table', 2),
	(244, '2024_06_18_090439_add_icon_column_to_frontend_generators_table', 2),
	(245, '2024_06_24_074201_add_footer_text_color_to_frontend_footer_settings_table', 2),
	(246, '2024_06_24_141627_create_introductions_table', 2),
	(247, '2024_06_25_112300_create_notifications_table', 2),
	(248, '2024_06_25_131414_add_tour_seen_to_users_table', 2),
	(249, '2024_06_26_074715_add_custom_menu_to_menus_table', 2),
	(250, '2024_06_26_123911_add_tour_seen_to_settings_table', 2),
	(251, '2024_06_27_135525_add_recaptcha_to_settings_table', 2),
	(252, '2024_07_01_103008_add_otp_to_users_table', 2),
	(253, '2024_07_01_103139_add_otp_to_settings_table', 2),
	(254, '2024_07_04_120705_create_domains_table', 2),
	(255, '2024_07_05_112203_add_synthesia_secret_key_to_settings_table', 2),
	(256, '2024_07_05_122831_add_is_selected_to_ai_models_table', 2),
	(257, '2024_07_09_045618_create_ai_chat_model_plans_table', 2),
	(258, '2024_07_09_150801_add_dash_notify_seen_to_users_table', 2),
	(259, '2024_07_18_121143_add_stablediffusion_bedrock_model_to_settings_two_table', 2),
	(260, '2024_07_19_184746_add_cols_to_frontend_sections_statuses_titles_table', 2),
	(261, '2024_07_19_212020_create_advanced_features_sectoion_table', 2),
	(262, '2024_07_23_231136_create_comparison_section_items_table', 2),
	(263, '2024_07_24_111812_create_features_marquees_table', 2),
	(264, '2024_07_24_115747_create_footer_items_table', 2),
	(265, '2024_07_25_081052_create_banner_bottom_texts_table', 2),
	(266, '2024_07_25_084337_add_generator_text_to_frontend_sections_statuses_titles_table', 2),
	(267, '2024_07_25_100909_add_plan_footer_text_to_frontend_sections_statuses_titles', 2),
	(268, '2024_07_25_114952_add_advanced_features_title_to_frontend_sections_statuses_titles_table', 2),
	(269, '2024_07_25_120715_add_description_to_howitworks_table', 2),
	(270, '2024_07_25_131428_add_pebblely_key_to_settings_table', 2),
	(271, '2024_07_29_121039_create_pebblely_table', 2),
	(272, '2024_07_31_051243_add_plan_columns_to_plans_table', 2),
	(273, '2024_08_06_050052_add_default_ai_model_to_plans_table', 2),
	(274, '2024_08_06_115604_update_admin_to_super_admin_in_users_table', 2),
	(275, '2024_08_09_103631_add_ai_models_to_plans_table', 2),
	(276, '2024_08_12_050354_create_user_credits_table', 2),
	(277, '2024_08_12_141902_add_assistant_to_openai_chat_category_table', 2),
	(278, '2024_08_12_225618_add_thread_id_to_user_openai_chat_table', 2),
	(279, '2024_08_13_095658_remove_is_free_column_in_plans_table', 2),
	(280, '2024_08_14_050339_add_request_id_to_user_openai_table', 2),
	(281, '2024_08_16_105255_rollback_permission_table', 2),
	(282, '2024_09_02_120410_create_share_links_table', 2),
	(283, '2024_09_12_185443_add_default_mrrobot_words_to_settings', 2),
	(284, '2024_09_19_070942_add_bolt_menu_to_menus_table', 2),
	(285, '2024_09_19_110114_create_engines_table', 2),
	(286, '2024_09_19_211829_make_sure_to_remove_deprecated_entities_before_migration', 2),
	(287, '2024_09_19_245426_add_entity_credits_to_users_table', 2),
	(288, '2024_09_24_095546_update_ai_models_table', 2),
	(289, '2024_09_24_213419_rename_ai_models_to_entities_table', 2),
	(290, '2024_09_24_213999_remove_deprecated_stable_diff_models_from_db', 2),
	(291, '2024_09_24_214000_update_plan_credits_temporary_migration', 2),
	(292, '2024_09_24_220949_rename_ai_engine_column_in_entities_table', 2),
	(293, '2024_09_24_221029_rename_ai_model_id_column_in_ai_chat_model_plans_table', 2),
	(294, '2024_09_24_221030_make_ai_chat_model_plans_entity_id_foreign_key', 2),
	(295, '2024_09_25_125009_update_sd_values_in_app_settings_table', 2),
	(296, '2024_09_30_113752_rename_ai_model_id_column_in_token_table', 2),
	(297, '2024_10_14_082619_add_aimlapi_key_to_settings_table', 2),
	(298, '2024_10_17_124512_remove_free_plan_column_from_settings_table', 2),
	(299, '2024_10_22_154324_remove_plan_total_words_and_images_columns', 2),
	(300, '2024_10_25_095152_add_logo_to_settings_table', 2),
	(301, '2024_11_04_100122_create_permission_tables', 2),
	(302, '2024_11_04_101015_update_permission_table', 2),
	(303, '2024_11_18_102726_change_amount_col_in_user_affiliates_table', 2),
	(304, '2024_11_25_101434_create_health_check_result_history_items_table', 2),
	(305, '2024_11_26_094758_add_heygen_secret_key_to_settings_table', 2),
	(306, '2024_11_28_061918_add_automate_tax_to_gateways_table', 2),
	(307, '2024_12_03_145649_add_status_to_introductions_table', 2),
	(308, '2024_12_10_071444_add_user_api_to_plans_table', 2),
	(309, '2024_12_10_080148_delete_menu_icon_one_time_migration', 2),
	(310, '2024_12_16_074143_add_column_to_scheduled_posts_table', 2),
	(311, '2024_12_16_080709_add_hidden_to_plans_table', 2),
	(312, '2024_12_17_081626_add_index_to_user_openai', 2),
	(313, '2024_12_17_113420_remove_deprecated_runway_models_from_db', 2),
	(314, '2024_12_19_180117_change_prompt_column_to_user_fall_table', 2),
	(315, '2024_12_20_104536_add_status_to_photo_studios_table', 2),
	(316, '2025_01_02_123507_add_file_to_introductions_table', 2),
	(317, '2025_01_08_132515_add_parent_id_to_introduction_table', 2),
	(318, '2025_01_24_145331_add_reset_credits_on_renewal_column_to_plans_table', 2),
	(319, '2025_02_26_082114_add_xai_api_keys_to_users_table', 2),
	(320, '2025_03_04_215021_add_show_for_all_column_to_prompt_library_table', 2),
	(321, '2025_03_10_221327_remove_cost_per_token_column_from_tokens_table', 2),
	(322, '2025_03_13_140538_add_slug_column_to_email_templates_table', 2),
	(323, '2025_03_13_140539_add_payment_mail_templates_to_email_templates_table', 2),
	(324, '2025_03_17_111036_add_social_theme_frontend_setting_migration', 2),
	(325, '2025_03_18_050755_create_channel_settings_table', 2),
	(326, '2025_03_18_053123_create_content_boxes_table', 2),
	(327, '2025_03_18_053809_create_curtains_table', 2),
	(328, '2025_03_24_112325_add_is_pinned_to_user_openai_chat_table', 2),
	(329, '2025_04_08_100750_create_user_usage_credits_table', 2),
	(330, '2025_04_08_110336_add_openai_vector_and_file_id_columns_to_user_openai_chat', 2),
	(331, '2025_04_10_113919_create_referers_table', 2),
	(332, '2025_04_23_164215_create_dashboard_widgets_table', 2),
	(333, '2025_04_25_094959_add_last_activity_at_to_users_table', 2),
	(334, '2025_05_02_115019_fix_typo_in_dashboard_widgets', 2),
	(335, '2025_05_02_120212_change_name_in_dashboard_widgets', 2),
	(337, '2025_05_06_102938_2remove_gemini_deprected_models', 2),
	(338, '2025_05_21_151911_add_engine_and_model_columns_to_user_openai_table', 2),
	(339, '2025_05_21_154920_add_price_tax_included_colum_to_plans_table', 2),
	(340, '2025_06_08_102625_create_exported_videos_table', 2),
	(341, '2025_06_16_135944_add_plan_entity_credits_to_teams_table', 2),
	(342, '2025_06_20_214812_add_2checkout_customer_reference_colmn_to_users_table', 2),
	(343, '2025_06_25_062502_create_recent_search_keys_table', 2),
	(344, '2025_06_26_050421_add_is_demo_to_user_openai_table', 2),
	(345, '2025_07_10_110144_add_user_id_to_exported_videos', 2),
	(346, '2025_07_11_082144_change_testimonials_words_colmn_type_to_text', 2),
	(347, '2025_07_23_140424_add_specific_instructions_column_to_companies_table', 2),
	(348, '2025_07_29_102938_remove_gemini_deprected_models2', 2),
	(349, '2025_08_05_151726_add_is_offer_column_to_coupons_table', 2),
	(350, '2025_08_13_102938_remove_openai_deprected_models', 2),
	(351, '2025_08_13_160030_add_effort_col_to_entities_table', 2),
	(352, '2025_08_18_125426_add_duration_column_to_coupons_table', 2),
	(353, '2025_08_22_090439_add_access_type_column_to_openai_table', 2),
	(354, '2025_08_27_094648_add_is_empty_colmn_to_user_openai_chat_table', 2),
	(355, '2025_09_09_085800_add_support_multi_model_selection_colum_to_plans_table', 2),
	(356, '2025_09_25_141701_add_index_to_user_openai_table', 2),
	(357, '2025_09_26_131447_add_indexes_to_menus_table', 2),
	(358, '2025_09_26_131720_add_indexes_to_teams_table', 2),
	(359, '2025_09_26_132442_add_indexes_to_users_table', 2),
	(360, '2025_10_02_000001_add_voice_call_seconds_limit_to_plans', 2),
	(361, '2025_10_02_215339_make_name_and_surname_nullable_in_users_table', 2),
	(362, '2025_10_06_113800_add_active_title_index_to_openai_table', 2),
	(363, '2025_10_06_114224_add_user_status_index_to_subscriptions', 2),
	(364, '2025_10_06_114954_add_user_team_index_to_user_openai_table', 2),
	(365, '2025_10_06_141500_add_key_index_to_entities_table', 2),
	(366, '2025_10_06_142343_add_key_index_to_engines_table', 2),
	(367, '2025_10_13_212019_add_affiliate_status_column_to_plans_table', 2),
	(368, '2025_10_28_144500_add_offer_id_to_coupons_table', 2),
	(369, '2025_11_03_105055_move_frontend_additional_url_to_app_settings_table', 2),
	(370, '2025_11_20_055013_add_chatbot_limit_to_plans_table', 2),
	(371, '2025_12_16_085213_add_social_media_agent_limits_to_plans_table', 2),
	(372, '2026_01_15_142724_add_chat_type_to_user_openai_chat_table', 2),
	(373, '2026_01_15_145408_add_indexes_to_search_tables', 2),
	(374, '2026_02_23_093522_add_badge_to_menus_table', 2),
	(375, '2026_02_24_000003_add_model_council_support_to_plans_table', 2),
	(376, '2026_02_24_104644_add_blogpilot_limits_to_plans_table', 2),
	(377, '2026_02_27_053831_add_social_media_automation_limits_to_plans_table', 2),
	(378, '2026_03_04_090723_add_image_to_entities_table', 2),
	(379, '2026_03_11_110001_add_deep_research_request_limit_to_plans_table', 2),
	(380, '2026_03_17_000003_add_video_dubbing_seconds_limit_to_plans', 2),
	(381, '2026_03_26_005526_add_used_skills_to_user_openai_chat_messages_table', 2),
	(382, '2026_03_30_130008_add_marketing_bot_limits_to_plans_table', 2),
	(383, '2026_04_01_000001_add_shared_credit_columns', 2),
	(384, '2026_04_01_000002_create_shared_credit_transactions_table', 2),
	(385, '2026_04_01_000003_create_shared_credit_costs_table', 2),
	(386, '2026_04_01_123529_add_daily_shared_credit_limit_to_team_members_table', 2),
	(387, '2026_04_10_072705_drop_shared_credits_expires_at_from_users', 2),
	(388, '2026_04_28_131234_add_ai_agent_limits_to_plans_table', 2),
	(389, '2026_04_28_133202_add_ai_agent_memory_limit_to_plans_table', 2),
	(390, '2026_05_08_100003_add_ugc_videos_limit_to_plans_table', 2),
	(391, '2026_05_18_000002_add_ai_captions_columns_to_plans_table', 2),
	(392, '2026_05_19_000005_add_phone_call_agent_seconds_limit_to_plans', 2),
	(393, '2026_05_19_084654_add_language_to_elevenlab_voices_table', 2),
	(394, '2026_05_19_100003_add_ugc_creator_videos_limit_to_plans_table', 2),
	(395, '2026_05_22_113556_add_twilio_credentials_to_settings_two', 2),
	(396, '2026_06_05_105707_backfill_image_for_new_claude_opus_entities', 2),
	(397, '2026_06_12_153306_drop_ip_column_from_users_activity_table', 2),
	(398, '2026_06_25_115509_add_ai_chat_pro_connectors_to_plans', 2),
	(399, '2024_07_11_073517_add_website_url_to_user_openai_chat_table', 3),
	(400, '2024_07_11_073517_ai_plagiarism_migrations', 3),
	(401, '2024_07_11_073517_ai_writer_templates_migrations', 3),
	(402, '2024_07_11_073517_create_ai_realtime_images_table', 3),
	(403, '2024_07_11_073517_create_user_synthesia_table', 3),
	(404, '2024_07_11_073518_create_user_heygen_table', 3),
	(405, '2024_07_11_073520_add_sample_data_table', 3),
	(406, '2024_10_15_103143_create_user_music_table', 3),
	(407, '2024_10_21_101417_chatbot_avatars', 3),
	(408, '2024_10_21_101417_chatbot_migrations', 3),
	(409, '2024_10_21_133239_create_user_fall_table', 3),
	(410, '2024_10_29_075638_create_chatbot_embeddings_table', 3),
	(411, '2024_10_29_075639_add_model_role_to_chatbot_histories_table', 3),
	(412, '2024_10_29_075640_add_trigger_avatar_size_chatbots_table', 3),
	(413, '2024_10_29_075640_add_type_to_chatbot_embeddings_table', 3),
	(414, '2024_10_29_075640_change_logo_chatbots_table', 3),
	(415, '2024_10_29_133239_change_prompt_column_to_text_in_user_fall_table', 3),
	(416, '2024_11_04_101015_automation_campaigns_table', 3),
	(417, '2024_11_04_101015_automations_table', 3),
	(418, '2024_11_04_101015_linkedin_tokens_table', 3),
	(419, '2024_11_04_101015_scheduled_posts_table', 3),
	(420, '2024_11_04_101015_twitter_settings_table', 3),
	(421, '2024_11_04_101015_wordpress_migrations_table', 3),
	(422, '2024_11_04_101016_add_command_running_scheduled_posts_table', 3),
	(423, '2024_11_04_101016_add_index_scheduled_posts_table', 3),
	(424, '2024_12_10_101229_create_automation_platforms_table', 3),
	(425, '2024_12_10_103351_platform_migration', 3),
	(426, '2024_12_11_070409_add_automation_platform_id_to_scheduled_posts_table', 3),
	(427, '2025_01_15_170129_add_reg_sub_status_column_to_users_table', 3),
	(428, '2025_01_17_053015_change_logo_column_to_ext_chatbots_table', 3),
	(429, '2025_01_20_080747_add_footer_link_to_ext_chatbots_table', 3),
	(430, '2025_01_20_080747_advanced_image_migrations', 3),
	(431, '2025_01_20_080747_chatbot_agent_migrations', 3),
	(432, '2025_01_20_080747_chatbot_agent_new_migrations', 3),
	(433, '2025_01_20_080747_is_advanced_image_to_user_openai_table', 3),
	(434, '2025_01_23_073520_add_sample_data_table', 3),
	(435, '2025_01_24_145331_add_video_to_video_entities', 3),
	(436, '2025_01_24_145331_insert_video_to_video_data', 3),
	(437, '2025_02_13_153751_create_xero_tokens_table', 3),
	(438, '2025_02_13_153752_add_xero_account_id_to_users_table', 3),
	(439, '2025_03_24_170158_add_is_favorite_column_to_chabots_table', 3),
	(440, '2025_03_24_184920_create_announcements_table', 3),
	(441, '2025_04_10_101417_channel_type_to_chatbot_conversations_table', 3),
	(442, '2025_04_10_101417_chatbot_channel_id_add_chatbots', 3),
	(443, '2025_04_10_101417_chatbot_channel_webhooks', 3),
	(444, '2025_04_10_101417_chatbot_channels', 3),
	(445, '2025_04_10_101417_message_type_chatbot_histories_table', 3),
	(446, '2025_04_16_124323_add_realtime_image_style', 3),
	(447, '2025_04_16_124323_setting', 3),
	(448, '2025_04_20_101417_add_last_activity_at_to_chatbot_conversations', 3),
	(449, '2025_04_25_172415_add_is_demo_to_chatbots_table', 3),
	(450, '2025_05_05_102938_remove_gemini_deprected_models', 3),
	(451, '2025_04_16_073518_add_is_guest_column_to_user_openai_chat_table', 4),
	(452, '2025_06_03_073518_add_chatpro_support_to_ads_table', 4);

-- Dumping structure for table magicai.model_has_permissions
CREATE TABLE IF NOT EXISTS `model_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.model_has_permissions: ~0 rows (approximately)

-- Dumping structure for table magicai.model_has_roles
CREATE TABLE IF NOT EXISTS `model_has_roles` (
  `role_id` bigint unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.model_has_roles: ~0 rows (approximately)
INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
	(3, 'App\\Models\\User', 1);

-- Dumping structure for table magicai.notifications
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.notifications: ~0 rows (approximately)

-- Dumping structure for table magicai.oldgatewayproducts
CREATE TABLE IF NOT EXISTS `oldgatewayproducts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `plan_id` int NOT NULL DEFAULT '0',
  `plan_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gateway_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `old_price_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new_price_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `old_product_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.oldgatewayproducts: ~0 rows (approximately)

-- Dumping structure for table magicai.openai
CREATE TABLE IF NOT EXISTS `openai` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `questions` text COLLATE utf8mb4_unicode_ci,
  `image` text COLLATE utf8mb4_unicode_ci,
  `premium` tinyint(1) NOT NULL DEFAULT '0',
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `prompt` text COLLATE utf8mb4_unicode_ci,
  `custom_template` tinyint(1) NOT NULL DEFAULT '0',
  `tone_of_voice` tinyint(1) NOT NULL DEFAULT '0',
  `color` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filters` text COLLATE utf8mb4_unicode_ci,
  `package` text COLLATE utf8mb4_unicode_ci,
  `access_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'regular',
  PRIMARY KEY (`id`),
  KEY `openai_access_type_index` (`access_type`),
  KEY `idx_openai_active_title` (`active`,`title`)
) ENGINE=InnoDB AUTO_INCREMENT=159 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.openai: ~0 rows (approximately)
INSERT INTO `openai` (`id`, `user_id`, `title`, `description`, `slug`, `active`, `questions`, `image`, `premium`, `type`, `created_at`, `updated_at`, `prompt`, `custom_template`, `tone_of_voice`, `color`, `filters`, `package`, `access_type`) VALUES
	(1, NULL, 'Post Title Generator', 'Get captivating post titles instantly with our title generator. Boost engagement and save time.', 'post_title_generator', 1, '[{"name":"your_description","type":"textarea","question":"Description","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48"><path d="M430 896V356H200V256h560v100H530v540H430Z"/></svg>', 0, 'text', '2023-03-11 01:26:49', '2023-03-11 01:26:49', NULL, 0, 0, '#A3D6C2', 'blog', NULL, 'regular'),
	(2, NULL, 'Summarize Text', 'Effortlessly condense large text into shorter summaries. Save time and increase productivity.', 'summarize_text', 1, '[{"name":"text_to_summary","type":"textarea","question":"Text to summary","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48"><path d="M120 816v-60h480v60H120Zm0-210v-60h720v60H120Zm0-210v-60h720v60H120Z"/></svg>', 0, 'text', '2023-03-11 03:25:43', '2023-03-11 03:25:43', NULL, 0, 0, '#CCD9B8', 'blog', NULL, 'regular'),
	(3, NULL, 'Product Description', 'Easily create compelling product descriptions that sell. Increase conversions and boost sales.', 'product_description', 1, '[{"name":"product_name","type":"text","question":"Product Name","select":""},{"name":"description","type":"textarea","question":"Short Description","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48"><path d="M319 806h322v-60H319v60Zm0-170h322v-60H319v60Zm-99 340q-24 0-42-18t-18-42V236q0-24 18-42t42-18h361l219 219v521q0 24-18 42t-42 18H220Zm331-554h189L551 236v186Z"/></svg>', 0, 'text', '2023-03-11 03:30:40', '2023-03-11 03:30:40', NULL, 0, 0, '#C2DEDD', 'ecommerce', NULL, 'regular'),
	(4, NULL, 'Article Generator', 'Instantly create unique articles on any topic. Boost engagement, improve SEO, and save time.', 'article_generator', 1, '[{"name":"article_title","type":"text","question":"Article Title","select":""},{"name":"focus_keywords","type":"text","question":"Focus Keywords (Seperate with Comma)","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48"><path d="M140 936q-24.75 0-42.375-17.625T80 876V216l67 67 66-67 67 67 67-67 66 67 67-67 67 67 66-67 67 67 67-67 66 67 67-67v660q0 24.75-17.625 42.375T820 936H140Zm0-60h310V596H140v280Zm370 0h310V766H510v110Zm0-170h310V596H510v110ZM140 536h680V416H140v120Z"/></svg>', 0, 'text', '2023-03-11 03:36:10', '2023-03-11 03:36:10', NULL, 0, 0, '#A3D6C2', 'blog', NULL, 'regular'),
	(5, NULL, 'Product Name Generator', 'Create catchy product names with ease. Attract customers and boost sales effortlessly.', 'product_name', 1, '[{"name":"seed_words","type":"text","question":"Seed Words (Seperate With Comma)","select":""},{"name":"product_description","type":"textarea","question":"Product Description","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48"><path d="M290 896V356H80V256h520v100H390v540H290Zm360 0V556H520V456h360v100H750v340H650Z"/></svg>', 0, 'text', '2023-03-11 03:37:56', '2023-03-11 03:37:56', NULL, 0, 0, '#C2DEDD', 'ecommerce', NULL, 'regular'),
	(6, NULL, 'Testimonial Review', 'Instantly generate authentic testimonials. Build trust and credibility with genuine reviews.', 'testimonial_review', 1, '[{"name":"subject","type":"textarea","question":"Subject","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="40" viewBox="0 96 960 960" width="40"><path d="m233 976 65-281L80 506l288-25 112-265 112 265 288 25-218 189 65 281-247-149-247 149Z"/></svg>', 0, 'text', '2023-03-11 03:39:00', '2023-03-11 03:39:00', NULL, 0, 0, '#A3A7D6', 'ecommerce', NULL, 'regular'),
	(7, NULL, 'Problem Agitate Solution', 'Identify and solve problems efficiently. Streamline solutions and increase productivity.', 'problem_agitate_solution', 1, '[{"name":"description","type":"textarea","question":"Description","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48"><path d="m772 421-43-100-104-46 104-45 43-95 43 95 104 45-104 46-43 100Zm0 595-43-96-104-45 104-45 43-101 43 101 104 45-104 45-43 96ZM333 862l-92-197-201-90 201-90 92-196 93 196 200 90-200 90-93 197Zm0-148 48-96 98-43-98-43-48-96-47 96-99 43 99 43 47 96Zm0-139Z"/></svg>', 0, 'text', '2023-03-11 03:39:56', '2023-03-11 03:39:56', NULL, 0, 0, '#E0BFC9', 'development', NULL, 'regular'),
	(8, NULL, 'Blog Section', 'Effortlessly create blog sections with AI. Get unique, engaging content and save time.', 'blog_section', 1, '[{"name":"description","type":"textarea","question":"Description","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48"><path d="M180 936q-24.75 0-42.375-17.625T120 876V276q0-24.75 17.625-42.375T180 216h600q24.75 0 42.375 17.625T840 276v600q0 24.75-17.625 42.375T780 936H180Zm0-60h600V356H180v520Zm100-310v-60h390v60H280Zm0 160v-60h230v60H280Z"/></svg>', 0, 'text', '2023-03-11 03:40:50', '2023-03-11 03:40:50', NULL, 0, 0, '#A3D6C2', 'blog', NULL, 'regular'),
	(9, NULL, 'Blog Post Ideas', 'Unlock your creativity with unique blog post ideas. Generate endless inspiration and take your content to the next level.', 'blog_post_ideas', 1, '[{"name":"description","type":"textarea","question":"Description","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48"><path d="M360 896q-134 0-227-93T40 576q0-134 93-227t227-93q134 0 227 93t93 227q0 134-93 227t-227 93Zm-.235-60Q468 836 544 760.235q76-75.764 76-184Q620 468 544.235 392q-75.764-76-184-76Q252 316 176 391.765q-76 75.764-76 184Q100 684 175.765 760q75.764 76 184 76ZM330 706h60V506h80v-40H250v40h80v200Zm454-298-42-94-94-42 94-42 42-94 42 94 94 42-94 42-42 94Zm0 608-42-94-94-42 94-42 42-94 42 94 94 42-94 42-42 94ZM360 576Z"/></svg>', 0, 'text', '2023-03-11 03:41:31', '2023-03-11 03:41:31', NULL, 0, 0, '#A3D6C2', 'blog', NULL, 'regular'),
	(10, NULL, 'Blog Intros', 'Set the tone for your blog post with captivating intros. Grab readers\' attention and keep them engaged.', 'blog_intros', 1, '[{"name":"title","type":"text","question":"Title of blog text","select":""},{"name":"description","type":"textarea","question":"Description of your need","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48"><path d="M80 976v-60h800v60H80Zm210-450V426h380v100H290Zm0 240V666h380v100H290Z"/></svg>', 0, 'text', '2023-03-14 04:43:57', '2023-03-14 04:43:57', NULL, 0, 0, '#A3D6C2', 'blog', NULL, 'regular'),
	(11, NULL, 'Blog Conclusion', 'End your blog posts on a high note. Craft memorable conclusions that leave a lasting impact.', 'blog_conclusion', 1, '[{"name":"title","type":"text","question":"Title of the blog text","select":""},{"name":"description","type":"textarea","question":"Description","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48"><path d="M80 236v-60h800v60H80Zm210 250V386h380v100H290Zm0 240V626h380v100H290Z"/></svg>', 0, 'text', '2023-03-14 04:44:49', '2023-03-14 04:44:49', NULL, 0, 0, '#A3D6C2', 'blog', NULL, 'regular'),
	(12, NULL, 'Facebook Ads', 'Create high-converting Facebook ads that grab attention. Drive sales and grow your business.', 'facebook_ads', 1, '[{"name":"title","type":"text","question":"Title","select":""},{"name":"description","type":"textarea","question":"Description","select":""}]', '<svg width="9" height="16" viewBox="0 0 9 16" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path d="M5.66016 15.2383H2.88281V8.41797H0.5625V5.74609H2.88281V3.77734C2.88281 2.65234 3.19922 1.78516 3.83203 1.17578C4.46484 0.566406 5.30859 0.261719 6.36328 0.261719C7.20703 0.261719 7.89844 0.296875 8.4375 0.367188V2.72266L6.99609 2.75781C6.48047 2.75781 6.12891 2.86328 5.94141 3.07422C5.75391 3.28516 5.66016 3.60156 5.66016 4.02344V5.74609H8.33203L7.98047 8.41797H5.66016V15.2383Z" fill="#23344D"/>\n</svg>', 0, 'text', '2023-03-14 04:46:23', '2023-03-14 04:46:23', NULL, 0, 0, '#E8CEC3', 'advertisement', NULL, 'regular'),
	(13, NULL, 'Youtube Video Description', 'Elevate your YouTube content with compelling video descriptions. Generate engaging descriptions effortlessly and increase views.', 'youtube_video_description', 1, '[{"name":"title","type":"text","question":"Title","select":""}]', '<svg width="17" height="11" viewBox="0 0 17 11" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path d="M15.8301 2.76172C15.9473 3.58203 16.0059 4.39062 16.0059 5.1875V6.3125L15.8301 8.73828C15.7363 9.41797 15.5371 9.91016 15.2324 10.2148C14.9043 10.543 14.4121 10.7539 13.7559 10.8477C13.123 10.8945 12.3613 10.9297 11.4707 10.9531C10.6035 10.9766 9.88867 10.9883 9.32617 10.9883H8.48242C5.88086 10.9648 4.18164 10.918 3.38477 10.8477C3.38477 10.8477 3.29102 10.8359 3.10352 10.8125C2.91602 10.7891 2.76367 10.7656 2.64648 10.7422C2.5293 10.7188 2.37695 10.6602 2.18945 10.5664C2.02539 10.4727 1.87305 10.3555 1.73242 10.2148C1.61523 10.0742 1.49805 9.88672 1.38086 9.65234C1.28711 9.39453 1.22852 9.17188 1.20508 8.98438L1.13477 8.73828C1.04102 7.91797 0.994141 7.10938 0.994141 6.3125V5.1875L1.13477 2.76172C1.22852 2.08203 1.42773 1.58984 1.73242 1.28516C2.06055 0.933594 2.56445 0.722656 3.24414 0.652344C3.87695 0.605469 4.62695 0.570313 5.49414 0.546875C6.36133 0.523437 7.07617 0.511719 7.63867 0.511719H8.48242C10.5918 0.511719 12.3496 0.558594 13.7559 0.652344C14.4121 0.722656 14.9043 0.933594 15.2324 1.28516C15.3262 1.37891 15.4082 1.49609 15.4785 1.63672C15.5488 1.75391 15.6074 1.88281 15.6543 2.02344C15.7012 2.14062 15.7363 2.25781 15.7598 2.375C15.7832 2.49219 15.8066 2.58594 15.8301 2.65625V2.76172ZM10.5215 5.85547L11.0137 5.60938L6.9707 3.5V7.71875L10.5215 5.85547Z" fill="#23344D"/>\n</svg>', 0, 'text', '2023-03-14 04:47:17', '2023-03-14 04:47:17', NULL, 0, 0, '#E4CD9F', 'social media', NULL, 'regular'),
	(14, NULL, 'Youtube Video Title', 'Get more views with attention-grabbing video titles. Create unique, catchy titles that entice viewers.', 'youtube_video_title', 1, '[{"name":"description","type":"textarea","question":"Description","select":""}]', '<svg width="17" height="11" viewBox="0 0 17 11" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path d="M15.8301 2.76172C15.9473 3.58203 16.0059 4.39062 16.0059 5.1875V6.3125L15.8301 8.73828C15.7363 9.41797 15.5371 9.91016 15.2324 10.2148C14.9043 10.543 14.4121 10.7539 13.7559 10.8477C13.123 10.8945 12.3613 10.9297 11.4707 10.9531C10.6035 10.9766 9.88867 10.9883 9.32617 10.9883H8.48242C5.88086 10.9648 4.18164 10.918 3.38477 10.8477C3.38477 10.8477 3.29102 10.8359 3.10352 10.8125C2.91602 10.7891 2.76367 10.7656 2.64648 10.7422C2.5293 10.7188 2.37695 10.6602 2.18945 10.5664C2.02539 10.4727 1.87305 10.3555 1.73242 10.2148C1.61523 10.0742 1.49805 9.88672 1.38086 9.65234C1.28711 9.39453 1.22852 9.17188 1.20508 8.98438L1.13477 8.73828C1.04102 7.91797 0.994141 7.10938 0.994141 6.3125V5.1875L1.13477 2.76172C1.22852 2.08203 1.42773 1.58984 1.73242 1.28516C2.06055 0.933594 2.56445 0.722656 3.24414 0.652344C3.87695 0.605469 4.62695 0.570313 5.49414 0.546875C6.36133 0.523437 7.07617 0.511719 7.63867 0.511719H8.48242C10.5918 0.511719 12.3496 0.558594 13.7559 0.652344C14.4121 0.722656 14.9043 0.933594 15.2324 1.28516C15.3262 1.37891 15.4082 1.49609 15.4785 1.63672C15.5488 1.75391 15.6074 1.88281 15.6543 2.02344C15.7012 2.14062 15.7363 2.25781 15.7598 2.375C15.7832 2.49219 15.8066 2.58594 15.8301 2.65625V2.76172ZM10.5215 5.85547L11.0137 5.60938L6.9707 3.5V7.71875L10.5215 5.85547Z" fill="#23344D"/>\n</svg>', 0, 'text', '2023-03-14 04:49:10', '2023-03-14 04:49:10', NULL, 0, 0, '#E4CD9F', 'social media', NULL, 'regular'),
	(15, NULL, 'Youtube Video Tag', 'Improve your YouTube video\'s discoverability with relevant video tags. Boost views and engagement.', 'youtube_video_tag', 1, '[{"name":"title","type":"textarea","question":"Title","select":""}]', '<svg width="17" height="11" viewBox="0 0 17 11" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path d="M15.8301 2.76172C15.9473 3.58203 16.0059 4.39062 16.0059 5.1875V6.3125L15.8301 8.73828C15.7363 9.41797 15.5371 9.91016 15.2324 10.2148C14.9043 10.543 14.4121 10.7539 13.7559 10.8477C13.123 10.8945 12.3613 10.9297 11.4707 10.9531C10.6035 10.9766 9.88867 10.9883 9.32617 10.9883H8.48242C5.88086 10.9648 4.18164 10.918 3.38477 10.8477C3.38477 10.8477 3.29102 10.8359 3.10352 10.8125C2.91602 10.7891 2.76367 10.7656 2.64648 10.7422C2.5293 10.7188 2.37695 10.6602 2.18945 10.5664C2.02539 10.4727 1.87305 10.3555 1.73242 10.2148C1.61523 10.0742 1.49805 9.88672 1.38086 9.65234C1.28711 9.39453 1.22852 9.17188 1.20508 8.98438L1.13477 8.73828C1.04102 7.91797 0.994141 7.10938 0.994141 6.3125V5.1875L1.13477 2.76172C1.22852 2.08203 1.42773 1.58984 1.73242 1.28516C2.06055 0.933594 2.56445 0.722656 3.24414 0.652344C3.87695 0.605469 4.62695 0.570313 5.49414 0.546875C6.36133 0.523437 7.07617 0.511719 7.63867 0.511719H8.48242C10.5918 0.511719 12.3496 0.558594 13.7559 0.652344C14.4121 0.722656 14.9043 0.933594 15.2324 1.28516C15.3262 1.37891 15.4082 1.49609 15.4785 1.63672C15.5488 1.75391 15.6074 1.88281 15.6543 2.02344C15.7012 2.14062 15.7363 2.25781 15.7598 2.375C15.7832 2.49219 15.8066 2.58594 15.8301 2.65625V2.76172ZM10.5215 5.85547L11.0137 5.60938L6.9707 3.5V7.71875L10.5215 5.85547Z" fill="#23344D"/>\n</svg>', 0, 'text', '2023-03-14 04:50:15', '2023-03-14 04:50:15', NULL, 0, 0, '#E4CD9F', 'social media', NULL, 'regular'),
	(16, NULL, 'Instagram Captions', 'Elevate your Instagram game with captivating captions. Generate unique captions that engage followers and increase your reach.', 'instagram_captions', 1, '[{"name":"title","type":"textarea","question":"Title","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" data-name="Layer 1" viewBox="0 0 24 24" id="instagram"><path d="M17.34,5.46h0a1.2,1.2,0,1,0,1.2,1.2A1.2,1.2,0,0,0,17.34,5.46Zm4.6,2.42a7.59,7.59,0,0,0-.46-2.43,4.94,4.94,0,0,0-1.16-1.77,4.7,4.7,0,0,0-1.77-1.15,7.3,7.3,0,0,0-2.43-.47C15.06,2,14.72,2,12,2s-3.06,0-4.12.06a7.3,7.3,0,0,0-2.43.47A4.78,4.78,0,0,0,3.68,3.68,4.7,4.7,0,0,0,2.53,5.45a7.3,7.3,0,0,0-.47,2.43C2,8.94,2,9.28,2,12s0,3.06.06,4.12a7.3,7.3,0,0,0,.47,2.43,4.7,4.7,0,0,0,1.15,1.77,4.78,4.78,0,0,0,1.77,1.15,7.3,7.3,0,0,0,2.43.47C8.94,22,9.28,22,12,22s3.06,0,4.12-.06a7.3,7.3,0,0,0,2.43-.47,4.7,4.7,0,0,0,1.77-1.15,4.85,4.85,0,0,0,1.16-1.77,7.59,7.59,0,0,0,.46-2.43c0-1.06.06-1.4.06-4.12S22,8.94,21.94,7.88ZM20.14,16a5.61,5.61,0,0,1-.34,1.86,3.06,3.06,0,0,1-.75,1.15,3.19,3.19,0,0,1-1.15.75,5.61,5.61,0,0,1-1.86.34c-1,.05-1.37.06-4,.06s-3,0-4-.06A5.73,5.73,0,0,1,6.1,19.8,3.27,3.27,0,0,1,5,19.05a3,3,0,0,1-.74-1.15A5.54,5.54,0,0,1,3.86,16c0-1-.06-1.37-.06-4s0-3,.06-4A5.54,5.54,0,0,1,4.21,6.1,3,3,0,0,1,5,5,3.14,3.14,0,0,1,6.1,4.2,5.73,5.73,0,0,1,8,3.86c1,0,1.37-.06,4-.06s3,0,4,.06a5.61,5.61,0,0,1,1.86.34A3.06,3.06,0,0,1,19.05,5,3.06,3.06,0,0,1,19.8,6.1,5.61,5.61,0,0,1,20.14,8c.05,1,.06,1.37.06,4S20.19,15,20.14,16ZM12,6.87A5.13,5.13,0,1,0,17.14,12,5.12,5.12,0,0,0,12,6.87Zm0,8.46A3.33,3.33,0,1,1,15.33,12,3.33,3.33,0,0,1,12,15.33Z"></path></svg>', 0, 'text', '2023-03-14 04:50:52', '2023-03-14 04:50:52', NULL, 0, 0, '#E49FE1', 'social media', NULL, 'regular'),
	(17, NULL, 'Instagram Hashtags', 'Boost your Instagram reach with relevant hashtags. Generate optimal, trending hashtags and increase your visibility.', 'instagram_hashtag', 1, '[{"name":"keywords","type":"textarea","question":"Keywords (Separate with comma.)","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" data-name="Layer 1" viewBox="0 0 24 24" id="instagram"><path d="M17.34,5.46h0a1.2,1.2,0,1,0,1.2,1.2A1.2,1.2,0,0,0,17.34,5.46Zm4.6,2.42a7.59,7.59,0,0,0-.46-2.43,4.94,4.94,0,0,0-1.16-1.77,4.7,4.7,0,0,0-1.77-1.15,7.3,7.3,0,0,0-2.43-.47C15.06,2,14.72,2,12,2s-3.06,0-4.12.06a7.3,7.3,0,0,0-2.43.47A4.78,4.78,0,0,0,3.68,3.68,4.7,4.7,0,0,0,2.53,5.45a7.3,7.3,0,0,0-.47,2.43C2,8.94,2,9.28,2,12s0,3.06.06,4.12a7.3,7.3,0,0,0,.47,2.43,4.7,4.7,0,0,0,1.15,1.77,4.78,4.78,0,0,0,1.77,1.15,7.3,7.3,0,0,0,2.43.47C8.94,22,9.28,22,12,22s3.06,0,4.12-.06a7.3,7.3,0,0,0,2.43-.47,4.7,4.7,0,0,0,1.77-1.15,4.85,4.85,0,0,0,1.16-1.77,7.59,7.59,0,0,0,.46-2.43c0-1.06.06-1.4.06-4.12S22,8.94,21.94,7.88ZM20.14,16a5.61,5.61,0,0,1-.34,1.86,3.06,3.06,0,0,1-.75,1.15,3.19,3.19,0,0,1-1.15.75,5.61,5.61,0,0,1-1.86.34c-1,.05-1.37.06-4,.06s-3,0-4-.06A5.73,5.73,0,0,1,6.1,19.8,3.27,3.27,0,0,1,5,19.05a3,3,0,0,1-.74-1.15A5.54,5.54,0,0,1,3.86,16c0-1-.06-1.37-.06-4s0-3,.06-4A5.54,5.54,0,0,1,4.21,6.1,3,3,0,0,1,5,5,3.14,3.14,0,0,1,6.1,4.2,5.73,5.73,0,0,1,8,3.86c1,0,1.37-.06,4-.06s3,0,4,.06a5.61,5.61,0,0,1,1.86.34A3.06,3.06,0,0,1,19.05,5,3.06,3.06,0,0,1,19.8,6.1,5.61,5.61,0,0,1,20.14,8c.05,1,.06,1.37.06,4S20.19,15,20.14,16ZM12,6.87A5.13,5.13,0,1,0,17.14,12,5.12,5.12,0,0,0,12,6.87Zm0,8.46A3.33,3.33,0,1,1,15.33,12,3.33,3.33,0,0,1,12,15.33Z"></path></svg>', 0, 'text', '2023-03-14 04:52:48', '2023-03-14 04:52:48', NULL, 0, 0, '#E49FE1', 'social media', NULL, 'regular'),
	(18, NULL, 'Social Media Post Tweet', 'Make an impact with every tweet. Generate attention-grabbing social media posts and increase engagement.', 'social_media_post_tweet', 1, '[{"name":"title","type":"textarea","question":"Title","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" data-name="Layer 1" viewBox="0 0 24 24" id="twitter"><path d="M22,5.8a8.49,8.49,0,0,1-2.36.64,4.13,4.13,0,0,0,1.81-2.27,8.21,8.21,0,0,1-2.61,1,4.1,4.1,0,0,0-7,3.74A11.64,11.64,0,0,1,3.39,4.62a4.16,4.16,0,0,0-.55,2.07A4.09,4.09,0,0,0,4.66,10.1,4.05,4.05,0,0,1,2.8,9.59v.05a4.1,4.1,0,0,0,3.3,4A3.93,3.93,0,0,1,5,13.81a4.9,4.9,0,0,1-.77-.07,4.11,4.11,0,0,0,3.83,2.84A8.22,8.22,0,0,1,3,18.34a7.93,7.93,0,0,1-1-.06,11.57,11.57,0,0,0,6.29,1.85A11.59,11.59,0,0,0,20,8.45c0-.17,0-.35,0-.53A8.43,8.43,0,0,0,22,5.8Z"></path></svg>', 0, 'text', '2023-03-14 04:55:37', '2023-03-14 04:55:37', NULL, 0, 0, '#C2DEDE', 'social media', NULL, 'regular'),
	(19, NULL, 'Social Media Post Business', 'Generate a text for your business social media networks. Maximize your social media presence with impactful business posts.', 'social_media_post_business', 1, '[{"name":"company_name","type":"text","question":"Company Name","select":""},{"name":"description","type":"textarea","question":"Company Description","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48"><path d="M180 936q-24 0-42-18t-18-42V276q0-24 18-42t42-18h600q24 0 42 18t18 42v600q0 24-18 42t-42 18H180Zm100-160h200v-80H280v80Zm40-171 160-80 160 80V276H320v329Z"/></svg>', 0, 'text', '2023-03-14 05:04:56', '2023-03-14 05:04:56', NULL, 0, 0, '#E3E49F', 'social media', NULL, 'regular'),
	(20, NULL, 'Facebook Headlines', 'Get noticed with attention-grabbing Facebook headlines. Generate unique, clickable headlines that increase engagement and drive traffic.', 'facebook_headlines', 1, '[{"name":"title","type":"text","question":"Title","select":""},{"name":"description","type":"textarea","question":"Description","select":""}]', '<svg width="9" height="16" viewBox="0 0 9 16" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path d="M5.66016 15.2383H2.88281V8.41797H0.5625V5.74609H2.88281V3.77734C2.88281 2.65234 3.19922 1.78516 3.83203 1.17578C4.46484 0.566406 5.30859 0.261719 6.36328 0.261719C7.20703 0.261719 7.89844 0.296875 8.4375 0.367188V2.72266L6.99609 2.75781C6.48047 2.75781 6.12891 2.86328 5.94141 3.07422C5.75391 3.28516 5.66016 3.60156 5.66016 4.02344V5.74609H8.33203L7.98047 8.41797H5.66016V15.2383Z" fill="#23344D"/>\n</svg>', 0, 'text', '2023-03-14 05:06:05', '2023-03-14 05:06:05', NULL, 0, 0, '#E8CEC3', 'social media', NULL, 'regular'),
	(21, NULL, 'Google Ads Headlines', 'Create high-converting Google ads with captivating headlines. Generate unique, clickable ads that drive traffic and boost sales.', 'google_ads_headlines', 1, '[{"name":"product_name","type":"text","question":"Product Name","select":""},{"name":"description","type":"textarea","question":"Description","select":""},{"name":"audience","type":"select","question":"Audience","select":"\\n        <option value=\'everyone\'> Everyone </option>\\n        <option value=\'man\'> Man </option>\\n        <option value=\'woman\'> Woman </option>\\n        <option value=\'children\'> Children </option>\\n        <option value=\'teenager\'> Teenager </option>\\n        "}]', '<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" enable-background="new 0 0 32 32" viewBox="0 0 32 32" id="adwords"><path fill="#263238" d="M2.066 23.314c-.082 0-.166-.021-.242-.063-.242-.135-.329-.438-.194-.681L9.278 8.803c.134-.24.439-.326.68-.194.242.135.329.438.194.681L2.503 23.058C2.412 23.222 2.242 23.314 2.066 23.314zM9.933 27.686c-.082 0-.166-.021-.242-.063-.242-.135-.329-.438-.194-.681l4.796-8.634c.133-.24.438-.326.68-.194.242.135.329.438.194.681l-4.796 8.634C10.279 27.593 10.109 27.686 9.933 27.686z"></path><path fill="#263238" d="M15.709,15.761L9.497,26.942c-0.705,1.27-2.046,2.059-3.5,2.059c-0.674,0-1.345-0.175-1.939-0.505 c-1.928-1.07-2.625-3.511-1.554-5.438l7.578-13.639c0.134-0.241,0.047-0.546-0.194-0.681c-0.24-0.133-0.545-0.046-0.68,0.194 L1.629,22.571c-1.339,2.41-0.468,5.46,1.942,6.8c0.742,0.412,1.58,0.63,2.424,0.63c1.817,0,3.493-0.985,4.375-2.572 l5.921-10.658L15.709,15.761z"></path><path fill="#263238" d="M6 30c-2.757 0-5-2.243-5-5s2.243-5 5-5 5 2.243 5 5S8.757 30 6 30zM6 21c-2.206 0-4 1.794-4 4s1.794 4 4 4 4-1.794 4-4S8.206 21 6 21zM26.004 30.001c-1.817 0-3.493-.985-4.375-2.572l-10-18c-1.339-2.41-.468-5.46 1.942-6.8.742-.412 1.581-.631 2.425-.631 1.816 0 3.492.986 4.374 2.573l10 18c1.339 2.41.468 5.46-1.942 6.8C27.687 29.783 26.848 30.001 26.004 30.001zM15.997 2.998c-.675 0-1.345.175-1.94.506-1.928 1.07-2.625 3.511-1.554 5.438l10 18c.705 1.27 2.046 2.059 3.5 2.059.674 0 1.345-.175 1.939-.505 1.928-1.07 2.625-3.511 1.554-5.438l-10-18C18.792 3.787 17.451 2.998 15.997 2.998z"></path></svg>', 0, 'text', '2023-03-14 05:10:42', '2023-03-14 05:10:42', NULL, 0, 0, '#D6C0A3', 'advertisement', NULL, 'regular'),
	(22, NULL, 'Google Ads Description', 'Step up your Google ad game, Craft high-converting ad copy that grabs attention and drives sales.', 'google_ads_description', 1, '[{"name":"product_name","type":"text","question":"Product Name","select":""},{"name":"description","type":"textarea","question":"Description","select":""},{"name":"audience","type":"select","question":"Audience","select":"\\n        <option value=\'everyone\'> Everyone </option>\\n        <option value=\'man\'> Man </option>\\n        <option value=\'woman\'> Woman </option>\\n        <option value=\'children\'> Children </option>\\n        <option value=\'teenager\'> Teenager </option>\\n        "}]', '<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" enable-background="new 0 0 32 32" viewBox="0 0 32 32" id="adwords"><path fill="#263238" d="M2.066 23.314c-.082 0-.166-.021-.242-.063-.242-.135-.329-.438-.194-.681L9.278 8.803c.134-.24.439-.326.68-.194.242.135.329.438.194.681L2.503 23.058C2.412 23.222 2.242 23.314 2.066 23.314zM9.933 27.686c-.082 0-.166-.021-.242-.063-.242-.135-.329-.438-.194-.681l4.796-8.634c.133-.24.438-.326.68-.194.242.135.329.438.194.681l-4.796 8.634C10.279 27.593 10.109 27.686 9.933 27.686z"></path><path fill="#263238" d="M15.709,15.761L9.497,26.942c-0.705,1.27-2.046,2.059-3.5,2.059c-0.674,0-1.345-0.175-1.939-0.505 c-1.928-1.07-2.625-3.511-1.554-5.438l7.578-13.639c0.134-0.241,0.047-0.546-0.194-0.681c-0.24-0.133-0.545-0.046-0.68,0.194 L1.629,22.571c-1.339,2.41-0.468,5.46,1.942,6.8c0.742,0.412,1.58,0.63,2.424,0.63c1.817,0,3.493-0.985,4.375-2.572 l5.921-10.658L15.709,15.761z"></path><path fill="#263238" d="M6 30c-2.757 0-5-2.243-5-5s2.243-5 5-5 5 2.243 5 5S8.757 30 6 30zM6 21c-2.206 0-4 1.794-4 4s1.794 4 4 4 4-1.794 4-4S8.206 21 6 21zM26.004 30.001c-1.817 0-3.493-.985-4.375-2.572l-10-18c-1.339-2.41-.468-5.46 1.942-6.8.742-.412 1.581-.631 2.425-.631 1.816 0 3.492.986 4.374 2.573l10 18c1.339 2.41.468 5.46-1.942 6.8C27.687 29.783 26.848 30.001 26.004 30.001zM15.997 2.998c-.675 0-1.345.175-1.94.506-1.928 1.07-2.625 3.511-1.554 5.438l10 18c.705 1.27 2.046 2.059 3.5 2.059.674 0 1.345-.175 1.939-.505 1.928-1.07 2.625-3.511 1.554-5.438l-10-18C18.792 3.787 17.451 2.998 15.997 2.998z"></path></svg>', 0, 'text', '2023-03-14 05:11:58', '2023-03-14 05:11:58', NULL, 0, 0, '#D6C0A3', 'advertisement', NULL, 'regular'),
	(23, NULL, 'Paragraph Generator', 'Generate a paragraph with keywords and description. Never struggle with writer\'s block again. Generate flawless paragraphs that captivate readers.', 'paragraph_generator', 1, '[{"name":"description","type":"textarea","question":"Description","select":""},{"name":"keywords","type":"textarea","question":"Keywords (Separate with comma.)","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48"><path d="M160 684v-60h640v60H160Zm0 160v-60h640v60H160Zm0-316v-60h640v60H160Zm0-160v-60h640v60H160Z"/></svg>', 0, 'text', '2023-03-14 05:17:21', '2023-03-14 05:17:21', NULL, 0, 0, '#A3D6C2', 'blog', NULL, 'regular'),
	(24, NULL, 'Pros & Cons', 'Make informed decisions with ease. Generate unbiased pros and cons lists that help you weigh options and make better choices.', 'pros_cons', 1, '[{"name":"description","type":"textarea","question":"Description","select":""},{"name":"title","type":"text","question":"Title","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48"><path d="M443 936q-17 0-32-6.5T385 912L203 719l32-33q11-11 25-13.5t29 .5l114 25V276q0-26 17-43t43-17q26 0 43 17t17 43v240h36q11 0 19 1.5t17 6.5l163 82q24 12 36 35t8 49l-26 180q-5 29-28 47.5T696 936H443Zm-26-60h281l43-249-183-91h-55V316q0-18-11-29t-29-11q-18 0-29 11t-11 29v399l-154-33-23 23 171 171Zm0 0L246 705l23-23 154 33V316q0-18 11-29t29-11q18 0 29 11t11 29v220h55l183 91-43 249H417Z"/></svg>', 0, 'text', '2023-03-14 05:21:00', '2023-03-14 05:21:00', NULL, 0, 0, '#E0BFC9', 'development', NULL, 'regular'),
	(25, NULL, 'Meta Description', 'Get more clicks with compelling meta descriptions. Generate unique, SEO-friendly meta descriptions that attract customers and boost traffic.', 'meta_description', 1, '[{"name":"description","type":"textarea","question":"Description","select":""},{"name":"title","type":"text","question":"Title","select":""},{"name":"keywords","type":"text","question":"Keywords (Separate with comma)","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48"><path d="M319 806h322v-60H319v60Zm0-170h322v-60H319v60Zm-99 340q-24 0-42-18t-18-42V236q0-24 18-42t42-18h361l219 219v521q0 24-18 42t-42 18H220Zm331-554V236H220v680h520V422H551ZM220 236v186-186 680-680Z"/></svg>', 0, 'text', '2023-03-14 06:17:43', '2023-03-14 06:17:43', NULL, 0, 0, '#A3D6C2', 'development', NULL, 'regular'),
	(26, NULL, 'FAQ Generator (All Datas)', 'Quickly create helpful FAQs. Our AI-powered generator provides custom responses to common questions in seconds.', 'faq_generator', 1, '[{"name":"description","type":"textarea","question":"Description","select":""},{"name":"title","type":"text","question":"Title (Faq Question)","select":""}]', '<svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path d="M8.62695 5.87109C8.04102 6.45703 7.32617 6.75 6.48242 6.75C5.66211 6.75 4.95898 6.45703 4.37305 5.87109C3.78711 5.28516 3.49414 4.58203 3.49414 3.76172C3.49414 2.91797 3.78711 2.20313 4.37305 1.61719C4.95898 1.03125 5.66211 0.738281 6.48242 0.738281C7.32617 0.738281 8.04102 1.03125 8.62695 1.61719C9.21289 2.20313 9.50586 2.91797 9.50586 3.76172C9.50586 4.58203 9.21289 5.28516 8.62695 5.87109ZM4.05664 8.57812C4.94727 8.36719 5.75586 8.26172 6.48242 8.26172C7.23242 8.26172 8.05273 8.36719 8.94336 8.57812C9.83398 8.78906 10.6426 9.14062 11.3691 9.63281C12.1191 10.1016 12.4941 10.6406 12.4941 11.25V12.7617H0.505859V11.25C0.505859 10.6406 0.869141 10.1016 1.5957 9.63281C2.3457 9.14062 3.16602 8.78906 4.05664 8.57812Z" fill="#23344D"/>\n</svg>', 0, 'text', '2023-03-14 06:19:40', '2023-03-14 06:19:40', NULL, 0, 0, '#D6D2A3', 'development', NULL, 'regular'),
	(27, NULL, 'Email Generator', 'Generate an email with your subject and description. Streamline your inbox and save time.', 'email_generator', 1, '[{"name":"description","type":"textarea","question":"Description","select":""},{"name":"subject","type":"text","question":"Subject of Email","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48"><path d="M140 896q-24 0-42-18t-18-42V316q0-24 18-42t42-18h680q24 0 42 18t18 42v520q0 24-18 42t-42 18H140Zm340-302 340-223v-55L480 534 140 316v55l340 223Z"/></svg>', 0, 'text', '2023-03-14 06:22:21', '2023-03-14 06:22:21', NULL, 0, 0, '#D1C5DE', 'email', NULL, 'regular'),
	(28, NULL, 'Email Answer Generator', 'Effortlessly tackle your overflowing inbox with custom, accurate responses to common queries, freeing you up to focus on what matters most.', 'email_answer_generator', 1, '[{"name":"description","type":"textarea","question":"Description (Receieved Email)","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48"><path d="M140 896q-24 0-42-18t-18-42V316q0-24 18-42t42-18h680q24 0 42 18t18 42v520q0 24-18 42t-42 18H140Zm340-302 340-223v-55L480 534 140 316v55l340 223Z"/></svg>', 0, 'text', '2023-03-14 06:24:20', '2023-03-14 06:24:20', NULL, 0, 0, '#D1C5DE', 'email', NULL, 'regular'),
	(29, NULL, 'Newsletter Generator', 'Generate engaging newsletters easily with personalized content that resonates with your audience, driving growth and engagement.', 'newsletter_generator', 1, '[{"name":"description","type":"textarea","question":"Description","select":""},{"name":"title","type":"text","question":"Title","select":""},{"name":"subject","type":"text","question":"Subject","select":""}]', '<svg width="17" height="14" viewBox="0 0 17 14" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path d="M0.625 13.5V8.26172L11.875 6.75L0.625 5.23828V0L16.375 6.75L0.625 13.5Z" fill="#23344D"/>\n</svg>', 0, 'text', '2023-03-14 06:26:49', '2023-03-14 06:26:49', NULL, 0, 0, '#E1D5F4', 'email', NULL, 'regular'),
	(30, NULL, 'Grammar Correction', 'Eliminate grammar errors and enhance your writing with ease. Our tool offers seamless grammar correction for flawless content.', 'grammar_correction', 1, '[{"name":"description","type":"textarea","question":"Description","select":""}]', '<svg width="17" height="18" viewBox="0 0 17 18" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path d="M4.75586 8.01172V9.48828H0.255859V8.01172H4.75586ZM6.37305 5.58594L5.31836 6.64062L3.73633 5.02344L4.79102 3.96875L6.37305 5.58594ZM9.25586 0.488281V4.98828H7.74414V0.488281H9.25586ZM13.2637 5.02344L11.6816 6.64062L10.627 5.58594L12.209 3.96875L13.2637 5.02344ZM12.2441 8.01172H16.7441V9.48828H12.2441V8.01172ZM6.90039 7.16797C7.3457 6.72266 7.87305 6.5 8.48242 6.5C9.11523 6.5 9.6543 6.72266 10.0996 7.16797C10.5449 7.58984 10.7676 8.11719 10.7676 8.75C10.7676 9.38281 10.5449 9.92188 10.0996 10.3672C9.6543 10.7891 9.11523 11 8.48242 11C7.87305 11 7.3457 10.7891 6.90039 10.3672C6.47852 9.92188 6.26758 9.38281 6.26758 8.75C6.26758 8.11719 6.47852 7.58984 6.90039 7.16797ZM10.627 11.9141L11.6816 10.8594L13.2637 12.4766L12.209 13.5312L10.627 11.9141ZM3.73633 12.4766L5.31836 10.8594L6.37305 11.9141L4.79102 13.5312L3.73633 12.4766ZM7.74414 17.0117V12.5117H9.25586V17.0117H7.74414Z" fill="#23344D"/>\n</svg>', 0, 'text', '2023-03-14 06:29:15', '2023-03-14 06:29:15', NULL, 0, 0, '#D6C0A3', 'blog', NULL, 'regular'),
	(31, NULL, 'TL;DR Summarization', 'Automatically summarize long texts into bite-sized summaries with this TL;DR generator.', 'tldr_summarization', 1, '[{"name":"description","type":"textarea","question":"Description","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48"><path d="M160 666v-60h389v60H160Zm0-120v-60h640v60H160Z"/></svg>', 0, 'text', '2023-03-14 06:30:44', '2023-03-14 06:30:44', NULL, 0, 0, '#A3D6C2', 'blog', NULL, 'regular'),
	(32, NULL, 'AI Image Generator', 'Create stunning images in seconds.', 'ai_image_generator', 1, '[{"name":"description","type":"textarea","question":"Describe the Image","select":""},{"name":"size","type":"select","question":"Image Resolution","select":"<option value=\'256x256\'>256x256</option><option value=\'512x512\'>512x512</option><option value=\'1024x1024\'>1024x1024</option>"}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48"><path d="M180 936q-24 0-42-18t-18-42V276q0-24 18-42t42-18h600q24 0 42 18t18 42v600q0 24-18 42t-42 18H180Zm56-157h489L578 583 446 754l-93-127-117 152Z"/></svg>', 0, 'image', '2023-03-20 06:22:02', '2023-03-20 06:22:02', NULL, 0, 0, '#D1C5DE', 'development', NULL, 'regular'),
	(33, NULL, 'Custom Generation', 'Create your own custom generator with AI! Our app allows you to quickly and easily generate unique content in any language.', 'custom-generation-eQao5n', 1, '[{"name":"description","type":"textarea","question":"Description","description":"Description for prompt"},{"name":"description-second","type":"textarea","question":"Description Second","description":"Description Second for prompt"}]', '<svg xmlns="http://www.w3.org/2000/svg" height="40" viewBox="0 96 960 960" width="40"><path d="M424 962.333V705h93.666v83H860v93.666H517.666v80.667H424ZM99.667 881.666V788H372v93.666H99.667Zm178.667-178.333V622H99.667v-92.666h178.667v-82H372v255.999h-93.666ZM424 622v-92.666h436V622H424Zm163.667-175.667V189h93.666v81.334H860V364H681.333v82.333h-93.666ZM99.667 364v-93.666h436V364h-436Z"/></svg>', 0, 'text', '2023-04-04 14:49:28', '2023-05-12 07:49:22', 'write a text about   **description**  and  **description-second**', 1, 0, '#F4E8A4', 'Custom', NULL, 'regular'),
	(34, NULL, 'AI Speech to Text', 'The AI app that turns audio speech into text with ease.', 'ai_speech_to_text', 1, '[{"name":"file","type":"file","question":"Upload an Audio File (mp3, mp4, mpeg, mpga, m4a, wav, and webm)(Max: 25Mb)","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48"><path d="M140 976q-24.75 0-42.375-17.625T80 916V236q0-24.75 17.625-42.375T140 176h380l-60 60H140v680h480V776h60v140q0 24.75-17.625 42.375T620 976H140Zm100-170v-60h280v60H240Zm0-120v-60h200v60H240Zm380 10L460 536H320V336h140l160-160v520Zm60-92V258q56 21 88 74t32 104q0 51-35 101t-85 67Zm0 142v-62q70-25 125-90t55-158q0-93-55-158t-125-90v-62q102 27 171 112.5T920 436q0 112-69 197.5T680 746Z"/></svg>', 0, 'audio', '2023-04-08 12:30:04', '2023-05-09 08:38:40', NULL, 0, 0, '#DEFF81', 'blog', NULL, 'regular'),
	(35, NULL, 'AI Code Generator', 'Create custom code in seconds! Leverage our state-of-the-art AI technology to quickly and easily generate code in any language.', 'ai_code_generator', 1, '[{"name":"description","type":"textarea","question":"Describe What Kind of Code You Need","select":""},{"name":"code_language","type":"text","question":"Coding Language (Java, PHP etc.)","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="40" viewBox="0 96 960 960" width="40"><path d="M196.666 965.333q-43.824 0-74.912-31.087-31.087-31.088-31.087-74.912V701.667h105.999v157.667h157.667v105.999H196.666Zm409.001 0V859.334h157.667V701.667H870v157.667q0 43.824-31.284 74.912-31.283 31.087-75.382 31.087H605.667ZM344 739.333 180.667 576 344 412.667 418.333 489l-86 87 86 87L344 739.333Zm272 0L541.667 663l86-87-86-87L616 412.667 779.333 576 616 739.333Zm-525.333-289V292.666q0-44.099 31.087-75.382Q152.842 186 196.666 186h157.667v106.666H196.666v157.667H90.667Zm672.667 0V292.666H605.667V186h157.667q44.099 0 75.382 31.284Q870 248.567 870 292.666v157.667H763.334Z"/></svg>', 0, 'code', '2023-04-12 12:58:19', '2023-05-06 14:43:02', NULL, 0, 0, '#81FFC2', 'development', NULL, 'regular'),
	(36, NULL, 'AI Article Wizard Generator', 'Create custom article instantly with our article wizard generator. Boost engagement and save time.', 'ai_article_wizard_generator', 1, '[{"name":"your_description","type":"textarea","question":"Description","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48"><path d="M430 896V356H200V256h560v100H530v540H430Z"/></svg>', 0, 'text', '2023-09-20 01:26:49', '2023-09-20 01:26:49', NULL, 0, 0, '#A3D6C2', 'blog', NULL, 'regular'),
	(37, NULL, 'AI Vision', 'Elevate your visual analytics with our AI Vision platform. Harness the power of machine learning for real-time image recognition and data insights. Enhance efficiency and decision-making.', 'ai_vision', 1, '[{"name":"your_description","type":"textarea","question":"Description","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" \n width="48" height="48" stroke-width="2" stroke="black" fill="none" viewBox="0 0 24 24"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M6 4l6 16l6 -16" /></svg>', 0, 'text', '2023-09-20 01:26:49', '2023-09-20 01:26:49', NULL, 0, 0, '#A3D6C2', 'blog', NULL, 'regular'),
	(38, NULL, 'File Analyzer', 'Simply upload a file (PDF, CSV, .doc or .docx) and extract key insights or summarize the entire document.', 'ai_pdf', 1, '[{"name":"your_description","type":"textarea","question":"Description","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" \n width="48" height="48" stroke-width="2" stroke="black" fill="none" viewBox="0 0 24 24"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M6 4l6 16l6 -16" /></svg>', 0, 'text', '2023-09-20 01:26:49', '2023-09-20 01:26:49', NULL, 0, 0, '#A3D6C2', 'blog', NULL, 'regular'),
	(39, NULL, 'Chat Image', 'Generate Image by user input', 'ai_chat_image', 1, '[{"name":"your_description","type":"textarea","question":"Description","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" \n width="48" height="48" stroke-width="2" stroke="black" fill="none" viewBox="0 0 24 24"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M6 4l6 16l6 -16" /></svg>', 0, 'text', '2023-09-20 01:26:49', '2023-09-20 01:26:49', NULL, 0, 0, '#A3D6C2', 'blog', NULL, 'regular'),
	(40, NULL, 'AI ReWriter', 'Rewrite more professional and detailed content instantly with our ai rewriter. Boost engagement and save time.', 'ai_rewriter', 1, '[{"name":"your_description","type":"textarea","question":"Description","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48"><path d="M430 896V356H200V256h560v100H530v540H430Z"/></svg>', 0, 'text', '2023-09-20 01:26:49', '2023-09-20 01:26:49', NULL, 0, 0, '#A3D6C2', 'blog', NULL, 'regular'),
	(41, NULL, 'AI Web Chat', 'Analyze web page content with url', 'ai_webchat', 1, '[{"name":"your_description","type":"textarea","question":"Description","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" \n width="48" height="48" stroke-width="2" stroke="black" fill="none" viewBox="0 0 24 24"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M6 4l6 16l6 -16" /></svg>', 0, 'text', '2023-09-20 01:26:49', '2023-09-20 01:26:49', NULL, 0, 0, '#A3D6C2', 'blog', NULL, 'regular'),
	(42, NULL, 'AI Video', 'Bring your static images to life and create visually compelling videos effortlessly.', 'ai_video', 1, '[{"name":"your_description","type":"textarea","question":"Description","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" \n width="48" height="48" stroke-width="2" stroke="black" fill="none" viewBox="0 0 24 24"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M6 4l6 16l6 -16" /></svg>', 0, 'video', '2023-09-20 01:26:49', '2023-09-20 01:26:49', NULL, 0, 0, '#A3D6C2', 'video', NULL, 'regular'),
	(43, NULL, 'AI Voiceover', 'The AI app that turns text into audio speech with ease. Get ready to generate custom audios from texts quickly and accurately.', 'ai_voiceover', 1, '[{"name":"file","type":"file","question":"Upload an Audio File (mp3, mp4, mpeg, mpga, m4a, wav, and webm)(Max: 25Mb)","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48"><path d="M140 976q-24.75 0-42.375-17.625T80 916V236q0-24.75 17.625-42.375T140 176h380l-60 60H140v680h480V776h60v140q0 24.75-17.625 42.375T620 976H140Zm100-170v-60h280v60H240Zm0-120v-60h200v60H240Zm380 10L460 536H320V336h140l160-160v520Zm60-92V258q56 21 88 74t32 104q0 51-35 101t-85 67Zm0 142v-62q70-25 125-90t55-158q0-93-55-158t-125-90v-62q102 27 171 112.5T920 436q0 112-69 197.5T680 746Z"/></svg>', 0, 'voiceover', '2024-03-01 04:35:52', '2024-03-01 04:35:52', '', 0, 0, '#DEFF81', 'voiceover', NULL, 'regular'),
	(44, NULL, 'AI YouTube', 'Simply turn your Youtube videos into Blog post.', 'ai_youtube', 1, '[{"name":"url","type":"url","question":"YouTube Video URL","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#2c3e50" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M2 8a4 4 0 0 1 4 -4h12a4 4 0 0 1 4 4v8a4 4 0 0 1 -4 4h-12a4 4 0 0 1 -4 -4v-8z" /><path d="M10 9l5 3l-5 3z" /></svg>', 0, 'youtube', '2024-03-01 04:59:52', '2024-03-01 04:59:52', '', 0, 0, '#FFB0B0', 'youtube', NULL, 'regular'),
	(45, NULL, 'AI RSS', 'Generate unique content with RSS Feed.', 'ai_rss', 1, '[{"name":"rss_feed","type":"rss_feed","question":"URL","select":""},{"name":"title","type":"select","question":"Fetched Post Title","select":"<option value=\\"\\">Enter the Feed URL, please!</option>"}]', '<svg xmlns="http://www.w3.org/2000/svg" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#2c3e50" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M5 19m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" /><path d="M4 4a16 16 0 0 1 16 16" /><path d="M4 11a9 9 0 0 1 9 9" /></svg>', 0, 'rss', '2024-02-22 12:43:17', '2024-04-01 04:17:54', NULL, 0, 0, '#FF9E4D', 'rss', NULL, 'regular'),
	(46, NULL, 'AI Voice Isolator', 'Separate voices from background noise in audio recordings.', 'ai_voice_isolator', 1, '[{"name":"file","type":"file","question":"Upload an Audio File (mp3, mp4, mpeg, mpga, m4a, wav, and webm)(Max: 500Mb)","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48"><path d="M140 976q-24.75 0-42.375-17.625T80 916V236q0-24.75 17.625-42.375T140 176h380l-60 60H140v680h480V776h60v140q0 24.75-17.625 42.375T620 976H140Zm100-170v-60h280v60H240Zm0-120v-60h200v60H240Zm380 10L460 536H320V336h140l160-160v520Zm60-92V258q56 21 88 74t32 104q0 51-35 101t-85 67Zm0 142v-62q70-25 125-90t55-158q0-93-55-158t-125-90v-62q102 27 171 112.5T920 436q0 112-69 197.5T680 746Z"/></svg>', 0, 'isolator', '2026-07-24 08:58:24', '2026-07-24 08:58:24', '', 0, 0, '#DEFF81', 'voice', NULL, 'regular'),
	(47, NULL, 'AI Plagiarism Checker', 'Analyze text, comparing it against a vast database online content to identify potential plagiarism.', 'ai_plagiarism', 1, '[{\\"name\\":\\"your_description\\",\\"type\\":\\"textarea\\",\\"question\\":\\"Description\\",\\"select\\":\\"\\"}]', '<svg xmlns=\\"http://www.w3.org/2000/svg\\" height=\\"48\\" viewBox=\\"0 96 960 960\\" width=\\"48\\"><path d=\\"M430 896V356H200V256h560v100H530v540H430Z\\"/></svg>', 0, 'text', '2026-07-24 11:11:11', '2026-07-24 11:11:11', NULL, 0, 0, '#A3D6C2', 'blog', NULL, 'regular'),
	(48, NULL, 'AI Content Detector', 'Analylze text, comparing it against a vast database online content to AI writing content.', 'ai_content_detect', 1, '[{\\"name\\":\\"your_description\\",\\"type\\":\\"textarea\\",\\"question\\":\\"Description\\",\\"select\\":\\"\\"}]', '<svg xmlns=\\"http://www.w3.org/2000/svg\\" height=\\"48\\" viewBox=\\"0 96 960 960\\" width=\\"48\\"><path d=\\"M430 896V356H200V256h560v100H530v540H430Z\\"/></svg>', 0, 'text', '2026-07-24 11:11:11', '2026-07-24 11:11:11', NULL, 0, 0, '#A3D6C2', 'blog', NULL, 'regular'),
	(49, NULL, 'Cover Letter', 'Generate professional cover letters that highlight your strengths and stand out to employers.', 'cover_letter', 1, '[{"name":"job_title","type":"text","question":"Job Title","select":""},{"name":"company_name","type":"text","question":"Company Name","select":""},{"name":"your_name","type":"text","question":"Your Name","select":""},{"name":"your_skills","type":"textarea","question":"Your Skills","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48"><path d="M220 936q-24 0-42-18t-18-42V276q0-24 18-42t42-18h520q24 0 42 18t18 42v600q0 24-18 42t-42 18H220Zm0-60h520V276H220v600Zm70-120h160v-60H290v60Zm0-160h380v-60H290v60Zm0-160h380v-60H290v60ZM180 876V276v600Z"/></svg>', 0, 'text', '2023-03-11 03:43:50', '2023-03-11 03:43:50', 'Write a cover letter for the position of **job_title** at **company_name**. My name is **your_name** and my skills include **your_skills**.', 1, 0, '#D6A3A3', 'academic', NULL, 'regular'),
	(50, NULL, 'Math Question', 'Solve complex math questions with ease. Get step-by-step solutions and understand the process.', 'math_question', 1, '[{"name":"question","type":"textarea","question":"Math Question","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48"><path d="M180 836v-60h600v60H180Zm130-150-43-43 112-112-112-112 43-43 112 112 112-112 43 43-112 112 112 112-43 43-112-112-112 112Zm-130-270v-60h600v60H180Z"/></svg>', 0, 'text', '2023-03-11 03:45:20', '2023-03-11 03:45:20', 'Solve the following math question: **question**. Provide step-by-step solutions.', 1, 0, '#C2D6D6', 'academic', NULL, 'regular'),
	(51, NULL, 'Bullet Point Answer', 'Generate concise bullet point answers for any question. Save time and get straight to the point.', 'bullet_point_answer', 1, '[{"name":"question","type":"textarea","question":"Question","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48"><path d="M120 796v-60h480v60H120Zm0-170v-60h720v60H120Zm0-170v-60h720v60H120Zm0-170v-60h480v60H120Z"/></svg>', 0, 'text', '2023-03-11 03:46:35', '2023-03-11 03:46:35', 'Provide a bullet point answer for the following question: **question**.', 1, 0, '#D6C2C2', 'academic', NULL, 'regular'),
	(52, NULL, 'Academic Essay', 'Generate an academic essay based on the given topic and guidelines.', 'academic_essay', 1, '[{"name":"topic","type":"textarea","question":"Essay Topic","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48"><path d="M480 936q-57 0-108-21.5t-88.5-58Q246 819 224 768q-22-51-22-108t22-108q22-51 59-88.5T372 414q51-22 108-22t108 22q51 22 88.5 59T734 561q22 51 22 108t-22 108q-22 51-59 88.5T588 914q-51 22-108 22Zm0-60q43 0 80.5-16.5t65-44.5 44.5-65 16.5-80.5-16.5-80.5-44.5-65-65-44.5-80.5-16.5-80.5 16.5-65 44.5-44.5 65T180 768t16.5 80.5 44.5 65 65 44.5T480 876ZM308 626q-13 0-21.5-8.5T278 596q0-13 8.5-21.5T308 566h344q13 0 21.5 8.5T682 596q0 13-8.5 21.5T652 626H308Z"/></svg>', 0, 'text', '2024-05-15 03:00:00', '2024-05-15 03:00:00', 'Write an academic essay on the following topic: **topic**.', 1, 0, '#F1C40F', 'academic', NULL, 'regular'),
	(53, NULL, 'Thesis Statement', 'Generate a thesis statement for the given topic.', 'thesis_statement', 1, '[{"name":"topic","type":"textarea","question":"Thesis Topic","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48"><path d="M120 936V216h720v720H120Zm60-60h600V276H180v600ZM180 276v600-600Zm280 390h120v-60H460v60Zm0-120h120v-60H460v60Zm-60-120h240V306H400v120Zm-120 300h480v-60H280v60Z"/></svg>', 0, 'text', '2024-05-15 03:05:00', '2024-05-15 03:05:00', 'Generate a thesis statement for the following topic: **topic**.', 1, 0, '#27AE60', 'academic', NULL, 'regular'),
	(54, NULL, 'Proofreading', 'Proofread the given text and provide suggestions for improvement.', 'proofreading', 1, '[{"name":"text_to_proofread","type":"textarea","question":"Text to Proofread","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48"><path d="M480 936q-65 0-122-25t-100-67.5T196.5 743 172 621V396q0-91 60-155.5T396 180v60q-65 0-111.5 46.5T238 396v225q0 74 37 138t100 102q60 24 133 24 70 0 130-27.5t101.5-75.5q40-47 62.5-107T840 396h60q0 80-24 153.5T837 660q-38 60-92 103.5T629 843t-149 93Zm-46-197 310-310-42-42-268 268-113-113-42 42 155 155ZM396 460Z"/></svg>', 0, 'text', '2024-05-15 03:10:00', '2024-05-15 03:10:00', 'Proofread the following text and provide suggestions for improvement: **text_to_proofread**.', 1, 0, '#3498DB', 'academic', NULL, 'regular'),
	(55, NULL, 'Rephrase', 'Rephrase the given text to improve clarity and readability.', 'rephrase', 1, '[{"name":"text_to_rephrase","type":"textarea","question":"Text to Rephrase","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48"><path d="M460 936q-62 0-120-18t-106-52q-48-34-86-84.5T78 662q-12-39-16-80.5T60 502q0-43 4-84.5T82 341q12-34 29-62.5T132 233q-17 39-29.5 82T90 418q-1 16-1 34t1 34q2 30 10.5 60.5T128 579q30 49 73 83t92 55.5T460 726q38 0 74.5-9t68.5-25v70q-33 14-69.5 21T460 792q-53 0-103-14.5t-95.5-40q-46-25-82.5-62t-62-82.5T92 502q-3-13-3-27.5t3-27.5q2-12 6-23.5t9-23.5q12-28 30-53t40-44q27-26 57.5-46.5T366 221q37-18 75-25t78-7v58q-40 2-80 10t-75 24q-30 12-57.5 29.5T250 335q-20 19-36.5 41.5T194 423q-11 23-17 47.5T170 517q-1 16-1 34t1 34q2 30 10.5 60.5T238 699q29 49 72 82.5t92 54T460 848q38 0 75.5-10t68.5-26v56q-31 12-64 17.5T460 936ZM704 348q-53 0-103-14.5t-95.5-40q-46-25-82.5-62T348 149.5 286 103q-3-13-3-27.5T286 48q12-47 37-87.5T408 0h132q22 0 43 3.5t41 9.5q49 12 91 33t73 53q23 20 43 44.5t33 53.5q12 28 20 57.5T980 316q0 33-3.5 66t-11.5 64q-12 45-31 86.5t-48 77.5q-31 34-68 59.5t-83 42q-41 14-82 17.5t-84 3.5q-34 0-67-3t-66-12V746q31 10 63 15.5t64 7.5q31 0 60.5-3t59.5-12q39-14 72-34t58-48q26-22 46.5-47t35.5-51q12-25 21.5-51.5T832 496q-2-17-2-34t2-34q2-30 11-60.5T896 272q29-49 72-83t92-54.5T1116 96q53 0 103 14.5t95.5 40q46 25 82.5 62t62 82.5T1580 478q12 39 16 80.5t4 80.5q0 43-4 84.5t-12 80.5q-12 34-29 62.5T1498 695q17-39 29.5-82T1540 548q1-16 1-34t-1-34q-2-30-10.5-60.5T1442 367q-30-49-73-83t-92-55.5T704 258Z"/></svg>', 0, 'text', '2024-05-15 03:15:00', '2024-05-15 03:15:00', 'Rephrase the following text to improve clarity and readability: **text_to_rephrase**.', 1, 0, '#9B59B6', 'academic', NULL, 'regular'),
	(56, NULL, 'Improve', 'Improve the given text by enhancing its quality and clarity.', 'improve', 1, '[{"name":"text_to_improve","type":"textarea","question":"Text to Improve","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 96 960 960" width="48"><path d="M480 936q-57 0-108-21.5t-88.5-58q-39-37.5-62-89t-23-107.5V378q0-91 60-155.5T396 180v60q-65 0-111.5 46.5T238 396v225q0 74 37 138t100 102q60 24 133 24 70 0 130-27.5t101.5-75.5q40-47 62.5-107T840 396h60q0 80-24 153.5T837 660q-38 60-92 103.5T629 843t-149 93ZM228 514q-4-4-6-10t-2-11q0-6 2-11t6-10l292-293q4-4 10-6t11-2q6 0 11 2t10 6l293 293q4 4 6 10t2 11q0 6-2 11t-6 10q-4 4-10 6t-11 2q-6 0-11-2t-10-6L480 306 238 514q-4 4-10 6t-11 2q-6 0-11-2t-10-6Z"/></svg>', 0, 'text', '2024-05-15 03:20:00', '2024-05-15 03:20:00', 'Improve the following text by enhancing its quality and clarity: **text_to_improve**.', 1, 0, '#1ABC9C', 'academic', NULL, 'regular'),
	(57, NULL, 'Job Description', 'Generate comprehensive job descriptions tailored to your company needs.', 'job_description', 1, '[{"name":"job_title","type":"text","question":"Job Title","select":""},{"name":"company_name","type":"text","question":"Company Name","select":""},{"name":"job_description","type":"textarea","question":"Job Description","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 0 24 24" width="48"><path d="M0 0h24v24H0z" fill="none"/><path d="M15 8V4H5c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V9c0-1.1-.9-2-2-2h-4z"/><path d="M17 8h-4V4h4v4zm-2-2v-1H9v1h6zM19 18H5V9h14v9zm0-10H5V6h14v2z"/></svg>', 0, 'text', '2024-05-15 01:00:00', '2024-05-15 01:00:00', 'Generate a comprehensive job description for the role of **job_title** at **company_name**.', 1, 0, '#D6A3A3', 'business', NULL, 'regular'),
	(58, NULL, 'Application Letter', 'Craft personalized application letters that grab attention and highlight your qualifications.', 'application_letter', 1, '[{"name":"job_title","type":"text","question":"Job Title","select":""},{"name":"company_name","type":"text","question":"Company Name","select":""},{"name":"your_name","type":"text","question":"Your Name","select":""},{"name":"your_qualifications","type":"textarea","question":"Your Qualifications","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 0 24 24" width="48"><path d="M0 0h24v24H0z" fill="none"/><path d="M5 4v16h14V4H5zm12 14H7V6h10v12z"/></svg>', 0, 'text', '2024-05-15 01:00:00', '2024-05-15 01:00:00', 'Craft a personalized application letter for the position of **job_title** at **company_name**. Highlight your qualifications, experiences, and reasons for applying. My name is **your_name** and my qualifications include **your_qualifications**.', 1, 0, '#C2D6D6', 'business', NULL, 'regular'),
	(59, NULL, 'Resume Builder', 'Create professional resumes tailored to your skills and experience.', 'resume_builder', 1, '[{"name":"your_name","type":"text","question":"Your Name","select":""},{"name":"your_skills","type":"textarea","question":"Your Skills","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 0 24 24" width="48"><path d="M0 0h24v24H0z" fill="none"/><path d="M19 5v14H5V5h14m0-2H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z"/><path d="M7 10h10v2H7zM7 14h10v2H7z"/></svg>', 0, 'text', '2024-05-15 01:00:00', '2024-05-15 01:00:00', 'Create a professional resume highlighting your skills and experiences. My name is **your_name** and my skills include **your_skills**.', 1, 0, '#D6C2C2', 'business', NULL, 'regular'),
	(60, NULL, 'Linkedin', 'Generate engaging LinkedIn profile descriptions that attract attention from employers and connections.', 'linkedin', 1, '[{"name":"your_name","type":"text","question":"Your Name","select":""},{"name":"your_title","type":"text","question":"Your Title","select":""},{"name":"your_summary","type":"textarea","question":"Your Summary","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 0 24 24" width="48"><path d="M0 0h24v24H0z" fill="none"/><path d="M3 4v16h18V4H3zm16 14H5V6h14v12zm-6-3v-1h3v1h-3zM7 11h10v1H7v-1z"/></svg>', 0, 'text', '2024-05-15 01:00:00', '2024-05-15 01:00:00', 'Generate an engaging LinkedIn profile description for **your_name**, **your_title**. Provide a summary that attracts attention from employers and connections. **your_summary**.', 1, 0, '#C2D6D6', 'business', NULL, 'regular'),
	(61, NULL, 'Startup Ideas (w/ quantities)', 'Generate innovative startup ideas along with estimated quantities and market analysis.', 'startup_ideas', 1, '[{"name":"keywords","type":"textarea","question":"Keywords","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 0 24 24" width="48"><path d="M0 0h24v24H0z" fill="none"/><path d="M5 2v2H3v2h2v2h2V6h2V4H5zm12 0v2h4v4h2V6h2V4h-2V2h-2zm-4 4h2v4h-2zm4 4h2v4h-2zm-4 0h2v4h-2zm-6 6h2v2H7v-2zm4 0h2v2h-2zm4 0h2v2h-2zm4 0h2v2h-2zm-12 2h2v2H3v-2zm8 0h2v2h-2zm4 0h2v2h-2z"/></svg>', 0, 'text', '2024-05-15 01:00:00', '2024-05-15 01:00:00', 'Generate innovative startup ideas based on the provided keywords \'**keywords**\'. Identify market opportunities, target audience, and potential business models.', 1, 0, '#D6A3A3', 'business', NULL, 'regular'),
	(62, NULL, 'PAS', 'Generate Persuasion-Awareness-Solution (PAS) frameworks for persuasive communication strategies.', 'pas', 1, '[{"name":"pain","type":"textarea","question":"Pain","select":""},{"name":"agitation","type":"textarea","question":"Agitation","select":""},{"name":"solution","type":"textarea","question":"Solution","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 0 24 24" width="48"><path d="M0 0h24v24H0z" fill="none"/><path d="M5 2v2H3v2h2v2h2V6h2V4H5zm12 0v2h4v4h2V6h2V4h-2V2h-2zm-4 4h2v4h-2zm4 4h2v4h-2zm-4 0h2v4h-2zm-6 6h2v2H7v-2zm4 0h2v2h-2zm4 0h2v2h-2zm4 0h2v2h-2zm-12 2h2v2H3v-2zm8 0h2v2h-2zm4 0h2v2h-2z"/></svg>', 0, 'text', '2024-05-15 01:00:00', '2024-05-15 01:00:00', 'Create Problem-Agitate-Solution (PAS) frameworks for effective marketing campaigns. Identify the pain point \'**pain**\', agitate the problem \'**agitation**\', and present the solution \'**solution**\'.', 1, 0, '#D6A3A3', 'business', NULL, 'regular'),
	(63, NULL, 'AIDA', 'Create Attention-Interest-Desire-Action (AIDA) frameworks for effective marketing campaigns.', 'aida', 1, '[{"name":"attention","type":"textarea","question":"Attention","select":""},{"name":"interest","type":"textarea","question":"Interest","select":""},{"name":"desire","type":"textarea","question":"Desire","select":""},{"name":"action","type":"textarea","question":"Action","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 0 24 24" width="48"><path d="M0 0h24v24H0z" fill="none"/><path d="M15 8V4H5c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V9c0-1.1-.9-2-2-2h-4z"/><path d="M17 8h-4V4h4v4zm-2-2v-1H9v1h6zM19 18H5V9h14v9zm0-10H5V6h14v2z"/></svg>', 0, 'text', '2024-05-15 01:00:00', '2024-05-15 01:00:00', 'Develop Attention-Interest-Desire-Action (AIDA) frameworks for marketing strategies. Capture attention with \'**attention**\', generate interest with \'**interest**\', create desire with \'**desire**\', and prompt action with \'**action**\'.', 1, 0, '#C2D6D6', 'business', NULL, 'regular'),
	(64, NULL, 'Strategy', 'Generate strategic plans and frameworks for business development and growth.', 'strategy', 1, '[{"name":"keywords","type":"textarea","question":"Keywords","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 0 24 24" width="48"><path d="M0 0h24v24H0z" fill="none"/><path d="M3 4v16h18V4H3zm16 14H5V6h14v12zm-6-3v-1h3v1h-3zM7 11h10v1H7v-1z"/></svg>', 0, 'text', '2024-05-15 01:00:00', '2024-05-15 01:00:00', 'Develop strategic plans and initiatives based on the provided keywords \'**keywords**\'. Identify objectives, key actions, and performance indicators to achieve desired outcomes.', 1, 0, '#D6C2C2', 'business', NULL, 'regular'),
	(65, NULL, 'Personal Bio', 'Generate compelling personal biographies for professional profiles and portfolios.', 'personal_bio', 1, '[{"name":"your_name","type":"text","question":"Your Name","select":""},{"name":"your_summary","type":"textarea","question":"Your Summary","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 0 24 24" width="48"><path d="M0 0h24v24H0z" fill="none"/><path d="M3 4v16h18V4H3zm16 14H5V6h14v12zm-6-3v-1h3v1h-3zM7 11h10v1H7v-1z"/></svg>', 0, 'text', '2024-05-15 01:00:00', '2024-05-15 01:00:00', 'Generate a compelling personal biography for **your_name**. Highlight your professional achievements, skills, and experiences. **your_summary**.', 1, 0, '#C2D6D6', 'business', NULL, 'regular'),
	(66, NULL, 'Career Advice', 'Provide career advice and guidance tailored to individual skills, goals, and aspirations.', 'career_advice', 1, '[{"name":"keywords","type":"textarea","question":"Keywords","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 0 24 24" width="48"><path d="M0 0h24v24H0z" fill="none"/><path d="M3 4v16h18V4H3zm16 14H5V6h14v12zm-6-3v-1h3v1h-3zM7 11h10v1H7v-1z"/></svg>', 0, 'text', '2024-05-15 01:00:00', '2024-05-15 01:00:00', 'Provide career advice and guidance tailored to individual skills, goals, and aspirations based on the provided keywords \'**keywords**\'. Offer personalized recommendations for career advancement and growth.', 1, 0, '#D6A3A3', 'business', NULL, 'regular'),
	(67, NULL, 'Cost Benefit Analysis', 'Conduct cost-benefit analyses to evaluate potential business decisions and investments.', 'cost_benefit_analysis', 1, '[{"name":"keywords","type":"textarea","question":"Keywords","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 0 24 24" width="48"><path d="M0 0h24v24H0z" fill="none"/><path d="M19 5v14H5V5h14m0-2H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z"/><path d="M7 10h10v2H7zM7 14h10v2H7z"/></svg>', 0, 'text', '2024-05-15 01:00:00', '2024-05-15 01:00:00', 'Conduct cost-benefit analyses to evaluate potential business decisions and investments based on the provided keywords \'**keywords**\'. Identify costs, benefits, and calculate the ROI for various scenarios.', 1, 0, '#D6C2C2', 'business', NULL, 'regular'),
	(68, NULL, 'Brainstorming', 'Generate creative ideas and solutions through structured brainstorming sessions.', 'brainstorming', 1, '[{"name":"keywords","type":"textarea","question":"Keywords","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 0 24 24" width="48"><path d="M0 0h24v24H0z" fill="none"/><path d="M19 5v14H5V5h14m0-2H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z"/><path d="M7 10h10v2H7zM7 14h10v2H7z"/></svg>', 0, 'text', '2024-05-15 01:00:00', '2024-05-15 01:00:00', 'Generate creative ideas and solutions through structured brainstorming sessions based on the provided keywords \'**keywords**\'. Explore innovative concepts and strategies to address specific challenges or opportunities.', 1, 0, '#D6A3A3', 'business', NULL, 'regular'),
	(69, NULL, 'Linkedin Post', 'Craft engaging and professional posts for sharing on LinkedIn.', 'linkedin_post', 1, '[{"name":"post_content","type":"textarea","question":"Post Content","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 0 24 24" width="48"><path d="M0 0h24v24H0z" fill="none"/><path d="M19 5v14H5V5h14m0-2H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z"/><path d="M7 10h10v2H7zM7 14h10v2H7z"/></svg>', 0, 'text', '2024-05-15 01:00:00', '2024-05-15 01:00:00', 'Write a LinkedIn post on the following topic: **post_content**. Provide valuable insights, tips, or updates related to your industry or profession.', 1, 0, '#C2D6D6', 'business', NULL, 'regular'),
	(70, NULL, 'Sales Pitch', 'Craft persuasive sales pitches to attract potential clients and investors.', 'sales_pitch', 1, '[{"name":"product_or_service","type":"text","question":"Product or Service","select":""},{"name":"target_audience","type":"text","question":"Target Audience","select":""},{"name":"unique_selling_proposition","type":"textarea","question":"Unique Selling Proposition","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 0 24 24" width="48"><path d="M0 0h24v24H0z" fill="none"/><path d="M19 5v14H5V5h14m0-2H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z"/><path d="M7 10h10v2H7zM7 14h10v2H7z"/></svg>', 0, 'text', '2024-05-15 01:00:00', '2024-05-15 01:00:00', 'Craft a persuasive sales pitch for **product_or_service** targeting **target_audience**. Highlight the unique selling proposition \'**unique_selling_proposition**\' and key benefits.', 1, 0, '#D6C2C2', 'business', NULL, 'regular'),
	(71, NULL, 'Social Media Reply', 'Craft effective and professional replies to social media comments and messages.', 'social_media_reply', 1, '[{"name":"platform","type":"text","question":"Platform","select":""},{"name":"comment","type":"textarea","question":"Comment/Message","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M12 2a10 10 0 00-10 10c0 5.523 4.477 10 10 10s10-4.477 10-10A10 10 0 0012 2zm-.25 15h-1.5V12h1.5v5zm0-6h-1.5V8h1.5v3z"/></svg>', 0, 'text', '2024-05-15 03:30:00', '2024-05-15 03:30:00', 'Craft a professional reply for a comment/message on **platform**. The comment/message is: **comment**.', 1, 0, '#D6A3A3', 'customer service', NULL, 'regular'),
	(72, NULL, 'Apology Email', 'Write a sincere and professional apology email for any situation.', 'apology_email', 1, '[{"name":"recipient_name","type":"text","question":"Recipient Name","select":""},{"name":"issue_description","type":"textarea","question":"Issue Description","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M12 2a10 10 0 100 20 10 10 0 000-20zM6 10h12v2H6v-2zm1 4h10v2H7v-2z"/></svg>', 0, 'text', '2024-05-15 03:35:00', '2024-05-15 03:35:00', 'Write a professional apology email to **recipient_name** regarding the following issue: **issue_description**.', 1, 0, '#FFBD33', 'customer service', NULL, 'regular'),
	(73, NULL, 'Ticket Reply', 'Generate professional replies for customer support tickets.', 'ticket_reply', 1, '[{"name":"ticket_id","type":"text","question":"Ticket ID","select":""},{"name":"ticket_content","type":"textarea","question":"Ticket Content","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 2h16v20H4V2zm2 2v16h12V4H6zm2 2h8v2H8V6zm0 4h8v2H8v-2zm0 4h8v2H8v-2z"/></svg>', 0, 'text', '2024-05-15 03:40:00', '2024-05-15 03:40:00', 'Generate a professional reply for the support ticket with ID **ticket_id**. The ticket content is: **ticket_content**.', 1, 0, '#C2D6D6', 'customer service', NULL, 'regular'),
	(74, NULL, 'Article Generator - Documentation', 'Generate detailed documentation articles based on the provided topics and instructions.', 'article_generator_documentation', 1, '[{"name":"topic","type":"textarea","question":"Article Topic","select":""},{"name":"instructions","type":"textarea","question":"Instructions","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M19 2H5a2 2 0 00-2 2v16a2 2 0 002 2h14a2 2 0 002-2V4a2 2 0 00-2-2zm0 18H5V4h14v16zm-4-5H9v-2h6v2zm0-4H9V9h6v2zm0-4H9V5h6v2z"/></svg>', 0, 'text', '2024-05-15 03:45:00', '2024-05-15 03:45:00', 'Generate a detailed documentation article on the topic **topic**. Follow these instructions: **instructions**.', 1, 0, '#3498DB', 'customer service', NULL, 'regular'),
	(75, NULL, 'Song Lyrics', 'Generate creative and original song lyrics for any genre.', 'song_lyrics', 1, '[{"name":"genre","type":"text","question":"Genre","select":""},{"name":"theme","type":"text","question":"Theme","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M12 2a10 10 0 100 20 10 10 0 000-20zM6 10h12v2H6v-2zm1 4h10v2H7v-2z"/></svg>', 0, 'text', '2024-05-15 04:00:00', '2024-05-15 04:00:00', 'Generate song lyrics in the **genre** genre with the theme of **theme**.', 1, 0, '#D6A3A3', 'entertainment', NULL, 'regular'),
	(76, NULL, 'Jokes', 'Create funny and entertaining jokes.', 'jokes', 1, '[{"name":"topic","type":"text","question":"Joke Topic","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M12 2a10 10 0 100 20 10 10 0 000-20zM6 10h12v2H6v-2zm1 4h10v2H7v-2z"/></svg>', 0, 'text', '2024-05-15 04:05:00', '2024-05-15 04:05:00', 'Create a joke about **topic**.', 1, 0, '#FFBD33', 'entertainment', NULL, 'regular'),
	(77, NULL, 'Event Planner', 'Plan a detailed event itinerary.', 'event_planner', 1, '[{"name":"event_type","type":"text","question":"Event Type","select":""},{"name":"details","type":"textarea","question":"Event Details","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M12 2a10 10 0 100 20 10 10 0 000-20zM6 10h12v2H6v-2zm1 4h10v2H7v-2z"/></svg>', 0, 'text', '2024-05-15 04:10:00', '2024-05-15 04:10:00', 'Plan an event of type **event_type** with the following details: **details**.', 1, 0, '#C2D6D6', 'entertainment', NULL, 'regular'),
	(78, NULL, 'Travel Planner', 'Create a detailed travel itinerary for any destination.', 'travel_planner', 1, '[{"name":"destination","type":"text","question":"Destination","select":""},{"name":"preferences","type":"textarea","question":"Preferences","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M12 2a10 10 0 100 20 10 10 0 000-20zM6 10h12v2H6v-2zm1 4h10v2H7v-2z"/></svg>', 0, 'text', '2024-05-15 04:15:00', '2024-05-15 04:15:00', 'Plan a travel itinerary to **destination** with the following preferences: **preferences**.', 1, 0, '#3498DB', 'entertainment', NULL, 'regular'),
	(79, NULL, 'Gift Ideas', 'Generate creative and personalized gift ideas.', 'gift_ideas', 1, '[{"name":"recipient","type":"text","question":"Recipient","select":""},{"name":"occasion","type":"text","question":"Occasion","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M12 2a10 10 0 100 20 10 10 0 000-20zM6 10h12v2H6v-2zm1 4h10v2H7v-2z"/></svg>', 0, 'text', '2024-05-15 04:20:00', '2024-05-15 04:20:00', 'Generate gift ideas for **recipient** on the occasion of **occasion**.', 1, 0, '#D6A3A3', 'entertainment', NULL, 'regular'),
	(80, NULL, 'Product Features', 'Highlight the key features of a product.', 'product_features', 1, '[{"name":"product_name","type":"text","question":"Product Name","select":""},{"name":"features","type":"textarea","question":"Features","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v16H4V4zm8 2v2H8V6h4zm0 4v2H8v-2h4zm0 4v2H8v-2h4z"/></svg>', 0, 'text', '2024-05-15 04:35:00', '2024-05-15 04:35:00', 'List the key features of **product_name**. The features are: **features**.', 1, 0, '#FFBD33', 'ecommerce', NULL, 'regular'),
	(81, NULL, 'Product Name Ideas', 'Generate creative and catchy product name ideas.', 'product_name_ideas', 1, '[{"name":"product_type","type":"text","question":"Product Type","select":""},{"name":"quantity","type":"number","question":"Number of Names","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M12 2a10 10 0 100 20 10 10 0 000-20zm1 14h-2v-2h2v2zm0-4h-2V7h2v5z"/></svg>', 0, 'text', '2024-05-15 04:40:00', '2024-05-15 04:40:00', 'Generate **quantity** product name ideas for a **product_type**.', 1, 0, '#C2D6D6', 'ecommerce', NULL, 'regular'),
	(82, NULL, 'Why Choose This Product', 'Explain why a customer should choose a specific product.', 'why_choose_this_product', 1, '[{"name":"product_name","type":"text","question":"Product Name","select":""},{"name":"reasons","type":"textarea","question":"Reasons","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M2 2v20l20-10L2 2zm2.5 5L17 12 4.5 17V7z"/></svg>', 0, 'text', '2024-05-15 04:45:00', '2024-05-15 04:45:00', 'Explain why a customer should choose **product_name**. The reasons are: **reasons**.', 1, 0, '#3498DB', 'ecommerce', NULL, 'regular'),
	(83, NULL, 'Reviews', 'Generate detailed reviews for a product.', 'reviews', 1, '[{"name":"product_name","type":"text","question":"Product Name","select":""},{"name":"review_details","type":"textarea","question":"Review Details","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M12 2a10 10 0 100 20 10 10 0 000-20zm0 2a8 8 0 110 16 8 8 0 010-16zm-1 4h2v5h-2V8zm0 7h2v2h-2v-2z"/></svg>', 0, 'text', '2024-05-15 04:50:00', '2024-05-15 04:50:00', 'Write a detailed review for **product_name**. The review details are: **review_details**.', 1, 0, '#D6A3A3', 'ecommerce', NULL, 'regular'),
	(84, NULL, 'Review Responder', 'Craft professional responses to customer reviews.', 'review_responder', 1, '[{"name":"review","type":"textarea","question":"Customer Review","select":""},{"name":"response","type":"textarea","question":"Response","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M21 3H3v14h6v4l4-4h8V3zM5 5h14v10h-7.172L11 17.828V15H5V5z"/></svg>', 0, 'text', '2024-05-15 04:55:00', '2024-05-15 04:55:00', 'Craft a professional response to the following customer review: **review**. The response is: **response**.', 1, 0, '#FFBD33', 'ecommerce', NULL, 'regular'),
	(85, NULL, 'Amazon', 'Generate Amazon product listings and descriptions.', 'amazon', 1, '[{"name":"product_name","type":"text","question":"Product Name","select":""},{"name":"product_details","type":"textarea","question":"Product Details","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M5 4h14v2H5V4zm0 4h14v2H5V8zm0 4h10v2H5v-2zm0 4h8v2H5v-2z"/></svg>', 0, 'text', '2024-05-15 05:00:00', '2024-05-15 05:00:00', 'Generate an Amazon product listing for **product_name**. The product details are: **product_details**.', 1, 0, '#C2D6D6', 'ecommerce', NULL, 'regular'),
	(86, NULL, 'Sitemap', 'Generate a comprehensive sitemap for your website.', 'sitemap', 1, '[{"name":"website_url","type":"text","question":"Website URL","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 4h16v2H4V8zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 05:30:00', '2024-05-15 05:30:00', 'Generate a sitemap for the website: **website_url**.', 1, 0, '#D6A3A3', 'website', NULL, 'regular'),
	(87, NULL, 'Tagline', 'Create a catchy and memorable tagline for your website.', 'tagline', 1, '[{"name":"website_name","type":"text","question":"Website Name","select":""},{"name":"description","type":"textarea","question":"Website Description","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M12 2a10 10 0 100 20 10 10 0 000-20zm-2 14h4v-2h-4v2zm-2-4h8v-2H8v2zm0-4h8V6H8v2z"/></svg>', 0, 'text', '2024-05-15 05:35:00', '2024-05-15 05:35:00', 'Create a catchy tagline for **website_name**. Description: **description**.', 1, 0, '#FFBD33', 'website', NULL, 'regular'),
	(88, NULL, 'UX Ideas', 'Generate innovative UX ideas to improve user experience.', 'ux_ideas', 1, '[{"name":"website_name","type":"text","question":"Website Name","select":""},{"name":"current_issues","type":"textarea","question":"Current UX Issues","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 4h16v2H4V8zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 05:40:00', '2024-05-15 05:40:00', 'Provide UX improvement ideas for **website_name**. Current issues: **current_issues**.', 1, 0, '#C2D6D6', 'website', NULL, 'regular'),
	(89, NULL, 'Design Ideas', 'Get creative design ideas for your website.', 'design_ideas', 1, '[{"name":"website_name","type":"text","question":"Website Name","select":""},{"name":"design_preferences","type":"textarea","question":"Design Preferences","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 4h16v2H4V8zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 05:45:00', '2024-05-15 05:45:00', 'Generate design ideas for **website_name**. Preferences: **design_preferences**.', 1, 0, '#3498DB', 'website', NULL, 'regular'),
	(90, NULL, 'Services Page', 'Create detailed content for your services page.', 'services_page', 1, '[{"name":"service_name","type":"text","question":"Service Name","select":""},{"name":"service_details","type":"textarea","question":"Service Details","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 4h16v2H4V8zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 05:50:00', '2024-05-15 05:50:00', 'Write content for the services page for **service_name**. Details: **service_details**.', 1, 0, '#D6A3A3', 'website', NULL, 'regular'),
	(91, NULL, 'Features Page', 'Create detailed content for your features page.', 'features_page', 1, '[{"name":"feature_name","type":"text","question":"Feature Name","select":""},{"name":"feature_details","type":"textarea","question":"Feature Details","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 4h16v2H4V8zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 05:55:00', '2024-05-15 05:55:00', 'Write content for the features page for **feature_name**. Details: **feature_details**.', 1, 0, '#FFBD33', 'website', NULL, 'regular'),
	(92, NULL, 'Keyword Generator', 'Generate relevant keywords for your website content.', 'keyword_generator', 1, '[{"name":"topic","type":"text","question":"Topic","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 4h16v2H4V8zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 06:00:00', '2024-05-15 06:00:00', 'Generate relevant keywords for the topic: **topic**.', 1, 0, '#C2D6D6', 'website', NULL, 'regular'),
	(93, NULL, 'Keyword Extractor', 'Extract important keywords from your website content.', 'keyword_extractor', 1, '[{"name":"content","type":"textarea","question":"Content","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 4h16v2H4V8zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 06:05:00', '2024-05-15 06:05:00', 'Extract keywords from the following content: **content**.', 1, 0, '#3498DB', 'website', NULL, 'regular'),
	(94, NULL, 'SEO', 'Optimize your website content for search engines.', 'seo', 1, '[{"name":"content","type":"textarea","question":"Content","select":""},{"name":"keywords","type":"textarea","question":"Keywords","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 4h16v2H4V8zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 06:10:00', '2024-05-15 06:10:00', 'Optimize the website content for search engines. Content: **content**. Keywords: **keywords**.', 1, 0, '#D6A3A3', 'website', NULL, 'regular'),
	(95, NULL, 'Testimonials', 'Generate authentic testimonials for your website.', 'testimonials', 1, '[{"name":"customer_name","type":"text","question":"Customer Name","select":""},{"name":"testimonial","type":"textarea","question":"Testimonial","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 4h16v2H4V8zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 06:15:00', '2024-05-15 06:15:00', 'Generate a testimonial for **customer_name**. Testimonial: **testimonial**.', 1, 0, '#FFBD33', 'website', NULL, 'regular'),
	(96, NULL, 'Landing Page Content - Copywriting', 'Create compelling copy for your landing page.', 'landing_page_copywriting', 1, '[{"name":"product_name","type":"text","question":"Product Name","select":""},{"name":"benefits","type":"textarea","question":"Benefits","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 4h16v2H4V8zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 06:20:00', '2024-05-15 06:20:00', 'Write compelling copy for the landing page of **product_name**. Benefits: **benefits**.', 1, 0, '#C2D6D6', 'website', NULL, 'regular'),
	(97, NULL, 'Website - Copywriting', 'Create engaging copy for your website pages.', 'website_copywriting', 1, '[{"name":"page_name","type":"text","question":"Page Name","select":""},{"name":"content","type":"textarea","question":"Content","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 4h16v2H4V8zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 06:25:00', '2024-05-15 06:25:00', 'Write engaging copy for the **page_name** page. Content: **content**.', 1, 0, '#3498DB', 'website', NULL, 'regular'),
	(98, NULL, 'FAQ', 'Generate frequently asked questions for your website.', 'faq', 1, '[{"name":"topic","type":"text","question":"Topic","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 4h16v2H4V8zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 06:30:00', '2024-05-15 06:30:00', 'Generate frequently asked questions on the topic: **topic**.', 1, 0, '#D6A3A3', 'website', NULL, 'regular'),
	(99, NULL, 'Call to Action', 'Create compelling calls to action for your website.', 'call_to_action', 1, '[{"name":"action","type":"textarea","question":"Action","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 4h16v2H4V8zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 06:35:00', '2024-05-15 06:35:00', 'Create a compelling call to action: **action**.', 1, 0, '#FFBD33', 'website', NULL, 'regular'),
	(100, NULL, 'Rewrite with Keywords', 'Rewrite website content with targeted keywords.', 'rewrite_with_keywords', 1, '[{"name":"content","type":"textarea","question":"Content","select":""},{"name":"keywords","type":"textarea","question":"Keywords","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 4h16v2H4V8zm0 4h16v2H4V8zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 06:45:00', '2024-05-15 06:45:00', 'Rewrite the content with targeted keywords. Content: **content**. Keywords: **keywords**.', 1, 0, '#3498DB', 'website', NULL, 'regular'),
	(101, NULL, 'Privacy Policy', 'Generate a privacy policy for your website.', 'privacy_policy', 1, '[{"name":"company_name","type":"text","question":"Company Name","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 4h16v2H4V8zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 06:50:00', '2024-05-15 06:50:00', 'Generate a privacy policy for **company_name**.', 1, 0, '#D6A3A3', 'website', NULL, 'regular'),
	(102, NULL, 'Terms and Conditions', 'Generate terms and conditions for your website.', 'terms_and_conditions', 1, '[{"name":"company_name","type":"text","question":"Company Name","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 4h16v2H4V8zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 06:55:00', '2024-05-15 06:55:00', 'Generate terms and conditions for **company_name**.', 1, 0, '#FFBD33', 'website', NULL, 'regular'),
	(103, NULL, 'Blog Ideas', 'Generate creative ideas for your next blog post.', 'blog_ideas', 1, '[{"name":"topic","type":"textarea","question":"Blog Topic","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 4h16v2H4V8zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 07:00:00', '2024-05-15 07:00:00', 'Generate creative ideas for your next blog post on the topic: **topic**.', 1, 0, '#D6A3A3', 'blog', NULL, 'regular'),
	(104, NULL, 'Blog Intro', 'Generate an engaging introduction for your blog post.', 'blog_intro', 1, '[{"name":"topic","type":"text","question":"Blog Topic","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 4h16v2H4V8zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 07:05:00', '2024-05-15 07:05:00', 'Generate an engaging introduction for your blog post on **topic**.', 1, 0, '#FFBD33', 'blog', NULL, 'regular'),
	(105, NULL, 'Blog Outline', 'Generate an outline for your blog post.', 'blog_outline', 1, '[{"name":"topic","type":"text","question":"Blog Topic","select":""},{"name":"sections","type":"textarea","question":"Sections","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 4h16v2H4V8zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 07:15:00', '2024-05-15 07:15:00', 'Generate an outline for your blog post on **topic**. Sections: **sections**.', 1, 0, '#3498DB', 'blog', NULL, 'regular'),
	(106, NULL, 'Blog Article', 'Generate a full article for your blog post.', 'blog_article', 1, '[{"name":"topic","type":"text","question":"Blog Topic","select":""},{"name":"sections","type":"textarea","question":"Sections","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 4h16v2H4V8zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 07:20:00', '2024-05-15 07:20:00', 'Generate a full article for your blog post on **topic**. Sections: **sections**.', 1, 0, '#FFC300', 'blog', NULL, 'regular'),
	(107, NULL, 'IG Reel Script', 'Generate a script for an Instagram Reel video.', 'ig_reel_script', 1, '[{"name":"topic","type":"textarea","question":"Video Topic","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 4h16v2H4V8zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 08:00:00', '2024-05-15 08:00:00', 'Generate a script for an Instagram Reel video on **topic**.', 1, 0, '#D6A3A3', 'social media', NULL, 'regular'),
	(108, NULL, 'IG Captions', 'Generate captions for Instagram posts.', 'ig_captions', 1, '[{"name":"photo_description","type":"textarea","question":"Photo Description","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 4h16v2H4V8zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 08:05:00', '2024-05-15 08:05:00', 'Generate captions for Instagram posts with the photo description: **photo_description**.', 1, 0, '#3498DB', 'social media', NULL, 'regular'),
	(109, NULL, 'TikTok Script', 'Generate a script for a TikTok video.', 'tiktok_script', 1, '[{"name":"topic","type":"textarea","question":"Video Topic","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 4h16v2H4V8zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 08:10:00', '2024-05-15 08:10:00', 'Generate a script for a TikTok video on **topic**.', 1, 0, '#D6A3A3', 'social media', NULL, 'regular'),
	(110, NULL, 'TikTok Video Caption', 'Generate captions for TikTok videos.', 'tiktok_video_caption', 1, '[{"name":"video_description","type":"textarea","question":"Video Description","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 4h16v2H4V8zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 08:15:00', '2024-05-15 08:15:00', 'Generate captions for TikTok videos with the video description: **video_description**.', 1, 0, '#3498DB', 'social media', NULL, 'regular'),
	(111, NULL, 'TikTok Video Script', 'Generate a script for a TikTok video.', 'tiktok_video_script', 1, '[{"name":"topic","type":"textarea","question":"Video Topic","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 4h16v2H4V8zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 08:20:00', '2024-05-15 08:20:00', 'Generate a script for a TikTok video on **topic**.', 1, 0, '#D6A3A3', 'social media', NULL, 'regular'),
	(112, NULL, 'Facebook Post', 'Generate engaging posts for Facebook.', 'facebook_post', 1, '[{"name":"post_content","type":"textarea","question":"Post Content","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 4h16v2H4V8zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 08:25:00', '2024-05-15 08:25:00', 'Generate engaging posts for Facebook with the content: **post_content**.', 1, 0, '#3498DB', 'social media', NULL, 'regular'),
	(113, NULL, 'Facebook Video Script', 'Generate a script for a Facebook video.', 'facebook_video_script', 1, '[{"name":"topic","type":"textarea","question":"Video Topic","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 4h16v2H4V8zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 08:35:00', '2024-05-15 08:35:00', 'Generate a script for a Facebook video on **topic**.', 1, 0, '#3498DB', 'social media', NULL, 'regular'),
	(114, NULL, 'X Tweet', 'Generate a tweet for any purpose.', 'x_tweet', 1, '[{"name":"tweet_content","type":"textarea","question":"Tweet Content","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 6h16v2H4V10zm0 6h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 08:40:00', '2024-05-15 08:40:00', 'Generate a tweet with the following content: **tweet_content**.', 1, 0, '#D6A3A3', 'social media', NULL, 'regular'),
	(115, NULL, 'X Thread', 'Generate a Twitter thread for any topic.', 'x_thread', 1, '[{"name":"thread_content","type":"textarea","question":"Thread Content","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 6h16v2H4V10zm0 6h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 08:45:00', '2024-05-15 08:45:00', 'Generate a Twitter thread with the following content: **thread_content**.', 1, 0, '#3498DB', 'social media', NULL, 'regular'),
	(116, NULL, 'Youtube Video to Blog Post', 'Generate blog posts from YouTube videos.', 'youtube_video_to_blog_post', 1, '[{"name":"video_url","type":"text","question":"Video URL","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 6h16v2H4V10zm0 6h16v2H4v-2zm0 6h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 09:05:00', '2024-05-15 09:05:00', 'Generate blog posts from YouTube videos with the video URL: **video_url**.', 1, 0, '#3498DB', 'social media', NULL, 'regular'),
	(117, NULL, 'Video Idea', 'Generate ideas for video content.', 'video_idea', 1, '[{"name":"topic","type":"textarea","question":"Video Topic","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 6h16v2H4V10zm0 6h16v2H4v-2zm0 6h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 09:10:00', '2024-05-15 09:10:00', 'Generate ideas for video content on **topic**.', 1, 0, '#D6A3A3', 'social media', NULL, 'regular'),
	(118, NULL, 'Video Description', 'Generate descriptions for videos.', 'video_description', 1, '[{"name":"video_topic","type":"textarea","question":"Video Topic","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 6h16v2H4V10zm0 6h16v2H4v-2zm0 6h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 09:15:00', '2024-05-15 09:15:00', 'Generate descriptions for videos on **video_topic**.', 1, 0, '#3498DB', 'social media', NULL, 'regular'),
	(119, NULL, 'Viral Tweet Idea', 'Generate ideas for tweets that could potentially go viral.', 'viral_tweet_idea', 1, '[{"name":"topic","type":"textarea","question":"Tweet Topic","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 6h16v2H4V10zm0 6h16v2H4v-2zm0 6h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 09:20:00', '2024-05-15 09:20:00', 'Generate ideas for tweets that could potentially go viral on **topic**.', 1, 0, '#D6A3A3', 'social media', NULL, 'regular'),
	(120, NULL, 'Clickbait Titles', 'Generate clickbait titles for social media posts.', 'clickbait_titles', 1, '[{"name":"topic","type":"textarea","question":"Topic","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 6h16v2H4V10zm0 6h16v2H4v-2zm0 6h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 09:25:00', '2024-05-15 09:25:00', 'Generate clickbait titles for social media posts on **topic**.', 1, 0, '#3498DB', 'social media', NULL, 'regular'),
	(121, NULL, 'App and SMS Notifications', 'Generate notifications for mobile apps and SMS.', 'app_and_sms_notifications', 1, '[{"name":"notification_type","type":"text","question":"Notification Type","select":""},{"name":"message","type":"textarea","question":"Message","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 6h16v2H4V10zm0 6h16v2H4v-2zm0 6h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 09:30:00', '2024-05-15 09:30:00', 'Generate notifications for **notification_type** with the message: **message**.', 1, 0, '#D6A3A3', 'social media', NULL, 'regular'),
	(122, NULL, 'Advertising Ideas', 'Generate ideas for advertising campaigns.', 'advertising_ideas', 1, '[{"name":"topic","type":"textarea","question":"Advertising Topic","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 6h16v2H4V10zm0 6h16v2H4v-2zm0 6h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 09:35:00', '2024-05-15 09:35:00', 'Generate ideas for advertising campaigns on **topic**.', 1, 0, '#F1C40F', 'advertising', NULL, 'regular'),
	(123, NULL, 'FB Ad', 'Generate content for Facebook advertisements.', 'fb_ad', 1, '[{"name":"ad_content","type":"textarea","question":"Ad Content","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 6h16v2H4V10zm0 6h16v2H4v-2zm0 6h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 09:40:00', '2024-05-15 09:40:00', 'Generate content for a Facebook advertisement: **ad_content**.', 1, 0, '#C2D6D6', 'advertising', NULL, 'regular'),
	(124, NULL, 'Google Ad', 'Generate content for Google advertisements.', 'google_ad', 1, '[{"name":"ad_content","type":"textarea","question":"Ad Content","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 6h16v2H4V10zm0 6h16v2H4v-2zm0 6h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 09:45:00', '2024-05-15 09:45:00', 'Generate content for a Google advertisement: **ad_content**.', 1, 0, '#D6A3A3', 'advertising', NULL, 'regular'),
	(125, NULL, 'Ad Script', 'Generate scripts for advertisements.', 'ad_script', 1, '[{"name":"ad_type","type":"text","question":"Ad Type","select":""},{"name":"ad_content","type":"textarea","question":"Ad Content","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 6h16v2H4V10zm0 6h16v2H4v-2zm0 6h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 09:50:00', '2024-05-15 09:50:00', 'Generate a script for a **ad_type** advertisement: **ad_content**.', 1, 0, '#3498DB', 'advertising', NULL, 'regular'),
	(126, NULL, 'TV Ads', 'Generate ideas and content for TV advertisements.', 'tv_ads', 1, '[{"name":"ad_content","type":"textarea","question":"Ad Content","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 6h16v2H4V10zm0 6h16v2H4v-2zm0 6h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 09:55:00', '2024-05-15 09:55:00', 'Generate ideas and content for TV advertisements: **ad_content**.', 1, 0, '#F1C40F', 'advertising', NULL, 'regular'),
	(127, NULL, 'Youtube Ads', 'Generate ideas and content for YouTube advertisements.', 'youtube_ads', 1, '[{"name":"ad_content","type":"textarea","question":"Ad Content","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 6h16v2H4V10zm0 6h16v2H4v-2zm0 6h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 10:00:00', '2024-05-15 10:00:00', 'Generate ideas and content for YouTube advertisements: **ad_content**.', 1, 0, '#C2D6D6', 'advertising', NULL, 'regular'),
	(128, NULL, 'Translate', 'Translate text from one language to another.', 'translate', 1, '[{"name":"source_language","type":"text","question":"Source Language","select":""},{"name":"target_language","type":"text","question":"Target Language","select":""},{"name":"text","type":"textarea","question":"Text to Translate","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 6h16v2H4V10zm0 6h16v2H4v-2zm0 6h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 10:05:00', '2024-05-15 10:05:00', 'Translate the text **text** from **source_language** to **target_language**.', 1, 0, '#F1C40F', 'languages', NULL, 'regular'),
	(129, NULL, 'Grammar Check', 'Check grammar and provide suggestions for improvement.', 'grammar_check', 1, '[{"name":"text","type":"textarea","question":"Text to Check","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 6h16v2H4V10zm0 6h16v2H4v-2zm0 6h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 10:10:00', '2024-05-15 10:10:00', 'Check the grammar of the text **text** and provide suggestions for improvement.', 1, 0, '#C2D6D6', 'languages', NULL, 'regular'),
	(130, NULL, 'List Synonyms', 'Generate a list of synonyms for a given word.', 'list_synonyms', 1, '[{"name":"word","type":"text","question":"Word","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 6h16v2H4V10zm0 6h16v2H4v-2zm0 6h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 10:15:00', '2024-05-15 10:15:00', 'Generate a list of synonyms for the word **word**.', 1, 0, '#D6A3A3', 'languages', NULL, 'regular'),
	(131, NULL, 'Learn New Words', 'Discover and learn new words with their meanings and usage.', 'learn_new_words', 1, '[{"name":"topic","type":"text","question":"Topic","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M4 4h16v2H4V4zm0 6h16v2H4V10zm0 6h16v2H4v-2zm0 6h16v2H4v-2zm0 4h16v2H4v-2z"/></svg>', 0, 'text', '2024-05-15 10:20:00', '2024-05-15 10:20:00', 'Discover and learn new words related to **topic** with their meanings and usage.', 1, 0, '#3498DB', 'languages', NULL, 'regular'),
	(132, NULL, 'Bug Fix', 'Identify and fix bugs in code to improve functionality and performance.', 'bug_fix', 1, '[{"name":"issue_description","type":"textarea","question":"Issue Description","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M19.707 4.293a1 1 0 00-1.414 0l-3.5 3.5A6.972 6.972 0 0012 4a7 7 0 00-7 7c0 3.128 2.053 5.862 5 6.75V18a1 1 0 002 0v-.25c2.947-.888 5-3.622 5-6.75a7 7 0 00-2.793-5.618l-3.5-3.5a1 1 0 00-1.414 1.414l3.5 3.5a4.976 4.976 0 011.914 3.328A5 5 0 0112 11a4.976 4.976 0 01-3.328-1.914A5 5 0 018 6a4.978 4.978 0 011.207-3.293A1 1 0 009.207.293 6.98 6.98 0 0112 0a7 7 0 017 7c0 2.562-1.373 4.832-3.414 6.064l-.5.436V14a1 1 0 00-2 0v1a1 1 0 001 1h4a1 1 0 000-2h-1V11h1a1 1 0 000-2h-1V8h1a1 1 0 000-2h-1V5a1 1 0 00.293-.707zM12 22a6.978 6.978 0 01-5.064-2.192l-2.686 2.686A1 1 0 004 23a1 1 0 00.707-1.707l2.636-2.636A7.015 7.015 0 014 17c0-3.86 3.14-7 7-7s7 3.14 7 7-3.14 7-7 7z"/></svg>', 0, 'text', '2024-05-15 10:25:00', '2024-05-15 10:25:00', 'Identify and fix the following issue: **issue_description**.', 1, 0, '#F1C40F', 'development', NULL, 'regular'),
	(133, NULL, 'Explain Code', 'Provide explanations and clarifications on specific sections of code.', 'explain_code', 1, '[{"name":"code_section","type":"textarea","question":"Code Section","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M19 2H5c-1.104 0-2 .896-2 2v16c0 1.104.896 2 2 2h14c1.104 0 2-.896 2-2V4c0-1.104-.896-2-2-2zm0 18H5V4h14v16z"/></svg>', 0, 'text', '2024-05-15 10:30:00', '2024-05-15 10:30:00', 'Provide explanations and clarifications on the following code section: **code_section**.', 1, 0, '#C2D6D6', 'development', NULL, 'regular'),
	(134, NULL, 'Teach Code', 'Create educational materials and tutorials to teach coding concepts and techniques.', 'teach_code', 1, '[{"name":"concept","type":"textarea","question":"Concept","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M12 2C6.488 2 2 6.488 2 12s4.488 10 10 10 10-4.488 10-10S17.512 2 12 2zm0 18.25c-4.525 0-8.25-3.725-8.25-8.25S7.475 3.75 12 3.75 20.25 7.475 20.25 12 16.525 20.25 12 20.25zm-.24-9.504l-4.536 4.537L6.88 13.68l4.397-4.395-1.01-1.01-4.88 4.88 4.88 4.88 1.01-1.01-4.395-4.397 1.057-1.057 4.537 4.537 1.414-1.414z"/></svg>', 0, 'text', '2024-05-15 10:35:00', '2024-05-15 10:35:00', 'Create educational materials and tutorials to teach the coding concept: **concept**.', 1, 0, '#D6A3A3', 'development', NULL, 'regular'),
	(135, NULL, 'Changelog Creator', 'Generate changelogs to document updates and modifications in software or projects.', 'changelog_creator_dev', 1, '[{"name":"version","type":"text","question":"Version","select":""},{"name":"changes","type":"textarea","question":"Changes","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M20 2H4a2 2 0 00-2 2v16a2 2 0 002 2h14a2 2 0 002-2V4a2 2 0 00-2-2zm0 18H4V4h14v16zm-4-5H9v-2h6v2zm0-4H9V9h6v2zm0-4H9V5h6v2z"/></svg>', 0, 'text', '2024-05-15 11:00:00', '2024-05-15 11:00:00', 'Generate a changelog for version **version** documenting the following changes: **changes**.', 1, 0, '#3498DB', 'development', NULL, 'regular'),
	(136, NULL, 'Welcome Email', 'Craft a warm and engaging email to welcome new subscribers or users.', 'welcome_email', 1, '[{"name":"recipient_name","type":"text","question":"Recipient Name","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M22 2H2C.894 2 0 2.894 0 4v16c0 1.106.894 2 2 2h20c1.106 0 2-.894 2-2V4c0-1.106-.894-2-2-2zm0 4L12 13 2 6v2l10 7 10-7V6z"/></svg>', 0, 'text', '2024-05-15 11:15:00', '2024-05-15 11:15:00', 'Craft a warm welcome email for **recipient_name**.', 1, 0, '#D6A3A3', 'email', NULL, 'regular'),
	(137, NULL, 'Invitation Mail', 'Create an inviting email to send out invitations for events, gatherings, or meetings.', 'invitation_mail', 1, '[{"name":"event_name","type":"text","question":"Event Name","select":""},{"name":"event_date","type":"text","question":"Event Date","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M19 4H5a2 2 0 00-2 2v12a2 2 0 002 2h14a2 2 0 002-2V6a2 2 0 00-2-2zm0 4l-7 5-7-5V6l7 5 7-5v2z"/></svg>', 0, 'text', '2024-05-15 11:20:00', '2024-05-15 11:20:00', 'Create an inviting email for **event_name** happening on **event_date**.', 1, 0, '#3498DB', 'email', NULL, 'regular'),
	(138, NULL, 'Follow up Email', 'Craft a follow-up email to reconnect with clients, customers, or contacts.', 'follow_up_email', 1, '[{"name":"recipient_name","type":"text","question":"Recipient Name","select":""},{"name":"reason","type":"textarea","question":"Reason for Follow-up","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M22 2H2C.894 2 0 2.894 0 4v16c0 1.106.894 2 2 2h20c1.106 0 2-.894 2-2V4c0-1.106-.894-2-2-2zm0 4L12 13 2 6v2l10 7 10-7V6z"/></svg>', 0, 'text', '2024-05-15 11:25:00', '2024-05-15 11:25:00', 'Craft a follow-up email for **recipient_name** regarding **reason**.', 1, 0, '#F1C40F', 'email', NULL, 'regular'),
	(139, NULL, 'Reply Email', 'Compose a professional email response to reply to inquiries, questions, or requests.', 'reply_email', 1, '[{"name":"sender_name","type":"text","question":"Sender Name","select":""},{"name":"subject","type":"text","question":"Subject","select":""},{"name":"message","type":"textarea","question":"Message","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M22 2H2C.894 2 0 2.894 0 4v16c0 1.106.894 2 2 2h20c1.106 0 2-.894 2-2V4c0-1.106-.894-2-2-2zm0 4L12 13 2 6v2l10 7 10-7V6z"/></svg>', 0, 'text', '2024-05-15 11:30:00', '2024-05-15 11:30:00', 'Compose a professional email response to **sender_name** regarding the subject **subject**. Message: **message**.', 1, 0, '#C2D6D6', 'email', NULL, 'regular'),
	(140, NULL, 'Newsletter', 'Design and create a newsletter to share updates, news, or promotions with subscribers.', 'newsletter', 1, '[{"name":"topic","type":"text","question":"Newsletter Topic","select":""},{"name":"content","type":"textarea","question":"Newsletter Content","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M15.414 3H2a1 1 0 00-1 1v16a1 1 0 001 1h18a1 1 0 001-1V7.586L15.414 3zM20 18H4V6h11.414L20 9.586V18zm-8-4h-4v2h4v-2zm0-4h-4v2h4v-2zm0-4h-4v2h4V6z"/></svg>', 0, 'text', '2024-05-15 11:35:00', '2024-05-15 11:35:00', 'Design and create a newsletter on **topic**. Content: **content**.', 1, 0, '#F1C40F', 'email', NULL, 'regular'),
	(141, NULL, 'Press Release', 'Write a press release to announce new products, events, or company updates.', 'press_release', 1, '[{"name":"announcement","type":"textarea","question":"Announcement","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M22 2H2C.894 2 0 2.894 0 4v16c0 1.106.894 2 2 2h20c1.106 0 2-.894 2-2V4c0-1.106-.894-2-2-2zm0 4L12 13 2 6v2l10 7 10-7V6z"/></svg>', 0, 'text', '2024-05-15 11:40:00', '2024-05-15 11:40:00', 'Write a press release to announce: **announcement**.', 1, 0, '#D6A3A3', 'email', NULL, 'regular'),
	(142, NULL, 'Cold Email', 'Create an effective cold email to reach out to potential clients or partners.', 'cold_email', 1, '[{"name":"recipient_name","type":"text","question":"Recipient Name","select":""},{"name":"reason","type":"textarea","question":"Reason for Contact","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M22 2H2C.894 2 0 2.894 0 4v16c0 1.106.894 2 2 2h20c1.106 0 2-.894 2-2V4c0-1.106-.894-2-2-2zm0 4L12 13 2 6v2l10 7 10-7V6z"/></svg>', 0, 'text', '2024-05-15 11:45:00', '2024-05-15 11:45:00', 'Create an effective cold email to reach out to **recipient_name** regarding **reason**.', 1, 0, '#3498DB', 'email', NULL, 'regular'),
	(143, NULL, 'Create a Workout Plan', 'Design a personalized workout plan tailored to individual needs and fitness goals.', 'workout_plan', 1, '[{"name":"fitness_goals","type":"textarea","question":"Fitness Goals","select":""},{"name":"current_fitness_level","type":"text","question":"Current Fitness Level","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M20 2H4c-1.105 0-2 .895-2 2v18c0 1.105.895 2 2 2h16c1.105 0 2-.895 2-2V4c0-1.105-.895-2-2-2zm0 4l-8 5-8-5V4l8 5 8-5v2z"/></svg>', 0, 'text', '2024-05-15 12:10:00', '2024-05-15 12:10:00', 'Design a personalized workout plan to achieve **fitness_goals** considering your **current_fitness_level**.', 1, 0, '#D6A3A3', 'fitness & health', NULL, 'regular'),
	(144, NULL, 'Create a Meal Plan', 'Develop a customized meal plan based on dietary preferences, nutritional needs, and health goals.', 'meal_plan', 1, '[{"name":"dietary_preferences","type":"text","question":"Dietary Preferences","select":""},{"name":"health_goals","type":"textarea","question":"Health Goals","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M20 2H4c-1.105 0-2 .895-2 2v18c0 1.105.895 2 2 2h16c1.105 0 2-.895 2-2V4c0-1.105-.895-2-2-2zm0 4l-8 5-8-5V4l8 5 8-5v2z"/></svg>', 0, 'text', '2024-05-15 12:15:00', '2024-05-15 12:15:00', 'Develop a customized meal plan based on **dietary_preferences** to achieve **health_goals**.', 1, 0, '#3498DB', 'fitness & health', NULL, 'regular'),
	(145, NULL, 'eBook', 'Generate a complete eBook on any topic of your choice.', 'ebook', 1, '[{"name":"topic","type":"text","question":"Topic","select":""},{"name":"audience","type":"text","question":"Audience","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M20 2H4c-1.105 0-2 .895-2 2v16c0 1.105.895 2 2 2h16c1.105 0 2-.895 2-2V4c0-1.105-.895-2-2-2zm0 4l-8 5-8-5V4l8 5 8-5v2z"/></svg>', 0, 'text', '2024-05-15 12:20:00', '2024-05-15 12:20:00', 'Generate a complete eBook on the topic **topic** for the **audience** audience.', 1, 0, '#F1C40F', 'writer', NULL, 'regular'),
	(146, NULL, 'Paragraph', 'Generate a well-written paragraph on any given topic.', 'paragraph', 1, '[{"name":"topic","type":"textarea","question":"Topic","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M20 2H4c-1.105 0-2 .895-2 2v16c0 1.105.895 2 2 2h16c1.105 0 2-.895 2-2V4c0-1.105-.895-2-2-2zm0 4l-8 5-8-5V4l8 5 8-5v2z"/></svg>', 0, 'text', '2024-05-15 12:25:00', '2024-05-15 12:25:00', 'Generate a well-written paragraph on the topic **topic**.', 1, 0, '#C2D6D6', 'writer', NULL, 'regular'),
	(147, NULL, 'Story Generator', 'Generate creative story ideas or complete stories based on provided prompts.', 'story_generator', 1, '[{"name":"prompt","type":"textarea","question":"Prompt","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M20 2H4c-1.105 0-2 .895-2 2v16c0 1.105.895 2 2 2h16c1.105 0 2-.895 2-2V4c0-1.105-.895-2-2-2zm0 4l-8 5-8-5V4l8 5 8-5v2z"/></svg>', 0, 'text', '2024-05-15 12:30:00', '2024-05-15 12:30:00', 'Generate creative story ideas or complete stories based on the provided prompt: **prompt**.', 1, 0, '#D6A3A3', 'writer', NULL, 'regular'),
	(148, NULL, 'Book Ideas', 'Generate ideas for new books or novels based on specified themes or genres.', 'book_ideas', 1, '[{"name":"theme","type":"text","question":"Theme","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M20 2H4c-1.105 0-2 .895-2 2v16c0 1.105.895 2 2 2h16c1.105 0 2-.895 2-2V4c0-1.105-.895-2-2-2zm0 4l-8 5-8-5V4l8 5 8-5v2z"/></svg>', 0, 'text', '2024-05-15 12:35:00', '2024-05-15 12:35:00', 'Generate ideas for new books or novels based on the theme **theme**.', 1, 0, '#3498DB', 'writer', NULL, 'regular'),
	(149, NULL, 'Content Improver', 'Enhance the quality and readability of existing content by providing suggestions for improvement.', 'content_improver', 1, '[{"name":"content","type":"textarea","question":"Content","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M20 2H4c-1.105 0-2 .895-2 2v16c0 1.105.895 2 2 2h16c1.105 0 2-.895 2-2V4c0-1.105-.895-2-2-2zm0 4l-8 5-8-5V4l8 5 8-5v2z"/></svg>', 0, 'text', '2024-05-15 12:40:00', '2024-05-15 12:40:00', 'Enhance the quality and readability of the provided content: **content**.', 1, 0, '#F1C40F', 'writer', NULL, 'regular'),
	(150, NULL, 'Explain to a Child', 'Simplify complex topics or concepts to make them understandable to children.', 'explain_to_child', 1, '[{"name":"topic","type":"textarea","question":"Topic","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M20 2H4c-1.105 0-2 .895-2 2v16c0 1.105.895 2 2 2h16c1.105 0 2-.895 2-2V4c0-1.105-.895-2-2-2zm0 4l-8 5-8-5V4l8 5 8-5v2z"/></svg>', 0, 'text', '2024-05-15 13:00:00', '2024-05-15 13:00:00', 'Simplify the topic **topic** to make it understandable to children.', 1, 0, '#F1C40F', 'misc', NULL, 'regular'),
	(151, NULL, 'Write News From a Journalist Point of View', 'Craft news articles from the perspective of a journalist.', 'write_news_journalist_view', 1, '[{"name":"topic","type":"textarea","question":"Topic","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M20 2H4c-1.105 0-2 .895-2 2v16c0 1.105.895 2 2 2h16c1.105 0 2-.895 2-2V4c0-1.105-.895-2-2-2zm0 4l-8 5-8-5V4l8 5 8-5v2z"/></svg>', 0, 'text', '2024-05-15 13:05:00', '2024-05-15 13:05:00', 'Write a news article from the perspective of a journalist on the topic **topic**.', 1, 0, '#C2D6D6', 'misc', NULL, 'regular'),
	(152, NULL, 'Generate From RSS Feed', 'Generate content based on the information extracted from a provided RSS feed.', 'generate_from_rss_feed', 1, '[{"name":"rss_feed_url","type":"text","question":"RSS Feed URL","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M20 2H4c-1.105 0-2 .895-2 2v16c0 1.105.895 2 2 2h16c1.105 0 2-.895 2-2V4c0-1.105-.895-2-2-2zm0 4l-8 5-8-5V4l8 5 8-5v2z"/></svg>', 0, 'text', '2024-05-15 13:10:00', '2024-05-15 13:10:00', 'Generate content based on the information extracted from the provided RSS feed: **rss_feed_url**.', 1, 0, '#D6A3A3', 'misc', NULL, 'regular'),
	(153, NULL, 'Undetectable AI', 'Generate content or responses that are indistinguishable from human-generated content.', 'undetectable_ai', 1, '[{"name":"prompt","type":"textarea","question":"Prompt","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M20 2H4c-1.105 0-2 .895-2 2v16c0 1.105.895 2 2 2h16c1.105 0 2-.895 2-2V4c0-1.105-.895-2-2-2zm0 4l-8 5-8-5V4l8 5 8-5v2z"/></svg>', 0, 'text', '2024-05-15 13:15:00', '2024-05-15 13:15:00', 'Generate content or responses that are indistinguishable from human-generated content based on the provided prompt: **prompt**.', 1, 0, '#3498DB', 'misc', NULL, 'regular'),
	(154, NULL, 'Pros and Cons', 'Generate a list of pros and cons for any given topic.', 'pros_and_cons', 1, '[{"name":"topic","type":"textarea","question":"Topic","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M20 2H4c-1.105 0-2 .895-2 2v16c0 1.105.895 2 2 2h16c1.105 0 2-.895 2-2V4c0-1.105-.895-2-2-2zm0 4l-8 5-8-5V4l8 5 8-5v2z"/></svg>', 0, 'text', '2024-05-15 13:20:00', '2024-05-15 13:20:00', 'Generate a list of pros and cons for the topic **topic**.', 1, 0, '#F1C40F', 'misc', NULL, 'regular'),
	(155, NULL, 'Real Estate Listing', 'Generate real estate listings for properties based on specified criteria.', 'real_estate_listing', 1, '[{"name":"criteria","type":"textarea","question":"Criteria","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M20 2H4c-1.105 0-2 .895-2 2v16c0 1.105.895 2 2 2h16c1.105 0 2-.895 2-2V4c0-1.105-.895-2-2-2zm0 4l-8 5-8-5V4l8 5 8-5v2z"/></svg>', 0, 'text', '2024-05-15 13:25:00', '2024-05-15 13:25:00', 'Generate real estate listings for properties based on the following criteria: **criteria**.', 1, 0, '#C2D6D6', 'misc', NULL, 'regular'),
	(156, NULL, 'Prompt Generator', 'Generate creative prompts to inspire writing, brainstorming, or idea generation.', 'prompt_generator', 1, '[{"name":"type","type":"text","question":"Type","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M20 2H4c-1.105 0-2 .895-2 2v16c0 1.105.895 2 2 2h16c1.105 0 2-.895 2-2V4c0-1.105-.895-2-2-2zm0 4l-8 5-8-5V4l8 5 8-5v2z"/></svg>', 0, 'text', '2024-05-15 13:30:00', '2024-05-15 13:30:00', 'Generate creative prompts of type **type** to inspire writing, brainstorming, or idea generation.', 1, 0, '#D6A3A3', 'misc', NULL, 'regular'),
	(157, NULL, 'Realtime Voice Chat', 'AI Realtime Voice Chat', 'ai_realtime_voice_chat', 1, '[{\\"name\\":\\"your_description\\",\\"type\\":\\"textarea\\",\\"question\\":\\"Description\\",\\"select\\":\\"\\"}]', '<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" stroke-width="2" stroke="black" fill="none" viewBox="0 0 24 24"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M6 4l6 16l6 -16" /></svg>', 0, 'text', '2026-07-24 11:11:13', '2026-07-24 11:11:13', NULL, 0, 0, '#A3D6C2', 'blog', NULL, 'regular'),
	(158, NULL, 'AI Video to Video', 'Bring your static images to life and create visually compelling videos effortlessly.', 'ai_video_to_video', 1, '[{"name":"your_description","type":"textarea","question":"Description","select":""}]', '<svg xmlns="http://www.w3.org/2000/svg" \n width="48" height="48" stroke-width="2" stroke="black" fill="none" viewBox="0 0 24 24"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M6 4l6 16l6 -16" /></svg>', 0, 'video-to-video', '2026-07-24 11:11:13', '2026-07-24 11:11:13', NULL, 0, 0, '#A3D6C2', 'video-to-video', NULL, 'regular');

-- Dumping structure for table magicai.openai_chat_category
CREATE TABLE IF NOT EXISTS `openai_chat_category` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `chatbot_id` bigint DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `short_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `instructions` text COLLATE utf8mb4_unicode_ci,
  `first_message` text COLLATE utf8mb4_unicode_ci,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `human_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `helps_with` text COLLATE utf8mb4_unicode_ci,
  `prompt_prefix` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `chat_completions` text COLLATE utf8mb4_unicode_ci,
  `plan` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assistant` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.openai_chat_category: ~0 rows (approximately)
INSERT INTO `openai_chat_category` (`id`, `user_id`, `chatbot_id`, `name`, `short_name`, `slug`, `description`, `instructions`, `first_message`, `role`, `human_name`, `helps_with`, `prompt_prefix`, `image`, `color`, `created_at`, `updated_at`, `chat_completions`, `plan`, `category`, `assistant`) VALUES
	(1, NULL, NULL, 'Default AI Chat Bot', 'ACB', 'ai-chat-bot', 'Default', NULL, NULL, 'default', '', '', '', '', '#A3D6C2', '2023-05-15 20:34:57', '2023-05-15 20:39:11', NULL, NULL, NULL, NULL),
	(2, NULL, NULL, 'Finance Expert', 'FE', 'finance-expert', 'Personal Finance Expert', NULL, NULL, 'Finance Expert', 'Allison Burgers', 'I can help you with managing your finance', 'As a personal finance expert,', NULL, '#DBD5F5', '2023-05-15 20:34:57', '2023-05-15 20:39:11', NULL, NULL, NULL, NULL),
	(3, NULL, NULL, 'Nutritionist', 'N', 'nutritionist', 'Personal Nutritionist', NULL, NULL, 'Nutritionist', 'Employes Mustwashhands', 'I can assist you with nutrition-related information or questions', 'As a nutritionist,', NULL, '#EDBBBE', '2023-05-15 20:34:57', '2023-05-15 20:39:11', NULL, NULL, NULL, NULL),
	(4, NULL, NULL, 'Career Counselor', 'CC', 'career-counselor', 'Personal Career Counselor', NULL, NULL, 'Career Counselor', 'Neil Feetstrong', 'I can assist you with your career-related inquiries or concerns', 'As a career counselor,', NULL, '#D4D4E2', '2023-05-15 20:34:57', '2023-05-15 20:39:11', NULL, NULL, NULL, NULL),
	(5, NULL, NULL, 'Time Management Consultant', 'TMC', 'time-management-consultant', 'Personal Time Management Consultant', NULL, NULL, 'Time Management Consultant', 'Sarman Yellow', 'I can assist you with improving your time management skills or addressing any time management challenges you may be facing', 'As a time management consultant,', NULL, '#D6CBA3', '2023-05-15 20:34:57', '2023-05-15 20:39:11', NULL, NULL, NULL, NULL),
	(6, NULL, NULL, 'Language Tutor', 'LT', 'language-tutor', 'Personal Language Tutor', NULL, NULL, 'Language Tutor', 'Sherlock Jonas', 'I can assist you with your language learning goals or provide guidance on language-related topics', 'As a language tutor,', NULL, '#EACCEB', '2023-05-15 20:34:57', '2023-05-15 20:39:11', NULL, NULL, NULL, NULL),
	(7, NULL, NULL, 'Cybersecurity Expert', 'CE', 'cybersecurity-expert', 'Cybersecurity Expert', NULL, NULL, 'Cybersecurity Expert', 'Mr. Robot', 'I can assist you with your cybersecurity concerns or provide information and guidance related to cybersecurity', 'As a cybersecurity expert, ', NULL, '#BDE3E3', '2023-05-15 20:34:57', '2023-05-15 20:39:11', NULL, NULL, NULL, NULL),
	(8, NULL, NULL, 'Interior Designer', 'ID', 'interior-designer', 'Personal Interior Designer', NULL, NULL, 'Interior Designer', 'Olivia Sinclair', 'I can assist you with your interior design needs or provide guidance on creating beautiful and functional spaces', 'As an interior designer, ', NULL, '#F0D1CD', '2023-05-15 20:34:57', '2023-05-15 20:39:11', NULL, NULL, NULL, NULL),
	(9, NULL, NULL, 'Parenting Coach', 'PC', 'parenting-coach', 'Personal Parenting Coach', NULL, NULL, 'Parenting Coach', 'Alexandra Stevens', 'I can assist you with your parenting questions or provide guidance and support in raising children', 'As a parenting coach, ', NULL, '#A3D6C2', '2023-05-15 20:34:57', '2023-05-15 20:39:11', NULL, NULL, NULL, NULL),
	(10, NULL, NULL, 'Fitness Trainer', 'FT', 'fitness-trainer', 'Personal Fitness Trainer', NULL, NULL, 'Fitness Trainer', 'Mert Karapinar', 'I can assist you with your fitness goals or provide guidance and advice on exercise, nutrition, and overall wellness', 'As a fitness trainer, ', NULL, '#D2D6DF', '2023-05-15 20:34:57', '2023-05-15 20:39:11', NULL, NULL, NULL, NULL),
	(11, NULL, NULL, 'Travel Advisor', 'TA', 'travel-advisor', 'Personal Travel Advisor', NULL, NULL, 'Travel Advisor', 'Bilbo Harries', 'I can assist you with your travel plans, provide destination recommendations, or offer guidance on travel-related inquiries', 'As a travel advisor,', NULL, '#BFE3EB', '2023-05-15 20:34:57', '2023-05-15 20:34:57', NULL, NULL, NULL, NULL),
	(12, NULL, NULL, 'Sustainability Expert', 'SE', 'sustainability-expert', 'Sustainability Expert', NULL, NULL, 'Sustainability Expert', 'Viabil Ity', 'I can assist you with your sustainability goals, provide information on sustainable practices, or offer guidance on living a more environmentally friendly lifestyle', 'As a sustainability expert', NULL, '#ECDBC1', '2023-05-15 20:34:57', '2023-05-15 20:34:57', NULL, NULL, NULL, NULL),
	(13, NULL, NULL, 'Event Planner', 'EP', 'event planner', 'Event Planner', NULL, NULL, 'Event Planner', 'Jack Groomer', 'I can assist you with planning and organizing your upcoming event, providing advice on event management, or offering guidance on creating memorable and successful events', 'As an event planner,', NULL, '#E3E3BD', '2023-05-15 20:34:57', '2023-05-15 20:34:57', NULL, NULL, NULL, NULL),
	(14, NULL, NULL, 'VisionAI', 'VI', 'ai_vision', 'Image PDF Expert', NULL, NULL, 'Image Expert', 'VisionAI', 'I can assist you with PDF or Images-related information or questions', 'As a VisionAI,', 'assets/img/vision.png', '#EDBBBE', '2023-05-15 20:34:57', '2023-05-15 20:39:11', '[{"role": "system", "content": "You are a Vision AI assistant."}, {"role": "user", "content": "What objects are present in this image?"}, {"role": "assistant", "content": "The image contains various objects, including a person, a car, and a building."}, {"role": "user", "content": "Can you describe the color of the car?"}, {"role": "assistant", "content": "The car in the image appears to be red."}]', NULL, NULL, NULL),
	(15, NULL, NULL, 'File Analyzer', 'FA', 'ai_pdf', 'I can assist you with PDF, DOC, DOCX or CSX, XLS, XLSX information or questions', NULL, NULL, 'File Analyzer', 'File Analyzer', 'I can assist you with PDF, DOC, DOCX or CSX, XLS, XLSX information or questions', 'As a File Analyzer', 'assets/img/vision.png', '#EDBBBE', '2023-05-15 20:34:57', '2026-07-24 08:58:24', '[{"role": "system", "content": "You are a PDF AI assistant."}]', NULL, NULL, NULL),
	(16, NULL, NULL, 'Chat Image', 'CI', 'ai_chat_image', 'Image Generator', NULL, NULL, 'Image Generator', 'Image Generator', 'I can assist to generate image by user input', 'As a Pdf AI,', 'assets/img/vision.png', '#EDBBBE', '2023-05-15 20:34:57', '2023-05-15 20:39:11', '[{"role": "system", "content": "You are a Chat Image assistant."}]', '', '', NULL),
	(17, NULL, NULL, 'WebChat', 'WC', 'ai_webchat', 'AI Web Chat', NULL, NULL, 'Web Analyzer', 'AI Web Chat', 'I can assist you with web page content analyzation', 'As a WebPage analyzer,', 'assets/img/vision.png', '#EDBBBE', '2023-05-15 20:34:57', '2023-05-15 20:39:11', '[{"role": "system", "content": "You are a Web Page Analyzer assistant."}]', '', '', NULL),
	(18, NULL, NULL, 'Realtime Voice Chat', 'RVC', 'ai_realtime_voice_chat', 'AI Realtime Voice Chat', NULL, NULL, 'Voice Chatting Bot', 'AI Realtime Voice Chat', 'I can assist you with voice chat', 'As a Voice Chatting', 'assets/img/chat-default.jpg', '#EDBBBE', '2026-07-24 11:11:13', '2026-07-24 11:11:13', '[{"role": "system", "content": "You are a Voice Chatting assistant."}]', '', '', NULL);

-- Dumping structure for table magicai.openai_filters
CREATE TABLE IF NOT EXISTS `openai_filters` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.openai_filters: ~0 rows (approximately)
INSERT INTO `openai_filters` (`id`, `user_id`, `name`) VALUES
	(1, NULL, 'blog'),
	(2, NULL, 'ecommerce'),
	(3, NULL, 'development'),
	(4, NULL, 'advertisement'),
	(5, NULL, 'Custom'),
	(6, NULL, 'social media'),
	(7, NULL, 'voiceover'),
	(8, NULL, 'youtube'),
	(9, NULL, 'rss'),
	(10, NULL, 'academic'),
	(11, NULL, 'business'),
	(12, NULL, 'customer service'),
	(13, NULL, 'entertainment'),
	(14, NULL, 'website'),
	(15, NULL, 'advertising'),
	(16, NULL, 'languages'),
	(17, NULL, 'email'),
	(18, NULL, 'fitness & health'),
	(19, NULL, 'writer'),
	(20, NULL, 'misc');

-- Dumping structure for table magicai.pages
CREATE TABLE IF NOT EXISTS `pages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `titlebar_status` tinyint NOT NULL DEFAULT '1',
  `is_custom` tinyint(1) NOT NULL DEFAULT '0',
  `show_on_footer` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.pages: ~0 rows (approximately)
INSERT INTO `pages` (`id`, `title`, `content`, `slug`, `status`, `created_at`, `updated_at`, `titlebar_status`, `is_custom`, `show_on_footer`) VALUES
	(1, 'About', '<p><img style="display: block; border-radius: 25px; margin-left: auto; margin-right: auto;" src="https://aidefault.liquid-themes.com/wp-content/uploads/2023/08/img-1.jpg" alt="" width="1450" height="761"></p>\r\n<p style="text-align: center;"><span class="highlight">About Us</span></p>\r\n<h1 style="text-align: center;">Shaping the future 🏔️</h1>\r\n<p class="leading" style="max-width: 80%; margin-left: auto; margin-right: auto; text-align: center;">Whether&nbsp;you&rsquo;re&nbsp;a&nbsp;content&nbsp;creator,&nbsp;business&nbsp;owner,&nbsp;or&nbsp;student, <span style="color: rgb(89, 89, 89);">our&nbsp;text&nbsp;generator&nbsp;is&nbsp;an&nbsp;essential&nbsp;tool&nbsp;for&nbsp;boosting&nbsp;your&nbsp;productivity.</span></p>\r\n<hr>\r\n<p>&nbsp;</p>\r\n<p><span class="highlight">Who Are We<br></span></p>\r\n<p class="leading">At MagicAI, we are passionate about harnessing the power of artificial intelligence to unlock limitless creativity and efficiency.<span style="color: rgb(89, 89, 89);"> Our cutting-edge AI Generators are designed to revolutionize the way you create, streamline your workflows, and supercharge your productivity.</span></p>\r\n<p>Our mission is to empower individuals and businesses to unleash their creative potential and achieve extraordinary results.</p>\r\n<p>We believe that AI has the ability to augment human capabilities, enhance decision-making processes, and accelerate innovation.</p>\r\n<p>By developing state-of-the-art AI Generators, we aim to democratize access to advanced AI technologies, enabling users from all backgrounds to excel in their creative endeavors.</p>\r\n<p>&nbsp;</p>\r\n<hr>\r\n<p>&nbsp;</p>\r\n<p><span class="highlight">Invite a Friend</span></p>\r\n<h3>Our Mission</h3>\r\n<p class="leading">We pride ourselves on offering AI Generators that are unmatched in their quality, <span style="color: rgb(89, 89, 89);">versatility, and ease of use. Here&rsquo;s what sets us apart from the competition:</span></p>\r\n<p>With our AI Generators, the possibilities are endless. From generating compelling marketing copy and designing stunning visuals to automating data analysis and creating personalized user experiences, our tools will transform the way you work and help you achieve remarkable outcomes.</p>\r\n<p>Join our community of innovators, creators, and forward-thinkers who are leveraging the power of AI to revolutionize their industries. Start your journey with MagicAI today and unlock the full potential of AI Generators.</p>\r\n<p>Ready to experience the future of creativity? Sign up now and embark on an exciting adventure of limitless possibilities.</p>\r\n<p>&nbsp;</p>\r\n<p style="text-align: center;"><span class="info-box">Still have a question? <span style="color: rgb(8, 53, 248);"><a style="color: rgb(8, 53, 248);" href="#">Browse documentation</a></span> or <span style="color: rgb(8, 53, 248);"><a style="color: rgb(8, 53, 248);" href="#">submit a ticket</a></span>.</span></p>\r\n<p>&nbsp;</p>\r\n<hr>\r\n<p>&nbsp;</p>\r\n<table style="border-collapse: collapse; width: 100%; border-width: 0px; border-style: none;" border="1"><colgroup><col style="width: 20%;"><col style="width: 20%;"><col style="width: 20%;"><col style="width: 20%;"><col style="width: 20%;"></colgroup>\r\n<tbody>\r\n<tr style="text-align: center;">\r\n<td style="border-width: 0px; text-align: center;"><img src="https://aidefault.liquid-themes.com/wp-content/uploads/2023/08/Path-143406.svg" alt="" width="79" height="28"></td>\r\n<td style="border-width: 0px; text-align: center;"><img src="https://aidefault.liquid-themes.com/wp-content/uploads/2023/08/Path-159906.svg" alt="" width="48" height="48"></td>\r\n<td style="border-width: 0px; text-align: center;"><img src="https://aidefault.liquid-themes.com/wp-content/uploads/2023/08/Path-159907.svg" alt="" width="55" height="34"></td>\r\n<td style="border-width: 0px; text-align: center;"><img src="https://aidefault.liquid-themes.com/wp-content/uploads/2023/08/Path-159908.svg" alt="" width="47" height="48"></td>\r\n<td style="border-width: 0px; text-align: center;"><img src="https://aidefault.liquid-themes.com/wp-content/uploads/2023/08/Path-159909.svg" alt="" width="80" height="20"></td>\r\n</tr>\r\n</tbody>\r\n</table>', 'custom-about', 0, '2024-02-12 20:46:38', '2024-02-14 07:11:26', 0, 1, 0),
	(2, 'Privacy and Policy', '<p style="text-align: center;"><span class="highlight">Privacy Policy</span></p>\r\n<h1 style="text-align: center;">Privacy and Policy</h1>\r\n<p class="leading" style="max-width: 80%; margin-left: auto; margin-right: auto; text-align: center;">With our tool, you can generate text in seconds, freeing up your <span style="color: rgb(89, 89, 89);">time to focus on other important tasks that matter the most.</span></p>\r\n<p><img style="display: block; border-radius: 25px; margin-left: auto; margin-right: auto;" src="https://gcdnb.pbrd.co/images/D92RJsyqJdHy.png?o=1" alt="" width="1450" height="761"></p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p><span class="highlight">Privacy Policy</span></p>\r\n<p class="leading">Our newest theme update brings modern and clean design templates to Hub Collection which is already one of the biggest template collections ever built. <span style="color: rgb(89, 89, 89);">These layouts are designed in a simple and unique style that can improve your daily workflow and save you an enormous amount of time.</span></p>\r\n<p>Test built the Liquid app as a Commercial app. This Service is provided by Test and is intended for use as is.</p>\r\n<p>If you choose to use our Service, then you agree to the collection and use of information in relation to this policy. The Personal Information that we collect is used for providing and improving the Service. We will not use or share your information with anyone except as described in this Privacy Policy.</p>\r\n<p>The terms used in this Privacy Policy have the same meanings as in our Terms and Conditions, which are accessible at Liquid unless otherwise defined in this Privacy Policy.</p>\r\n<p>&nbsp;</p>\r\n<hr>\r\n<h5>&nbsp;</h5>\r\n<h5>Fair Use</h5>\r\n<p>For a better experience, while using our Service, we may require you to provide us with certain personally identifiable information, including but not limited to Test. The information that we request will be retained by us and used as described in this privacy policy.</p>\r\n<p>The app does use third-party services that may collect information used to identify you.</p>\r\n<p>Link to the privacy policy of third-party service providers used by the app</p>\r\n<p>We want to inform you that whenever you use our Service, in a case of an error in the app we collect data and information (through third-party products) on your phone called Log Data. This Log Data may include information such as your device Internet Protocol (&ldquo;IP&rdquo;) address, device name, operating system version, the configuration of the app when utilizing our Service, the time and date of your use of the Service, and other statistics.</p>\r\n<p>&nbsp;</p>\r\n<h5 class="lqd-text-el m-0 p-0"><span class="lqd-text-item relative elementor-repeater-item-c3d0556">Cookies</span></h5>\r\n<p>Cookies are files with a small amount of data that are commonly used as anonymous unique identifiers. These are sent to your browser from the websites that you visit and are stored on your device&rsquo;s internal memory.</p>\r\n<p>This Service does not use these &ldquo;cookies&rdquo; explicitly. However, the app may use third-party code and libraries that use &ldquo;cookies&rdquo; to collect information and improve their services. You have the option to either accept or refuse</p>\r\n<p>&nbsp;</p>\r\n<p style="text-align: center;"><span class="info-box">Still have a question? <span style="color: rgb(8, 53, 248);"><a style="color: rgb(8, 53, 248);" href="#">Browse documentation</a></span> or <span style="color: rgb(8, 53, 248);"><a style="color: rgb(8, 53, 248);" href="#">submit a ticket</a>.</span></span></p>', 'custom-privacy-and-policy', 0, '2024-02-12 20:48:09', '2024-02-14 07:15:29', 0, 1, 0),
	(3, 'How It Works', '<p style="text-align: center;">Trusted by these amazing companies</p>\r\n<table style="border-collapse: collapse; width: 100.068%; border-width: 0px;" border="1"><colgroup><col style="width: 25.0342%;"><col style="width: 25.0342%;"><col style="width: 25.0342%;"><col style="width: 25.0342%;"></colgroup>\r\n<tbody>\r\n<tr>\r\n<td style="border-width: 0px;"><img style="display: block; margin-left: auto; margin-right: auto;" src="https://aidefault.liquid-themes.com/wp-content/uploads/2023/08/nike.svg" alt="" width="88" height="32"></td>\r\n<td style="border-width: 0px;"><img style="display: block; margin-left: auto; margin-right: auto;" src="https://aidefault.liquid-themes.com/wp-content/uploads/2023/08/Path-133531.svg" alt="" width="86" height="37"></td>\r\n<td style="border-width: 0px;"><img style="display: block; margin-left: auto; margin-right: auto;" src="https://aidefault.liquid-themes.com/wp-content/uploads/2023/08/Path-46878.svg" alt="" width="49" height="35"></td>\r\n<td style="border-width: 0px;"><img style="display: block; margin-left: auto; margin-right: auto;" src="https://aidefault.liquid-themes.com/wp-content/uploads/2023/08/volkswagen-1.svg" alt="" width="53" height="53"></td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p class="leading" style="text-align: center;">&nbsp;</p>\r\n<p class="leading" style="text-align: center;">At MagicAI, we are passionate about harnessing the power of artificial intelligence to unlock limitless creativity and efficiency.&nbsp;<span style="color: rgb(89, 89, 89);">Our cutting-edge AI Generators are designed to revolutionize the way you create, streamline your workflows, and supercharge your productivity.</span></p>\r\n<p class="leading" style="text-align: center;">&nbsp;</p>\r\n<p><span class="num-block">1</span></p>\r\n<h4>Select a Template</h4>\r\n<p>Our mission is to empower individuals and businesses to unleash their creative potential and achieve extraordinary results. We believe that AI has the ability to augment human capabilities, enhance decision-making processes, and accelerate innovation.</p>\r\n<p>&nbsp;</p>\r\n<p><span class="num-block">2</span></p>\r\n<h4>Explain your idea</h4>\r\n<p>AI generators are sophisticated systems trained on vast amounts of data to learn patterns, understand context, and generate original content. They are designed to mimic human creativity by analyzing existing examples.</p>\r\n<p>&nbsp;</p>\r\n<p><span class="num-block">3</span></p>\r\n<h4>Done!</h4>\r\n<p>By developing state-of-the-art AI Generators, we aim to democratize access to advanced AI technologies, enabling users from all backgrounds to excel in their creative endeavors.</p>\r\n<p>&nbsp;</p>\r\n<p style="text-align: center;"><span class="info-box">Still have a question? <span style="color: rgb(8, 53, 248);"><a style="color: rgb(8, 53, 248);" href="#">Browse documentation</a></span> or <span style="color: rgb(8, 53, 248);"><a style="color: rgb(8, 53, 248);" href="#">submit a ticket</a>.</span></span></p>\r\n<p>&nbsp;</p>\r\n<p><img style="border-radius: 25px;" src="https://gcdnb.pbrd.co/images/OZmBXkQ5MQyH.png?o=1" alt="How it works" width="1620" height="870"></p>\r\n<p>&nbsp;</p>\r\n<p><span class="highlight">Invite a Friend</span></p>\r\n<h4>Affiliate System.</h4>\r\n<p class="leading">We pride ourselves on offering AI Generators that are unmatched in their quality, <span style="color: rgb(89, 89, 89);">versatility, and ease of use. Here&rsquo;s what sets us apart from the competition:</span></p>\r\n<h5>Done!</h5>\r\n<p>Join our community of innovators, creators, and forward-thinkers who are leveraging the power of AI to revolutionize their industries. Start your journey with MagicAI today and unlock the full potential of AI Generators.</p>\r\n<p>&nbsp;</p>\r\n<p><img src="https://aidefault.liquid-themes.com/wp-content/uploads/2023/08/icon-2.jpg" alt="" width="48" height="48"></p>\r\n<h5>Invite your Friend</h5>\r\n<p>With our AI Generators, the possibilities are endless. From generating compelling marketing copy and designing stunning visuals to automating data analysis and creating personalized user experiences.</p>\r\n<p>&nbsp;</p>\r\n<p><img src="https://aidefault.liquid-themes.com/wp-content/uploads/2023/08/icon-3.jpg" alt="" width="48" height="48"></p>\r\n<h5>Make Money</h5>\r\n<p>Ready to experience the future of creativity? Sign up now and embark on an exciting adventure of limitless possibilities.</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p style="text-align: center;"><span class="info-box">Still have a question? <span style="color: rgb(8, 53, 248);"><a style="color: rgb(8, 53, 248);" href="#">Browse documentation</a></span> or <span style="color: rgb(8, 53, 248);"><a style="color: rgb(8, 53, 248);" href="#">submit a ticket</a>.</span></span></p>', 'custom-how-it-works', 0, '2024-02-12 20:49:08', '2024-02-14 06:37:35', 1, 1, 0),
	(4, 'Features', '<p><img style="border-radius: 25px;" src="https://gcdnb.pbrd.co/images/iTA0Xv7SHrVp.png?o=1" alt="About us" width="1526 &times;" height="866"></p>\r\n<p>&nbsp;</p>\r\n<p><span class="highlight">Introducing</span></p>\r\n<h3 class="lqd-text-el m-0 p-0"><span class="lqd-text-item relative elementor-repeater-item-eaff06a">Custom Chatbots.</span></h3>\r\n<p class="leading">We pride ourselves on offering AI Generators that are unmatched in their quality, <span style="color: rgb(89, 89, 89);">versatility, and ease of use. Here&rsquo;s what sets us apart from the competition:</span></p>\r\n<p>With our AI Generators, the possibilities are endless. From generating compelling marketing copy and designing stunning visuals to automating data analysis and creating personalized user experiences, our tools will transform the way you work and help you achieve remarkable outcomes.</p>\r\n<p>Join our community of innovators, creators, and forward-thinkers who are leveraging the power of AI to revolutionize their industries. Start your journey with MagicAI today and unlock the full potential of AI Generators.</p>\r\n<p>Ready to experience the future of creativity? Sign up now and embark on an exciting adventure of limitless possibilities.</p>\r\n<ul style="list-style: disc; list-style-position: inside;">\r\n<li><strong>New &mdash;</strong>&nbsp;AI Voiceover in 30 Languages</li>\r\n<li><strong>New &mdash;</strong>&nbsp;Custom Avatar for Chatbot</li>\r\n<li><strong>Improved &mdash;</strong>&nbsp;Auto Translate</li>\r\n</ul>', 'custom-features', 0, '2024-02-14 05:27:38', '2024-02-14 06:25:50', 1, 1, 0);

-- Dumping structure for table magicai.password_reset_tokens
CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.password_reset_tokens: ~0 rows (approximately)

-- Dumping structure for table magicai.payment_proofs
CREATE TABLE IF NOT EXISTS `payment_proofs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `order_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `plan_id` bigint unsigned NOT NULL,
  `total_amount` decimal(15,2) DEFAULT NULL,
  `proof_image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_proofs_user_id_foreign` (`user_id`),
  KEY `payment_proofs_plan_id_foreign` (`plan_id`),
  CONSTRAINT `payment_proofs_plan_id_foreign` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payment_proofs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.payment_proofs: ~0 rows (approximately)

-- Dumping structure for table magicai.paystack_payment_infos
CREATE TABLE IF NOT EXISTS `paystack_payment_infos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trans` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trxref` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `plan_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paystack_payment_infos_user_id_foreign` (`user_id`),
  CONSTRAINT `paystack_payment_infos_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.paystack_payment_infos: ~0 rows (approximately)

-- Dumping structure for table magicai.pdf_data
CREATE TABLE IF NOT EXISTS `pdf_data` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `chat_id` int NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `vector` json NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.pdf_data: ~0 rows (approximately)

-- Dumping structure for table magicai.pebblely
CREATE TABLE IF NOT EXISTS `pebblely` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.pebblely: ~0 rows (approximately)

-- Dumping structure for table magicai.permissions
CREATE TABLE IF NOT EXISTS `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.permissions: ~0 rows (approximately)
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
	(1, 'marketplace', 'web', '2026-07-24 08:58:23', '2026-07-24 08:58:23'),
	(2, 'themes', 'web', '2026-07-24 08:58:23', '2026-07-24 08:58:23'),
	(3, 'user_management', 'web', '2026-07-24 08:58:23', '2026-07-24 08:58:23'),
	(4, 'announcements', 'web', '2026-07-24 08:58:23', '2026-07-24 08:58:23'),
	(5, 'google_adsense', 'web', '2026-07-24 08:58:23', '2026-07-24 08:58:23'),
	(6, 'support_requests', 'web', '2026-07-24 08:58:23', '2026-07-24 08:58:23'),
	(7, 'templates', 'web', '2026-07-24 08:58:23', '2026-07-24 08:58:23'),
	(8, 'chat_settings', 'web', '2026-07-24 08:58:23', '2026-07-24 08:58:23'),
	(9, 'frontend', 'web', '2026-07-24 08:58:23', '2026-07-24 08:58:23'),
	(10, 'finance', 'web', '2026-07-24 08:58:23', '2026-07-24 08:58:23'),
	(11, 'pages', 'web', '2026-07-24 08:58:23', '2026-07-24 08:58:23'),
	(12, 'blog', 'web', '2026-07-24 08:58:23', '2026-07-24 08:58:23'),
	(13, 'affiliates_admin', 'web', '2026-07-24 08:58:23', '2026-07-24 08:58:23'),
	(14, 'coupons_admin', 'web', '2026-07-24 08:58:23', '2026-07-24 08:58:23'),
	(15, 'email_templates', 'web', '2026-07-24 08:58:23', '2026-07-24 08:58:23'),
	(16, 'introductions', 'web', '2026-07-24 08:58:23', '2026-07-24 08:58:23'),
	(17, 'mailchimp_newsletter', 'web', '2026-07-24 08:58:23', '2026-07-24 08:58:23'),
	(18, 'hubspot', 'web', '2026-07-24 08:58:23', '2026-07-24 08:58:23'),
	(19, 'api_integration', 'web', '2026-07-24 08:58:23', '2026-07-24 08:58:23'),
	(20, 'settings', 'web', '2026-07-24 08:58:23', '2026-07-24 08:58:23'),
	(21, 'site_health', 'web', '2026-07-24 08:58:23', '2026-07-24 08:58:23'),
	(22, 'license', 'web', '2026-07-24 08:58:23', '2026-07-24 08:58:23'),
	(23, 'update', 'web', '2026-07-24 08:58:23', '2026-07-24 08:58:23'),
	(24, 'menu_setting', 'web', '2026-07-24 08:58:23', '2026-07-24 08:58:23'),
	(25, 'VIP_CHAT_WIDGET', 'web', '2026-07-24 08:58:23', '2026-07-24 08:58:23');

-- Dumping structure for table magicai.personal_access_tokens
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.personal_access_tokens: ~0 rows (approximately)

-- Dumping structure for table magicai.photo_studios
CREATE TABLE IF NOT EXISTS `photo_studios` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `photo` text COLLATE utf8mb4_unicode_ci,
  `payload` text COLLATE utf8mb4_unicode_ci,
  `credits` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.photo_studios: ~0 rows (approximately)

-- Dumping structure for table magicai.plans
CREATE TABLE IF NOT EXISTS `plans` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` double NOT NULL DEFAULT '0',
  `price_tax_included` tinyint(1) DEFAULT '0',
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USD',
  `frequency` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'monthly',
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  `stripe_product_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ai_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `max_tokens` bigint DEFAULT NULL,
  `can_create_ai_images` tinyint(1) DEFAULT NULL,
  `plan_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'all',
  `features` text COLLATE utf8mb4_unicode_ci,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'subscription',
  `credit_system_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'separated',
  `shared_credits_amount` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `shared_credit_model_overrides` json DEFAULT NULL,
  `shared_credit_feature_limits` json DEFAULT NULL,
  `is_team_plan` tinyint(1) NOT NULL DEFAULT '0',
  `plan_allow_seat` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `trial_days` int NOT NULL DEFAULT '0',
  `open_ai_items` json DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `plan_ai_tools` json NOT NULL,
  `plan_features` json NOT NULL,
  `social_media_agent_limits` json DEFAULT NULL,
  `social_media_automation_limits` json DEFAULT NULL,
  `blogpilot_limits` json DEFAULT NULL,
  `marketing_bot_limits` json DEFAULT NULL,
  `default_ai_model` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'gpt-3.5-turbo',
  `ai_models` json DEFAULT NULL,
  `user_api` tinyint(1) NOT NULL DEFAULT '0',
  `hidden_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hidden` tinyint(1) NOT NULL DEFAULT '0',
  `max_subscribe` int DEFAULT NULL,
  `chatbot_limit` int DEFAULT NULL,
  `chatbot_channels` json DEFAULT NULL,
  `chatbot_human_agent` tinyint(1) NOT NULL DEFAULT '1',
  `last_date` date DEFAULT NULL,
  `reset_credits_on_renewal` tinyint(1) NOT NULL DEFAULT '0',
  `multi_model_support` tinyint(1) DEFAULT '0',
  `voice_call_seconds_limit` int NOT NULL DEFAULT '-1',
  `phone_call_agent_seconds_limit` int NOT NULL DEFAULT '-1',
  `ai_chat_pro_connectors` json DEFAULT NULL,
  `affiliate_status` tinyint(1) NOT NULL DEFAULT '1',
  `model_council_support` tinyint(1) DEFAULT '0',
  `deep_research_request_limit` int NOT NULL DEFAULT '5',
  `ai_agent_workflow_limit` int DEFAULT NULL,
  `ai_agent_channel_limit` int DEFAULT NULL,
  `ai_agent_message_limit` int DEFAULT NULL,
  `ai_agent_memory_limit` int DEFAULT NULL,
  `video_dubbing_seconds_limit` int NOT NULL DEFAULT '20',
  `ugc_videos_limit` int NOT NULL DEFAULT '-1',
  `ai_captions_access` tinyint(1) NOT NULL DEFAULT '1',
  `ai_captions_minutes` int NOT NULL DEFAULT '30',
  `ugc_creator_videos_limit` int NOT NULL DEFAULT '-1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.plans: ~0 rows (approximately)

-- Dumping structure for table magicai.privacy_terms
CREATE TABLE IF NOT EXISTS `privacy_terms` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lang` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.privacy_terms: ~0 rows (approximately)

-- Dumping structure for table magicai.products
CREATE TABLE IF NOT EXISTS `products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` int DEFAULT NULL,
  `key_features` text COLLATE utf8mb4_unicode_ci,
  `user_id` bigint unsigned DEFAULT NULL,
  `company_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `products_user_id_foreign` (`user_id`),
  KEY `products_company_id_foreign` (`company_id`),
  CONSTRAINT `products_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE SET NULL,
  CONSTRAINT `products_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.products: ~0 rows (approximately)

-- Dumping structure for table magicai.prompt_library
CREATE TABLE IF NOT EXISTS `prompt_library` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prompt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int NOT NULL,
  `show_for_all` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.prompt_library: ~0 rows (approximately)

-- Dumping structure for table magicai.rate_limits
CREATE TABLE IF NOT EXISTS `rate_limits` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` int NOT NULL DEFAULT '0',
  `last_attempt_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'image',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.rate_limits: ~0 rows (approximately)

-- Dumping structure for table magicai.recent_search_keys
CREATE TABLE IF NOT EXISTS `recent_search_keys` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `keyword` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recent_search_keys_keyword_index` (`keyword`),
  KEY `recent_search_keys_user_keyword_index` (`user_id`,`keyword`),
  KEY `recent_search_keys_user_created_index` (`user_id`,`created_at`),
  CONSTRAINT `recent_search_keys_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.recent_search_keys: ~0 rows (approximately)

-- Dumping structure for table magicai.referers
CREATE TABLE IF NOT EXISTS `referers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `session_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `referer` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `domain` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  KEY `referers_domain_index` (`domain`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.referers: ~0 rows (approximately)
INSERT INTO `referers` (`id`, `session_id`, `referer`, `domain`, `created_at`) VALUES
	(1, 'ERJyySJSjEpWdN4Tk0XsDU3Ir1NJ6CXeizRPhnr9', 'https://magicai.test/login', 'magicai.test', '2026-07-24 09:21:17'),
	(2, 'NYBJBA13nxgbo9uHQO3PNwrcMSlSjNAi3b4e7pOD', 'https://magicai.test/login', 'magicai.test', '2026-07-24 09:30:42');

-- Dumping structure for table magicai.revenuecat_products
CREATE TABLE IF NOT EXISTS `revenuecat_products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `plan_id` bigint unsigned DEFAULT NULL,
  `gatewayproduct_id` bigint unsigned DEFAULT NULL,
  `entitlement_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `package_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `apple_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amazon_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `revenuecat_products_plan_id_foreign` (`plan_id`),
  KEY `revenuecat_products_gatewayproduct_id_foreign` (`gatewayproduct_id`),
  CONSTRAINT `revenuecat_products_gatewayproduct_id_foreign` FOREIGN KEY (`gatewayproduct_id`) REFERENCES `gatewayproducts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `revenuecat_products_plan_id_foreign` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.revenuecat_products: ~0 rows (approximately)

-- Dumping structure for table magicai.roles
CREATE TABLE IF NOT EXISTS `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.roles: ~0 rows (approximately)
INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
	(1, 'user', 'web', '2026-07-24 08:58:23', '2026-07-24 08:58:23'),
	(2, 'admin', 'web', '2026-07-24 08:58:23', '2026-07-24 08:58:23'),
	(3, 'super_admin', 'web', '2026-07-24 08:58:23', '2026-07-24 08:58:23');

-- Dumping structure for table magicai.role_has_permissions
CREATE TABLE IF NOT EXISTS `role_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.role_has_permissions: ~0 rows (approximately)

-- Dumping structure for table magicai.scheduled_posts
CREATE TABLE IF NOT EXISTS `scheduled_posts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `automation_platform_id` bigint DEFAULT NULL,
  `command_running` tinyint(1) NOT NULL DEFAULT '0',
  `last_run_date` date DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `company_id` bigint DEFAULT NULL,
  `platform` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `products` text COLLATE utf8mb4_unicode_ci,
  `campaign_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `campaign_target` longtext COLLATE utf8mb4_unicode_ci,
  `topics` longtext COLLATE utf8mb4_unicode_ci,
  `is_seo` tinyint(1) NOT NULL DEFAULT '0',
  `tone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `length` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_email` tinyint(1) NOT NULL DEFAULT '0',
  `is_repeated` tinyint(1) NOT NULL DEFAULT '0',
  `repeat_period` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `repeat_start_date` date DEFAULT NULL,
  `repeat_time` time DEFAULT NULL,
  `visual_format` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `visual_ratio` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `posted_at` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prompt` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `command_running_last_run_date_index` (`command_running`,`last_run_date`,`repeat_period`,`repeat_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.scheduled_posts: ~0 rows (approximately)

-- Dumping structure for table magicai.settings
CREATE TABLE IF NOT EXISTS `settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `invoice_currency` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_website` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_state` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_postal` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_vat` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `default_currency` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '2',
  `tax_rate` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripe_active` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `stripe_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripe_secret` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripe_base_url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'https://api.stripe.com',
  `bank_transfer_active` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `bank_transfer_instructions` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_transfer_informations` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'MagicAI',
  `site_url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'https://liquid-themes.com',
  `site_email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_analytics_active` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `google_analytics_code` text COLLATE utf8mb4_unicode_ci,
  `logo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'magicAI-logo.svg',
  `favicon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_title` text COLLATE utf8mb4_unicode_ci,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `facebook_active` tinyint(1) NOT NULL DEFAULT '0',
  `facebook_api_key` text COLLATE utf8mb4_unicode_ci,
  `facebook_api_secret` text COLLATE utf8mb4_unicode_ci,
  `facebook_redirect_url` text COLLATE utf8mb4_unicode_ci,
  `github_active` tinyint(1) NOT NULL DEFAULT '0',
  `github_api_key` text COLLATE utf8mb4_unicode_ci,
  `github_api_secret` text COLLATE utf8mb4_unicode_ci,
  `github_redirect_url` text COLLATE utf8mb4_unicode_ci,
  `google_active` tinyint(1) NOT NULL DEFAULT '0',
  `google_api_key` text COLLATE utf8mb4_unicode_ci,
  `google_api_secret` text COLLATE utf8mb4_unicode_ci,
  `google_redirect_url` text COLLATE utf8mb4_unicode_ci,
  `twitter_active` tinyint(1) NOT NULL DEFAULT '0',
  `twitter_api_key` text COLLATE utf8mb4_unicode_ci,
  `twitter_api_secret` text COLLATE utf8mb4_unicode_ci,
  `twitter_redirect_url` text COLLATE utf8mb4_unicode_ci,
  `register_active` tinyint(1) NOT NULL DEFAULT '1',
  `default_country` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'United States',
  `smtp_host` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_port` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_sender_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_encryption` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'TLS',
  `openai_api_secret` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `logo_path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'assets/img/logo/magicAI-logo.svg',
  `favicon_path` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `openai_default_model` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'gpt-3.5-turbo',
  `openai_default_language` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en-US',
  `openai_default_tone_of_voice` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'professional',
  `openai_default_creativity` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0.75',
  `openai_max_input_length` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '300',
  `openai_max_output_length` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '200',
  `affiliate_minimum_withdrawal` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '10',
  `affiliate_commission_percentage` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '10',
  `frontend_pricing_section` tinyint(1) NOT NULL DEFAULT '1',
  `frontend_custom_templates_section` tinyint(1) NOT NULL DEFAULT '1',
  `frontend_business_partners_section` tinyint(1) NOT NULL DEFAULT '1',
  `frontend_additional_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `frontend_custom_js` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `frontend_custom_css` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `frontend_footer_facebook` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `frontend_footer_twitter` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `frontend_footer_instagram` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `script_version` double NOT NULL DEFAULT '10',
  `logo_collapsed` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'magicAI-logo-Collapsed.png',
  `logo_collapsed_path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'assets/img/logo/magicAI-logo-Collapsed.png',
  `stripe_status_for_now` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'disabled',
  `logo_dark` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'magicAI-logo-dark.svg',
  `logo_dashboard` text COLLATE utf8mb4_unicode_ci,
  `logo_dashboard_dark` text COLLATE utf8mb4_unicode_ci,
  `logo_collapsed_dark` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'magicAI-logo-collapsed-dark.svg',
  `logo_2x` text COLLATE utf8mb4_unicode_ci,
  `logo_dark_2x` text COLLATE utf8mb4_unicode_ci,
  `logo_dashboard_2x` text COLLATE utf8mb4_unicode_ci,
  `logo_dashboard_dark_2x` text COLLATE utf8mb4_unicode_ci,
  `logo_collapsed_2x` text COLLATE utf8mb4_unicode_ci,
  `logo_collapsed_dark_2x` text COLLATE utf8mb4_unicode_ci,
  `logo_dark_path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'assets/img/logo/magicAI-logo-dark.svg',
  `logo_dashboard_path` text COLLATE utf8mb4_unicode_ci,
  `logo_dashboard_dark_path` text COLLATE utf8mb4_unicode_ci,
  `logo_collapsed_dark_path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'assets/img/logo/magicAI-logo-collapsed-dark.svg',
  `logo_2x_path` text COLLATE utf8mb4_unicode_ci,
  `logo_dark_2x_path` text COLLATE utf8mb4_unicode_ci,
  `logo_dashboard_2x_path` text COLLATE utf8mb4_unicode_ci,
  `logo_dashboard_dark_2x_path` text COLLATE utf8mb4_unicode_ci,
  `logo_collapsed_2x_path` text COLLATE utf8mb4_unicode_ci,
  `logo_collapsed_dark_2x_path` text COLLATE utf8mb4_unicode_ci,
  `feature_ai_writer` tinyint(1) NOT NULL DEFAULT '1',
  `feature_ai_image` tinyint(1) NOT NULL DEFAULT '1',
  `feature_ai_chat` tinyint(1) NOT NULL DEFAULT '1',
  `feature_ai_code` tinyint(1) NOT NULL DEFAULT '1',
  `feature_ai_voice_clone` tinyint(1) NOT NULL DEFAULT '0',
  `feature_ai_speech_to_text` tinyint(1) NOT NULL DEFAULT '1',
  `feature_affilates` tinyint(1) NOT NULL DEFAULT '1',
  `logo_sticky` text COLLATE utf8mb4_unicode_ci,
  `logo_sticky_path` text COLLATE utf8mb4_unicode_ci,
  `logo_sticky_2x` text COLLATE utf8mb4_unicode_ci,
  `logo_sticky_2x_path` text COLLATE utf8mb4_unicode_ci,
  `meta_keywords` text COLLATE utf8mb4_unicode_ci,
  `gdpr_status` tinyint(1) NOT NULL DEFAULT '0',
  `gdpr_button` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Accept',
  `gdpr_content` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'This website uses cookies to improve your web experience.',
  `menu_options` text COLLATE utf8mb4_unicode_ci,
  `privacy_enable` tinyint(1) NOT NULL DEFAULT '0',
  `privacy_enable_login` tinyint(1) NOT NULL DEFAULT '0',
  `privacy_content` text COLLATE utf8mb4_unicode_ci,
  `terms_content` text COLLATE utf8mb4_unicode_ci,
  `login_without_confirmation` tinyint(1) NOT NULL DEFAULT '1',
  `feature_ai_voiceover` tinyint(1) DEFAULT '1',
  `gcs_file` text COLLATE utf8mb4_unicode_ci,
  `gcs_name` text COLLATE utf8mb4_unicode_ci,
  `frontend_code_before_head` text COLLATE utf8mb4_unicode_ci,
  `frontend_code_before_body` text COLLATE utf8mb4_unicode_ci,
  `dashboard_code_before_head` text COLLATE utf8mb4_unicode_ci,
  `dashboard_code_before_body` text COLLATE utf8mb4_unicode_ci,
  `feature_ai_article_wizard` tinyint NOT NULL DEFAULT '1',
  `feature_ai_vision` tinyint NOT NULL DEFAULT '1',
  `feature_ai_pdf` tinyint NOT NULL DEFAULT '1',
  `feature_ai_chat_image` tinyint NOT NULL DEFAULT '1',
  `mobile_payment_active` tinyint(1) NOT NULL DEFAULT '0',
  `feature_ai_rewriter` tinyint NOT NULL DEFAULT '1',
  `feature_ai_youtube` tinyint NOT NULL DEFAULT '1',
  `feature_ai_rss` tinyint NOT NULL DEFAULT '1',
  `team_functionality` tinyint(1) NOT NULL DEFAULT '0',
  `feature_ai_advanced_editor` tinyint(1) NOT NULL DEFAULT '1',
  `user_count` int NOT NULL DEFAULT '0',
  `free_open_ai_items` json DEFAULT NULL,
  `user_api_option` tinyint NOT NULL DEFAULT '0',
  `auth_view_options` text COLLATE utf8mb4_unicode_ci,
  `tour_seen` tinyint(1) NOT NULL DEFAULT '1',
  `recaptcha_login` tinyint(1) NOT NULL DEFAULT '0',
  `recaptcha_register` tinyint(1) NOT NULL DEFAULT '0',
  `recaptcha_sitekey` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recaptcha_secretkey` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `login_with_otp` tinyint(1) NOT NULL DEFAULT '0',
  `synthesia_secret_key` text COLLATE utf8mb4_unicode_ci,
  `pebblely_key` text COLLATE utf8mb4_unicode_ci,
  `mrrobot_name` text COLLATE utf8mb4_unicode_ci,
  `mrrobot_search_words` text COLLATE utf8mb4_unicode_ci,
  `aimlapi_key` text COLLATE utf8mb4_unicode_ci,
  `ai_music_model` text COLLATE utf8mb4_unicode_ci,
  `x_logo` text COLLATE utf8mb4_unicode_ci,
  `xx_logo` text COLLATE utf8mb4_unicode_ci,
  `heygen_secret_key` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.settings: ~0 rows (approximately)
INSERT INTO `settings` (`id`, `invoice_currency`, `invoice_name`, `invoice_website`, `invoice_address`, `invoice_city`, `invoice_state`, `invoice_postal`, `invoice_country`, `invoice_phone`, `invoice_vat`, `default_currency`, `tax_rate`, `stripe_active`, `stripe_key`, `stripe_secret`, `stripe_base_url`, `bank_transfer_active`, `bank_transfer_instructions`, `bank_transfer_informations`, `site_name`, `site_url`, `site_email`, `google_analytics_active`, `google_analytics_code`, `logo`, `favicon`, `meta_title`, `meta_description`, `facebook_active`, `facebook_api_key`, `facebook_api_secret`, `facebook_redirect_url`, `github_active`, `github_api_key`, `github_api_secret`, `github_redirect_url`, `google_active`, `google_api_key`, `google_api_secret`, `google_redirect_url`, `twitter_active`, `twitter_api_key`, `twitter_api_secret`, `twitter_redirect_url`, `register_active`, `default_country`, `smtp_host`, `smtp_port`, `smtp_username`, `smtp_password`, `smtp_email`, `smtp_sender_name`, `smtp_encryption`, `openai_api_secret`, `created_at`, `updated_at`, `logo_path`, `favicon_path`, `openai_default_model`, `openai_default_language`, `openai_default_tone_of_voice`, `openai_default_creativity`, `openai_max_input_length`, `openai_max_output_length`, `affiliate_minimum_withdrawal`, `affiliate_commission_percentage`, `frontend_pricing_section`, `frontend_custom_templates_section`, `frontend_business_partners_section`, `frontend_additional_url`, `frontend_custom_js`, `frontend_custom_css`, `frontend_footer_facebook`, `frontend_footer_twitter`, `frontend_footer_instagram`, `script_version`, `logo_collapsed`, `logo_collapsed_path`, `stripe_status_for_now`, `logo_dark`, `logo_dashboard`, `logo_dashboard_dark`, `logo_collapsed_dark`, `logo_2x`, `logo_dark_2x`, `logo_dashboard_2x`, `logo_dashboard_dark_2x`, `logo_collapsed_2x`, `logo_collapsed_dark_2x`, `logo_dark_path`, `logo_dashboard_path`, `logo_dashboard_dark_path`, `logo_collapsed_dark_path`, `logo_2x_path`, `logo_dark_2x_path`, `logo_dashboard_2x_path`, `logo_dashboard_dark_2x_path`, `logo_collapsed_2x_path`, `logo_collapsed_dark_2x_path`, `feature_ai_writer`, `feature_ai_image`, `feature_ai_chat`, `feature_ai_code`, `feature_ai_voice_clone`, `feature_ai_speech_to_text`, `feature_affilates`, `logo_sticky`, `logo_sticky_path`, `logo_sticky_2x`, `logo_sticky_2x_path`, `meta_keywords`, `gdpr_status`, `gdpr_button`, `gdpr_content`, `menu_options`, `privacy_enable`, `privacy_enable_login`, `privacy_content`, `terms_content`, `login_without_confirmation`, `feature_ai_voiceover`, `gcs_file`, `gcs_name`, `frontend_code_before_head`, `frontend_code_before_body`, `dashboard_code_before_head`, `dashboard_code_before_body`, `feature_ai_article_wizard`, `feature_ai_vision`, `feature_ai_pdf`, `feature_ai_chat_image`, `mobile_payment_active`, `feature_ai_rewriter`, `feature_ai_youtube`, `feature_ai_rss`, `team_functionality`, `feature_ai_advanced_editor`, `user_count`, `free_open_ai_items`, `user_api_option`, `auth_view_options`, `tour_seen`, `recaptcha_login`, `recaptcha_register`, `recaptcha_sitekey`, `recaptcha_secretkey`, `login_with_otp`, `synthesia_secret_key`, `pebblely_key`, `mrrobot_name`, `mrrobot_search_words`, `aimlapi_key`, `ai_music_model`, `x_logo`, `xx_logo`, `heygen_secret_key`) VALUES
	(1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2', NULL, '0', NULL, NULL, 'https://api.stripe.com', '0', NULL, NULL, 'MagicAI', 'https://liquid-themes.com', NULL, '0', NULL, 'magicAI-logo.svg', NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, 1, 'United States', NULL, NULL, NULL, NULL, NULL, NULL, 'TLS', NULL, NULL, '2026-07-24 08:58:19', 'assets/img/logo/magicAI-logo.svg', NULL, 'gpt-3.5-turbo', 'en-US', 'professional', '0.75', '300', '200', '10', '10', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, 10, 'magicAI-logo-Collapsed.png', 'assets/img/logo/magicAI-logo-Collapsed.png', 'disabled', 'magicAI-logo-dark.svg', NULL, NULL, 'magicAI-logo-collapsed-dark.svg', NULL, NULL, NULL, NULL, NULL, NULL, 'assets/img/logo/magicAI-logo-dark.svg', NULL, NULL, 'assets/img/logo/magicAI-logo-collapsed-dark.svg', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, 1, 1, NULL, NULL, NULL, NULL, NULL, 0, 'Accept', 'This website uses cookies to improve your web experience.', NULL, 0, 0, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, '["post_title_generator", "summarize_text", "product_description", "article_generator", "product_name", "testimonial_review", "problem_agitate_solution", "blog_section", "blog_post_ideas", "blog_intros", "blog_conclusion", "facebook_ads", "youtube_video_description", "youtube_video_title", "youtube_video_tag", "instagram_captions", "instagram_hashtag", "social_media_post_tweet", "social_media_post_business", "facebook_headlines", "google_ads_headlines", "google_ads_description", "paragraph_generator", "pros_cons", "meta_description", "faq_generator", "email_generator", "email_answer_generator", "newsletter_generator", "grammar_correction", "tldr_summarization", "ai_image_generator", "custom-generation-eQao5n", "ai_speech_to_text", "ai_code_generator", "ai_article_wizard_generator", "ai_vision", "ai_pdf", "ai_chat_image", "ai_rewriter", "ai_webchat", "ai_video"]', 0, NULL, 1, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- Dumping structure for table magicai.settings_two
CREATE TABLE IF NOT EXISTS `settings_two` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `theme` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default',
  `stable_diffusion_api_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stable_diffusion_default_model` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_recaptcha_status` tinyint(1) NOT NULL DEFAULT '0',
  `google_recaptcha_site_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_recaptcha_secret_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `languages` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'en',
  `languages_default` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `liquid_license_type` text COLLATE utf8mb4_unicode_ci,
  `liquid_license_domain_key` text COLLATE utf8mb4_unicode_ci,
  `openai_default_stream_server` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'backend',
  `ai_image_storage` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'public',
  `stablediffusion_default_language` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en-US',
  `stablediffusion_default_model` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'stable-diffusion-xl-1024-v1-0',
  `unsplash_api_key` text COLLATE utf8mb4_unicode_ci,
  `dalle` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'dall-e-3',
  `daily_limit_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_images_count` int NOT NULL DEFAULT '2',
  `daily_voice_limit_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_voice_count` int NOT NULL DEFAULT '1',
  `serper_api_key` text COLLATE utf8mb4_unicode_ci,
  `elevenlabs_api_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twilio_account_sid` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twilio_auth_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `feature_tts_google` tinyint(1) NOT NULL DEFAULT '0',
  `feature_tts_openai` tinyint(1) NOT NULL DEFAULT '1',
  `feature_tts_elevenlabs` tinyint(1) NOT NULL DEFAULT '0',
  `fine_tune_list` json DEFAULT NULL,
  `chatbot_status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'disabled',
  `chatbot_template` int DEFAULT NULL,
  `chatbot_position` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'bottom-left',
  `chatbot_login_require` tinyint NOT NULL DEFAULT '1',
  `chatbot_rate_limit` int DEFAULT '10',
  `feature_ai_video` tinyint(1) NOT NULL DEFAULT '1',
  `chatbot_show_timestamp` tinyint(1) NOT NULL DEFAULT '0',
  `stablediffusion_bedrock_model` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'stability.stable-diffusion-xl-v1',
  `plagiarism_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.settings_two: ~0 rows (approximately)
INSERT INTO `settings_two` (`id`, `theme`, `stable_diffusion_api_key`, `stable_diffusion_default_model`, `google_recaptcha_status`, `google_recaptcha_site_key`, `google_recaptcha_secret_key`, `languages`, `languages_default`, `liquid_license_type`, `liquid_license_domain_key`, `openai_default_stream_server`, `ai_image_storage`, `stablediffusion_default_language`, `stablediffusion_default_model`, `unsplash_api_key`, `dalle`, `daily_limit_enabled`, `allowed_images_count`, `daily_voice_limit_enabled`, `allowed_voice_count`, `serper_api_key`, `elevenlabs_api_key`, `twilio_account_sid`, `twilio_auth_token`, `feature_tts_google`, `feature_tts_openai`, `feature_tts_elevenlabs`, `fine_tune_list`, `chatbot_status`, `chatbot_template`, `chatbot_position`, `chatbot_login_require`, `chatbot_rate_limit`, `feature_ai_video`, `chatbot_show_timestamp`, `stablediffusion_bedrock_model`, `plagiarism_key`) VALUES
	(1, 'default', NULL, NULL, 0, NULL, NULL, 'en', 'en', 'Extended License', 'local-dev-key-00000000', 'backend', 'public', 'en-US', 'stable-diffusion-xl-1024-v1-0', NULL, 'dall-e-3', 0, 2, 0, 1, NULL, NULL, NULL, NULL, 0, 1, 0, NULL, 'both', 1, 'bottom-left', 1, 10, 1, 1, 'stability.stable-diffusion-xl-v1', NULL);

-- Dumping structure for table magicai.shared_credit_costs
CREATE TABLE IF NOT EXISTS `shared_credit_costs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `entity_key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `engine_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `feature_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_cost` decimal(10,4) NOT NULL,
  `quality_high_multiplier` decimal(6,2) NOT NULL DEFAULT '1.00',
  `quality_low_multiplier` decimal(6,2) NOT NULL DEFAULT '1.00',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `shared_credit_costs_entity_key_unique` (`entity_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.shared_credit_costs: ~0 rows (approximately)

-- Dumping structure for table magicai.shared_credit_transactions
CREATE TABLE IF NOT EXISTS `shared_credit_transactions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `entity_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `engine_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `feature_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(12,4) NOT NULL,
  `balance_after` decimal(12,4) NOT NULL,
  `unit_cost` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `quantity` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `quality` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shared_credit_transactions_user_id_created_at_index` (`user_id`,`created_at`),
  KEY `shared_credit_transactions_user_id_action_type_index` (`user_id`,`action_type`),
  CONSTRAINT `shared_credit_transactions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.shared_credit_transactions: ~0 rows (approximately)

-- Dumping structure for table magicai.share_links
CREATE TABLE IF NOT EXISTS `share_links` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chat` int NOT NULL,
  `message` int NOT NULL,
  `time` bigint NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.share_links: ~0 rows (approximately)

-- Dumping structure for table magicai.social_media_accounts
CREATE TABLE IF NOT EXISTS `social_media_accounts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subtitle` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` longtext COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `social_media_accounts_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.social_media_accounts: ~0 rows (approximately)
INSERT INTO `social_media_accounts` (`id`, `title`, `subtitle`, `key`, `link`, `icon`, `is_active`, `created_at`, `updated_at`) VALUES
	(1, 'Linkedin', 'Developments in the sector', 'linkedin', '#', '<svg width="50" height="52" viewBox="0 0 50 52" fill="currentColor" xmlns="http://www.w3.org/2000/svg"> <path d="M42.4358 43.9153H35.1192V32.1428C35.1192 29.3353 35.0705 25.7228 31.3137 25.7228C27.5033 25.7228 26.9193 28.7803 26.9193 31.9403V43.9153H19.6051V19.7053H26.6297V23.0128H26.7271C28.1602 20.4978 30.8221 18.9953 33.6568 19.1028C41.0732 19.1028 42.4383 24.1153 42.4383 30.6328L42.4358 43.9153ZM11.3492 16.3953C9.00359 16.3953 7.10326 14.4428 7.10326 12.0328C7.10326 9.62284 9.00359 7.67034 11.3492 7.67034C13.6948 7.67034 15.5951 9.62284 15.5951 12.0328C15.5951 14.4428 13.6948 16.3953 11.3492 16.3953ZM15.0063 43.9153H7.68236V19.7053H15.0063V43.9153ZM46.0832 0.690341H4.00579C2.01786 0.667841 0.387613 2.30534 0.363281 4.34784V47.7578C0.387613 49.8028 2.01786 51.4403 4.00579 51.4178H46.0832C48.076 51.4428 49.7136 49.8053 49.7403 47.7578V4.34534C49.7111 2.29784 48.0736 0.660341 46.0832 0.687841" /> </svg>', 1, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(2, 'Telegram', 'Fast instant communication', 'telegram', '#', '<svg width="54" height="44" viewBox="0 0 54 44" fill="currentColor" xmlns="http://www.w3.org/2000/svg"> <path d="M1.90766 21.6842L13.9835 25.7855L42.6529 8.25838C43.0684 8.0042 43.4942 8.56864 43.1358 8.89856L21.431 28.8769L20.6238 40.0616C20.5623 40.9125 21.5873 41.3862 22.1955 40.7881L28.8784 34.2166L41.0954 43.4649C42.4122 44.4619 44.319 43.7592 44.6743 42.1462L53.181 3.52121C53.6662 1.31777 51.5072 -0.541559 49.4001 0.265366L1.84622 18.475C0.35447 19.0463 0.395102 21.1706 1.90766 21.6842Z" /> </svg>', 1, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(3, 'Behance', 'A wide visibility', 'behance', '#', '<svg width="54" height="34" viewBox="0 0 54 34" fill="currentColor" xmlns="http://www.w3.org/2000/svg"> <path d="M27.5018 23.0206V20.9609C27.5018 17.6598 24.8344 15.019 21.5598 15.019L22.8538 14.121C24.9665 12.695 26.234 10.2918 26.234 7.75669C26.234 5.69675 25.4155 3.84808 24.0686 2.52765C22.7481 1.18091 20.8996 0.362305 18.8397 0.362305H0.75V32.8446H17.6778C23.0914 32.8447 27.5018 28.4343 27.5018 23.0206ZM7.64256 5.74963H16.014C18.074 5.74963 19.7377 7.41337 19.7377 9.47308C19.7377 11.533 18.074 13.1968 16.014 13.1968H7.64256V5.74963ZM7.64256 27.6422V18.3201H16.3574C18.9454 18.3201 21.0317 20.4062 21.0317 22.968C21.0317 25.5559 18.9454 27.6422 16.3574 27.6422H7.64256Z" /> <path d="M41.2872 8.5752C34.6851 8.5752 29.3242 14.1738 29.3242 21.0928C29.3242 28.0117 34.6851 33.6369 41.2872 33.6369C46.4368 33.6369 50.847 30.2038 52.5107 25.3973H46.7273C45.3278 28.8833 41.2872 28.3023 41.2872 28.3023C35.6886 27.8798 35.8999 22.5188 35.8999 22.5188H53.171C53.2238 22.0434 53.2503 21.5681 53.2503 21.0927C53.2503 14.1738 47.8893 8.5752 41.2872 8.5752ZM36.4017 18.3199C36.4017 15.4942 38.6992 13.1967 41.5249 13.1967C44.3769 13.1967 46.6746 15.4942 46.6746 18.3199H36.4017Z" /> <path d="M34.7812 2.5625H48.2213V5.74625H34.7812V2.5625Z" /> </svg>', 1, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(4, 'X', 'Latest news and updates', 'twitter', '#', '<svg id="Capa_1" enable-background="new 0 0 1226.37 1226.37" viewBox="0 0 1226.37 1226.37" xmlns="http://www.w3.org/2000/svg"><path d="m727.348 519.284 446.727-519.284h-105.86l-387.893 450.887-309.809-450.887h-357.328l468.492 681.821-468.492 544.549h105.866l409.625-476.152 327.181 476.152h357.328l-485.863-707.086zm-144.998 168.544-47.468-67.894-377.686-540.24h162.604l304.797 435.991 47.468 67.894 396.2 566.721h-162.604l-323.311-462.446z"/><g/><g/><g/><g/><g/><g/><g/><g/><g/><g/><g/><g/><g/><g/><g/></svg>', 1, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(5, 'Instagram', 'Share your photos', 'instagram', '#', '<svg height="511pt" viewBox="0 0 511 511.9" width="511pt" xmlns="http://www.w3.org/2000/svg"><path d="m510.949219 150.5c-1.199219-27.199219-5.597657-45.898438-11.898438-62.101562-6.5-17.199219-16.5-32.597657-29.601562-45.398438-12.800781-13-28.300781-23.101562-45.300781-29.5-16.296876-6.300781-34.898438-10.699219-62.097657-11.898438-27.402343-1.300781-36.101562-1.601562-105.601562-1.601562s-78.199219.300781-105.5 1.5c-27.199219 1.199219-45.898438 5.601562-62.097657 11.898438-17.203124 6.5-32.601562 16.5-45.402343 29.601562-13 12.800781-23.097657 28.300781-29.5 45.300781-6.300781 16.300781-10.699219 34.898438-11.898438 62.097657-1.300781 27.402343-1.601562 36.101562-1.601562 105.601562s.300781 78.199219 1.5 105.5c1.199219 27.199219 5.601562 45.898438 11.902343 62.101562 6.5 17.199219 16.597657 32.597657 29.597657 45.398438 12.800781 13 28.300781 23.101562 45.300781 29.5 16.300781 6.300781 34.898438 10.699219 62.101562 11.898438 27.296876 1.203124 36 1.5 105.5 1.5s78.199219-.296876 105.5-1.5c27.199219-1.199219 45.898438-5.597657 62.097657-11.898438 34.402343-13.300781 61.601562-40.5 74.902343-74.898438 6.296876-16.300781 10.699219-34.902343 11.898438-62.101562 1.199219-27.300781 1.5-36 1.5-105.5s-.101562-78.199219-1.300781-105.5zm-46.097657 209c-1.101562 25-5.300781 38.5-8.800781 47.5-8.601562 22.300781-26.300781 40-48.601562 48.601562-9 3.5-22.597657 7.699219-47.5 8.796876-27 1.203124-35.097657 1.5-103.398438 1.5s-76.5-.296876-103.402343-1.5c-25-1.097657-38.5-5.296876-47.5-8.796876-11.097657-4.101562-21.199219-10.601562-29.398438-19.101562-8.5-8.300781-15-18.300781-19.101562-29.398438-3.5-9-7.699219-22.601562-8.796876-47.5-1.203124-27-1.5-35.101562-1.5-103.402343s.296876-76.5 1.5-103.398438c1.097657-25 5.296876-38.5 8.796876-47.5 4.101562-11.101562 10.601562-21.199219 19.203124-29.402343 8.296876-8.5 18.296876-15 29.398438-19.097657 9-3.5 22.601562-7.699219 47.5-8.800781 27-1.199219 35.101562-1.5 103.398438-1.5 68.402343 0 76.5.300781 103.402343 1.5 25 1.101562 38.5 5.300781 47.5 8.800781 11.097657 4.097657 21.199219 10.597657 29.398438 19.097657 8.5 8.300781 15 18.300781 19.101562 29.402343 3.5 9 7.699219 22.597657 8.800781 47.5 1.199219 27 1.5 35.097657 1.5 103.398438s-.300781 76.300781-1.5 103.300781zm0 0"/><path d="m256.449219 124.5c-72.597657 0-131.5 58.898438-131.5 131.5s58.902343 131.5 131.5 131.5c72.601562 0 131.5-58.898438 131.5-131.5s-58.898438-131.5-131.5-131.5zm0 216.800781c-47.097657 0-85.300781-38.199219-85.300781-85.300781s38.203124-85.300781 85.300781-85.300781c47.101562 0 85.300781 38.199219 85.300781 85.300781s-38.199219 85.300781-85.300781 85.300781zm0 0"/><path d="m423.851562 119.300781c0 16.953125-13.746093 30.699219-30.703124 30.699219-16.953126 0-30.699219-13.746094-30.699219-30.699219 0-16.957031 13.746093-30.699219 30.699219-30.699219 16.957031 0 30.703124 13.742188 30.703124 30.699219zm0 0"/></svg>', 1, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(6, 'Facebook', 'The most popular social media', 'facebook', '#', '<svg width="54" height="54" viewBox="0 0 54 54" fill="currentColor" xmlns="http://www.w3.org/2000/svg"> <path d="M27 0C12.087 0 0 12.087 0 27C0 40.5 10.5 51 24 54V35.1H17.1V27H24V21.6C24 16.2 27.9 13.5 32.4 13.5C34.2 13.5 36 13.8 36 13.8V20.7H33.3C30.6 20.7 30 22.5 30 24V27H36L35.1 35.1H30V54C43.5 51 54 40.5 54 27C54 12.087 41.913 0 27 0Z" /> </svg>', 1, '2026-07-24 08:58:22', '2026-07-24 08:58:22');

-- Dumping structure for table magicai.subscriptions
CREATE TABLE IF NOT EXISTS `subscriptions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `plan_id` bigint unsigned DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stripe_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stripe_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stripe_price` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `trial_ends_at` timestamp NULL DEFAULT NULL,
  `ends_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `paid_with` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'stripe',
  `tax_rate` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_value` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `coupon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_amount` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auto_renewal` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `subscriptions_stripe_id_unique` (`stripe_id`),
  KEY `subscriptions_plan_id_foreign` (`plan_id`),
  KEY `subscriptions_user_id_stripe_status_index` (`user_id`,`stripe_status`),
  KEY `idx_subscriptions_user_status` (`user_id`,`stripe_status`),
  CONSTRAINT `subscriptions_plan_id_foreign` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.subscriptions: ~0 rows (approximately)

-- Dumping structure for table magicai.subscriptions_yokassa
CREATE TABLE IF NOT EXISTS `subscriptions_yokassa` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `plan_id` bigint unsigned DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_method_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subscription_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `trial_ends_at` timestamp NULL DEFAULT NULL,
  `ends_at` timestamp NULL DEFAULT NULL,
  `next_pay_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `tax_rate` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_value` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `coupon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_amount` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auto_renewal` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `subscriptions_yokassa_plan_id_foreign` (`plan_id`),
  KEY `subscriptions_yokassa_user_id_subscription_status_index` (`user_id`,`subscription_status`),
  CONSTRAINT `subscriptions_yokassa_plan_id_foreign` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.subscriptions_yokassa: ~0 rows (approximately)

-- Dumping structure for table magicai.subscription_items
CREATE TABLE IF NOT EXISTS `subscription_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `subscription_id` bigint unsigned NOT NULL,
  `stripe_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stripe_product` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stripe_price` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `subscription_items_subscription_id_stripe_price_unique` (`subscription_id`,`stripe_price`),
  UNIQUE KEY `subscription_items_stripe_id_unique` (`stripe_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.subscription_items: ~0 rows (approximately)

-- Dumping structure for table magicai.teams
CREATE TABLE IF NOT EXISTS `teams` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `entity_credits` json DEFAULT NULL,
  `credit_system_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'separated',
  `shared_credits` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `user_id` bigint unsigned DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `allow_seats` int NOT NULL DEFAULT '0',
  `used_image_credit` int NOT NULL DEFAULT '0',
  `word_credit` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_teams_user_id` (`user_id`),
  CONSTRAINT `teams_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.teams: ~0 rows (approximately)
INSERT INTO `teams` (`id`, `entity_credits`, `credit_system_type`, `shared_credits`, `user_id`, `name`, `allow_seats`, `used_image_credit`, `word_credit`, `created_at`, `updated_at`) VALUES
	(1, NULL, 'separated', 0.0000, 1, 'Super Admin', 0, 0, 0, '2026-07-24 11:36:08', '2026-07-24 11:38:26');

-- Dumping structure for table magicai.team_members
CREATE TABLE IF NOT EXISTS `team_members` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `team_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'member',
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'waiting',
  `allow_unlimited_credits` tinyint(1) NOT NULL DEFAULT '1',
  `daily_shared_credit_limit` decimal(10,4) DEFAULT NULL,
  `remaining_images` decimal(15,2) DEFAULT NULL,
  `remaining_words` decimal(15,2) DEFAULT NULL,
  `used_image_credit` int NOT NULL DEFAULT '0',
  `used_word_credit` int NOT NULL DEFAULT '0',
  `joined_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `team_members_team_id_foreign` (`team_id`),
  KEY `team_members_user_id_foreign` (`user_id`),
  CONSTRAINT `team_members_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE,
  CONSTRAINT `team_members_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.team_members: ~0 rows (approximately)

-- Dumping structure for table magicai.telescope_entries
CREATE TABLE IF NOT EXISTS `telescope_entries` (
  `sequence` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `family_hash` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `should_display_on_index` tinyint(1) NOT NULL DEFAULT '1',
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`sequence`),
  UNIQUE KEY `telescope_entries_uuid_unique` (`uuid`),
  KEY `telescope_entries_batch_id_index` (`batch_id`),
  KEY `telescope_entries_family_hash_index` (`family_hash`),
  KEY `telescope_entries_created_at_index` (`created_at`),
  KEY `telescope_entries_type_should_display_on_index_index` (`type`,`should_display_on_index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.telescope_entries: ~0 rows (approximately)

-- Dumping structure for table magicai.telescope_entries_tags
CREATE TABLE IF NOT EXISTS `telescope_entries_tags` (
  `entry_uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tag` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`entry_uuid`,`tag`),
  KEY `telescope_entries_tags_tag_index` (`tag`),
  CONSTRAINT `telescope_entries_tags_entry_uuid_foreign` FOREIGN KEY (`entry_uuid`) REFERENCES `telescope_entries` (`uuid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.telescope_entries_tags: ~0 rows (approximately)

-- Dumping structure for table magicai.telescope_monitoring
CREATE TABLE IF NOT EXISTS `telescope_monitoring` (
  `tag` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.telescope_monitoring: ~0 rows (approximately)

-- Dumping structure for table magicai.testimonials
CREATE TABLE IF NOT EXISTS `testimonials` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'assets/img/auth/default-avatar.png',
  `full_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `words` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.testimonials: ~0 rows (approximately)
INSERT INTO `testimonials` (`id`, `avatar`, `full_name`, `job_title`, `words`, `created_at`, `updated_at`) VALUES
	(1, '202306020840avatar-1.jpg', 'Peline Jan', 'Entrepreneur', '“Not only did it save me time, but it also helped me \nproduce content that was more engaging and \neffective than what I had been creating on my own.”', '2023-05-29 12:30:53', '2023-06-02 01:40:35'),
	(2, '202306020840avatar-3.jpg', 'Tom Daniel', 'Writer', 'As a freelance writer, I was looking for a tool that could help me generate ideas and write faster. This AI Text website has done that and more.', '2023-05-30 00:52:22', '2023-06-02 01:40:47'),
	(3, '202306020840avatar-2.jpg', 'Eric Sanchez', 'UX Designer', 'The customer support team has been incredibly helpful whenever I’ve had any questions. I can’t imagine going back to my old content-creation methods!', '2023-05-30 00:53:14', '2023-06-02 01:40:58');

-- Dumping structure for table magicai.tokens
CREATE TABLE IF NOT EXISTS `tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'word',
  `entity_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tokens_entity_id_foreign` (`entity_id`),
  CONSTRAINT `tokens_entity_id_foreign` FOREIGN KEY (`entity_id`) REFERENCES `entities` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=242 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.tokens: ~0 rows (approximately)
INSERT INTO `tokens` (`id`, `type`, `entity_id`, `created_at`, `updated_at`) VALUES
	(1, 'word', 1, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(2, 'word', 2, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(3, 'word', 3, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(4, 'word', 4, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(5, 'word', 5, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(6, 'word', 6, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(7, 'word', 7, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(8, 'word', 8, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(9, 'word', 9, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(10, 'word', 10, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(11, 'word', 11, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(12, 'word', 12, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(13, 'word', 13, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(14, 'word', 14, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(15, 'word', 15, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(16, 'word', 16, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(17, 'word', 17, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(18, 'word', 18, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(19, 'word', 19, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(20, 'word', 20, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(21, 'word', 21, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(22, 'word', 22, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(23, 'word', 23, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(24, 'word', 24, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(25, 'word', 25, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(26, 'word', 26, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(27, 'word', 27, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(28, 'word', 28, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(29, 'word', 29, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(30, 'word', 30, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(31, 'word', 31, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(32, 'word', 32, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(33, 'word', 33, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(34, 'word', 34, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(35, 'word', 35, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(36, 'word', 36, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(37, 'word', 37, '2026-07-24 08:58:21', '2026-07-24 08:58:21'),
	(38, 'word', 38, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(39, 'word', 39, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(40, 'word', 40, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(41, 'word', 41, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(42, 'word', 42, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(43, 'word', 43, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(44, 'word', 44, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(45, 'word', 45, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(46, 'word', 46, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(47, 'word', 47, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(48, 'word', 48, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(49, 'word', 49, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(50, 'word', 50, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(51, 'word', 51, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(52, 'word', 52, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(53, 'word', 53, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(54, 'word', 54, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(55, 'word', 55, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(56, 'word', 56, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(57, 'word', 57, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(58, 'word', 58, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(59, 'word', 59, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(60, 'word', 60, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(61, 'word', 61, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(62, 'word', 62, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(63, 'second', 63, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(64, 'second', 64, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(65, 'word', 65, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(66, 'word', 66, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(67, 'word', 67, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(68, 'image_to_video', 68, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(69, 'image', 69, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(70, 'image', 70, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(71, 'image', 71, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(72, 'image', 72, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(73, 'image', 73, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(74, 'image', 74, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(75, 'image', 75, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(76, 'image', 76, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(77, 'image', 77, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(78, 'image', 78, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(79, 'image', 79, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(80, 'image', 80, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(81, 'image', 81, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(82, 'word', 82, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(83, 'word', 83, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(84, 'word', 84, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(85, 'word', 85, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(86, 'word', 86, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(87, 'word', 87, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(88, 'word', 88, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(89, 'word', 89, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(90, 'word', 90, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(91, 'word', 91, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(92, 'word', 92, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(93, 'word', 93, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(94, 'word', 94, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(95, 'image', 95, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(96, 'image', 96, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(97, 'image', 97, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(98, 'plagiarism', 98, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(99, 'text_to_video', 99, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(100, 'text_to_video', 100, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(101, 'second', 101, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(102, 'minute', 102, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(103, 'image', 103, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(104, 'word', 104, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(105, 'word', 105, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(106, 'image', 106, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(107, 'image', 107, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(108, 'image', 108, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(109, 'character', 109, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(110, 'character', 110, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(111, 'character', 111, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(112, 'character', 112, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(113, 'minute', 113, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(114, 'second', 114, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(115, 'second', 115, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(116, 'character', 116, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(117, 'character', 117, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(118, 'word', 118, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(119, 'character', 119, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(120, 'word', 120, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(121, 'word', 121, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(122, 'speech_to_text', 122, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(123, 'image', 123, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(124, 'image', 124, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(125, 'image', 125, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(126, 'image', 126, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(127, 'image', 127, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(128, 'character', 128, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(129, 'character', 129, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(130, 'word', 130, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(131, 'word', 131, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(132, 'word', 132, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(133, 'word', 133, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(134, 'word', 134, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(135, 'word', 135, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(136, 'word', 136, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(137, 'word', 137, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(138, 'word', 138, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(139, 'word', 139, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(140, 'presentation', 140, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(141, 'text_to_video', 141, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(142, 'text_to_video', 142, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(143, 'text_to_video', 143, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(144, 'text_to_video', 144, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(145, 'text_to_video', 145, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(146, 'text_to_video', 146, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(147, 'text_to_video', 147, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(148, 'text_to_video', 148, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(149, 'text_to_video', 149, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(150, 'text_to_video', 150, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(151, 'text_to_video', 151, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(152, 'text_to_video', 152, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(153, 'text_to_video', 153, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(154, 'text_to_video', 154, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(155, 'text_to_video', 155, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(156, 'image', 156, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(157, 'image', 157, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(158, 'image', 158, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(159, 'image', 159, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(160, 'image', 160, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(161, 'image', 161, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(162, 'image', 162, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(163, 'image', 163, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(164, 'text_to_video', 164, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(165, 'image_to_video', 165, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(166, 'image', 166, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(167, 'image', 167, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(168, 'text_to_video', 168, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(169, 'image_to_video', 169, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(170, 'text_to_video', 170, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(171, 'text_to_video', 171, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(172, 'image_to_video', 172, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(173, 'text_to_video', 173, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(174, 'image', 174, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(175, 'image', 175, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(176, 'image', 176, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(177, 'image', 177, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(178, 'image', 178, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(179, 'image', 179, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(180, 'image', 180, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(181, 'image', 181, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(182, 'image', 182, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(183, 'image', 183, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(184, 'image', 184, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(185, 'text_to_video', 185, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(186, 'image_to_video', 186, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(187, 'text_to_video', 187, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(188, 'image_to_video', 188, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(189, 'image_to_video', 189, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(190, 'text_to_video', 190, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(191, 'image_to_video', 191, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(192, 'image_to_video', 192, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(193, 'image_to_video', 193, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(194, 'text_to_video', 194, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(195, 'image_to_video', 195, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(196, 'text_to_video', 196, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(197, 'image_to_video', 197, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(198, 'image_to_video', 198, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(199, 'text_to_video', 199, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(200, 'text_to_video', 200, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(201, 'text_to_video', 201, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(202, 'text_to_video', 202, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(203, 'minute', 203, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(204, 'word', 204, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(205, 'word', 205, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(206, 'word', 206, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(207, 'word', 207, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(208, 'word', 208, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(209, 'word', 209, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(210, 'word', 210, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(211, 'word', 211, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(212, 'word', 212, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(213, 'word', 213, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(214, 'word', 214, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(215, 'word', 215, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(216, 'word', 216, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(217, 'word', 217, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(218, 'word', 218, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(219, 'word', 219, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(220, 'word', 220, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(221, 'word', 221, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(222, 'word', 222, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(223, 'word', 223, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(224, 'word', 224, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(225, 'word', 225, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(226, 'word', 226, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(227, 'word', 227, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(228, 'word', 228, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(229, 'word', 229, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(230, 'word', 230, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(231, 'image', 231, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(232, 'video_to_video', 232, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(233, 'video_to_video', 233, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(234, 'video_to_video', 234, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(235, 'video_to_video', 235, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(236, 'video_to_video', 236, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(237, 'image', 237, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(238, 'text_to_video', 238, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(239, 'text_to_video', 239, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(240, 'text_to_video', 240, '2026-07-24 08:58:22', '2026-07-24 08:58:22'),
	(241, 'text_to_video', 241, '2026-07-24 08:58:22', '2026-07-24 08:58:22');

-- Dumping structure for table magicai.twitter_settings
CREATE TABLE IF NOT EXISTS `twitter_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `consumer_key` text COLLATE utf8mb4_unicode_ci,
  `consumer_secret` text COLLATE utf8mb4_unicode_ci,
  `access_token` text COLLATE utf8mb4_unicode_ci,
  `access_token_secret` text COLLATE utf8mb4_unicode_ci,
  `bearer_token` text COLLATE utf8mb4_unicode_ci,
  `account_id` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.twitter_settings: ~0 rows (approximately)

-- Dumping structure for table magicai.usage
CREATE TABLE IF NOT EXISTS `usage` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `total_user_count` int unsigned NOT NULL DEFAULT '0',
  `this_week_user_count` int unsigned NOT NULL DEFAULT '0',
  `last_week_user_count` int unsigned NOT NULL DEFAULT '0',
  `total_word_count` int unsigned NOT NULL DEFAULT '0',
  `this_week_word_count` int unsigned NOT NULL DEFAULT '0',
  `last_week_word_count` int unsigned NOT NULL DEFAULT '0',
  `total_image_count` int unsigned NOT NULL DEFAULT '0',
  `this_week_image_count` int unsigned NOT NULL DEFAULT '0',
  `last_week_image_count` int unsigned NOT NULL DEFAULT '0',
  `total_sales` int unsigned NOT NULL DEFAULT '0',
  `this_week_sales` int unsigned NOT NULL DEFAULT '0',
  `last_week_sales` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.usage: ~1 rows (approximately)
INSERT INTO `usage` (`id`, `total_user_count`, `this_week_user_count`, `last_week_user_count`, `total_word_count`, `this_week_word_count`, `last_week_word_count`, `total_image_count`, `this_week_image_count`, `last_week_image_count`, `total_sales`, `this_week_sales`, `last_week_sales`, `created_at`, `updated_at`) VALUES
	(1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2026-07-24 08:57:44', '2026-07-24 09:01:14');

-- Dumping structure for table magicai.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `entity_credits` json DEFAULT NULL,
  `credit_system_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'separated',
  `shared_credits` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `coingate_subscriber_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `team_id` bigint unsigned DEFAULT NULL,
  `team_manager_id` bigint unsigned DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `surname` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(1055) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'assets/img/auth/default-avatar.png',
  `company_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_website` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `remaining_words` decimal(15,2) DEFAULT '0.00',
  `remaining_images` decimal(15,2) DEFAULT '0.00',
  `last_seen` date DEFAULT NULL,
  `github_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `github_token` text COLLATE utf8mb4_unicode_ci,
  `google_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_token` text COLLATE utf8mb4_unicode_ci,
  `facebook_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook_token` text COLLATE utf8mb4_unicode_ci,
  `twitter_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google2fa_secret` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `stripe_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_checkout_customer_reference` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pm_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pm_last_four` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trial_ends_at` timestamp NULL DEFAULT NULL,
  `affiliate_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `affiliate_earnings` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `affiliate_bank_account` text COLLATE utf8mb4_unicode_ci,
  `affiliate_id` bigint unsigned DEFAULT NULL,
  `email_confirmation_code` text COLLATE utf8mb4_unicode_ci,
  `email_confirmed` tinyint(1) NOT NULL DEFAULT '0',
  `password_reset_code` text COLLATE utf8mb4_unicode_ci,
  `github_refresh_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_refresh_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `iyzico_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revenuecat_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `apple_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `apple_token` text COLLATE utf8mb4_unicode_ci,
  `apple_refresh_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `razorpay_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `api_keys` text COLLATE utf8mb4_unicode_ci,
  `gemini_api_keys` text COLLATE utf8mb4_unicode_ci,
  `anthropic_api_keys` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `defi_setting` text COLLATE utf8mb4_unicode_ci,
  `affiliate_status` tinyint DEFAULT '1',
  `tour_seen` tinyint(1) NOT NULL DEFAULT '0',
  `otp` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dash_notify_seen` tinyint(1) NOT NULL DEFAULT '0',
  `xai_api_keys` text COLLATE utf8mb4_unicode_ci,
  `last_activity_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `reg_sub_status` enum('completed','in_progress') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'completed',
  `xero_account_id` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_stripe_id_index` (`stripe_id`),
  KEY `users_affiliate_id_foreign` (`affiliate_id`),
  KEY `users_razorpay_id_index` (`razorpay_id`),
  KEY `users_last_activity_at_index` (`last_activity_at`),
  KEY `idx_users_team_id` (`team_id`),
  KEY `idx_users_team_manager_id` (`team_manager_id`),
  KEY `idx_users_type` (`type`),
  KEY `idx_users_last_activity_at` (`last_activity_at`),
  CONSTRAINT `users_affiliate_id_foreign` FOREIGN KEY (`affiliate_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.users: ~0 rows (approximately)
INSERT INTO `users` (`id`, `entity_credits`, `credit_system_type`, `shared_credits`, `coingate_subscriber_id`, `team_id`, `team_manager_id`, `name`, `surname`, `email`, `phone`, `type`, `password`, `avatar`, `company_name`, `company_website`, `country`, `address`, `city`, `state`, `postal`, `status`, `remaining_words`, `remaining_images`, `last_seen`, `github_id`, `github_token`, `google_id`, `google_token`, `facebook_id`, `facebook_token`, `twitter_id`, `twitter_token`, `google2fa_secret`, `created_at`, `updated_at`, `stripe_id`, `two_checkout_customer_reference`, `pm_type`, `pm_last_four`, `trial_ends_at`, `affiliate_code`, `affiliate_earnings`, `affiliate_bank_account`, `affiliate_id`, `email_confirmation_code`, `email_confirmed`, `password_reset_code`, `github_refresh_token`, `google_refresh_token`, `iyzico_id`, `revenuecat_id`, `apple_id`, `apple_token`, `apple_refresh_token`, `razorpay_id`, `api_keys`, `gemini_api_keys`, `anthropic_api_keys`, `remember_token`, `defi_setting`, `affiliate_status`, `tour_seen`, `otp`, `dash_notify_seen`, `xai_api_keys`, `last_activity_at`, `reg_sub_status`, `xero_account_id`) VALUES
	(1, '{"klap": {"ai-clip-klap": {"credit": 0, "isUnlimited": false}}, "x_ai": {"grok-3": {"credit": 0, "isUnlimited": false}, "grok-2-1212": {"credit": 0, "isUnlimited": false}, "grok-3-fast": {"credit": 0, "isUnlimited": false}, "grok-3-mini": {"credit": 0, "isUnlimited": false}, "grok-4-0709": {"credit": 0, "isUnlimited": false}, "grok-3-mini-fast": {"credit": 0, "isUnlimited": false}, "grok-2-vision-1212": {"credit": 0, "isUnlimited": false}, "grok-4-fast-reasoning": {"credit": 0, "isUnlimited": false}, "grok-4-1-fast-reasoning": {"credit": 0, "isUnlimited": false}, "grok-4-1-fast-non-reasoning": {"credit": 0, "isUnlimited": false}}, "azure": {"azure": {"credit": 0, "isUnlimited": false}, "azure-openai": {"credit": 0, "isUnlimited": false}}, "piapi": {"midjourney": {"credit": 0, "isUnlimited": false}}, "fal_ai": {"veed": {"credit": 0, "isUnlimited": false}, "veo2": {"credit": 0, "isUnlimited": false}, "veo3": {"credit": 0, "isUnlimited": false}, "kling": {"credit": 0, "isUnlimited": false}, "haiper": {"credit": 0, "isUnlimited": false}, "imagen4": {"credit": 0, "isUnlimited": false}, "minimax": {"credit": 0, "isUnlimited": false}, "flux-pro": {"credit": 0, "isUnlimited": false}, "klingV21": {"credit": 0, "isUnlimited": false}, "veo3-fast": {"credit": 0, "isUnlimited": false}, "klingImage": {"credit": 0, "isUnlimited": false}, "flux-2-flex": {"credit": 0, "isUnlimited": false}, "ideogram-v2": {"credit": 0, "isUnlimited": false}, "kling-video": {"credit": 0, "isUnlimited": false}, "nano-banana": {"credit": 0, "isUnlimited": false}, "flux-realism": {"credit": 0, "isUnlimited": false}, "flux/schnell": {"credit": 0, "isUnlimited": false}, "veo3__1/lite": {"credit": 0, "isUnlimited": false}, "nano-banana-2": {"credit": 0, "isUnlimited": false}, "flux-pro/v1__1": {"credit": 0, "isUnlimited": false}, "video-upscaler": {"credit": 0, "isUnlimited": false}, "animatediff-v2v": {"credit": 0, "isUnlimited": false}, "nano-banana-pro": {"credit": 0, "isUnlimited": false}, "flux-2-flex/edit": {"credit": 0, "isUnlimited": false}, "flux-pro/kontext": {"credit": 0, "isUnlimited": false}, "nano-banana/edit": {"credit": 0, "isUnlimited": false}, "seedream/v4/edit": {"credit": 0, "isUnlimited": false}, "veed/fabric-1__0": {"credit": 0, "isUnlimited": false}, "luma-dream-machine": {"credit": 0, "isUnlimited": false}, "nano-banana-2/edit": {"credit": 0, "isUnlimited": false}, "nano-banana-pro/edit": {"credit": 0, "isUnlimited": false}, "veo3__1/text-to-video": {"credit": 0, "isUnlimited": false}, "veo3__1/image-to-video": {"credit": 0, "isUnlimited": false}, "xai/grok-imagine-image": {"credit": 0, "isUnlimited": false}, "seedream/v4/text-to-image": {"credit": 0, "isUnlimited": false}, "flux-pro/kontext/max/multi": {"credit": 0, "isUnlimited": false}, "veo3__1/fast/text-to-video": {"credit": 0, "isUnlimited": false}, "veo3__1/reference-to-video": {"credit": 0, "isUnlimited": false}, "cogvideox-5b/video-to-video": {"credit": 0, "isUnlimited": false}, "veo3__1/fast/image-to-video": {"credit": 0, "isUnlimited": false}, "veo3__1/lite/image-to-video": {"credit": 0, "isUnlimited": false}, "xai/grok-imagine-image/edit": {"credit": 0, "isUnlimited": false}, "veed/video-background-removal": {"credit": 0, "isUnlimited": false}, "flux-pro/kontext/text-to-image": {"credit": 0, "isUnlimited": false}, "kling-video/v3/pro/text-to-video": {"credit": 0, "isUnlimited": false}, "kling-video/v3/pro/image-to-video": {"credit": 0, "isUnlimited": false}, "veo3__1/first-last-frame-to-video": {"credit": 0, "isUnlimited": false}, "kling-2__5-turbo/pro/text-to-video": {"credit": 0, "isUnlimited": false}, "kling-2__5-turbo/pro/image-to-video": {"credit": 0, "isUnlimited": false}, "kling-video/v2__6/pro/text-to-video": {"credit": 0, "isUnlimited": false}, "kling-video/v2__6/pro/image-to-video": {"credit": 0, "isUnlimited": false}, "kling-video/v2__6/pro/motion-control": {"credit": 0, "isUnlimited": false}, "xai/grok-imagine-video/text-to-video": {"credit": 0, "isUnlimited": false}, "bytedance/seedance-2__0/text-to-video": {"credit": 0, "isUnlimited": false}, "fast-animatediff/turbo/video-to-video": {"credit": 0, "isUnlimited": false}, "kling-video/v3/standard/text-to-video": {"credit": 0, "isUnlimited": false}, "xai/grok-imagine-video/image-to-video": {"credit": 0, "isUnlimited": false}, "bytedance/seedance-2__0/image-to-video": {"credit": 0, "isUnlimited": false}, "kling-video/v3/standard/image-to-video": {"credit": 0, "isUnlimited": false}, "veo3__1/fast/first-last-frame-to-video": {"credit": 0, "isUnlimited": false}, "veo3__1/lite/first-last-frame-to-video": {"credit": 0, "isUnlimited": false}, "kling-2__5-turbo/standard/image-to-video": {"credit": 0, "isUnlimited": false}, "kling-video/v2__6/standard/motion-control": {"credit": 0, "isUnlimited": false}, "bytedance/seedance-2__0/fast/text-to-video": {"credit": 0, "isUnlimited": false}, "bytedance/seedance-2__0/reference-to-video": {"credit": 0, "isUnlimited": false}, "bytedance/seedance-2__0/fast/image-to-video": {"credit": 0, "isUnlimited": false}, "bytedance/seedance-2__0/fast/reference-to-video": {"credit": 0, "isUnlimited": false}}, "gemini": {"lyria-3-pro": {"credit": 0, "isUnlimited": false}, "lyria-3-clip": {"credit": 0, "isUnlimited": false}, "gemini-1__5-pro": {"credit": 0, "isUnlimited": false}, "gemini-2__5-pro": {"credit": 0, "isUnlimited": false}, "gemini-1__5-flash": {"credit": 0, "isUnlimited": false}, "gemini-2__0-flash": {"credit": 0, "isUnlimited": false}, "text-embedding-004": {"credit": 0, "isUnlimited": false}, "gemini-3-pro-preview": {"credit": 0, "isUnlimited": false}, "gemini-deep-research": {"credit": 0, "isUnlimited": false}, "gemini-embedding-exp": {"credit": 0, "isUnlimited": false}, "gemini-2__0-flash-lite": {"credit": 0, "isUnlimited": false}, "gemini-3-flash-preview": {"credit": 0, "isUnlimited": false}, "gemini-3__1-pro-preview": {"credit": 0, "isUnlimited": false}, "gemini-3__1-flash-live-preview": {"credit": 0, "isUnlimited": false}, "gemini-2__5-flash-preview-05-20": {"credit": 0, "isUnlimited": false}}, "google": {"google": {"credit": 0, "isUnlimited": false}}, "heygen": {"heygen": {"credit": 0, "isUnlimited": false}, "video-dubbing": {"credit": 0, "isUnlimited": false}}, "novita": {"novita": {"credit": 0, "isUnlimited": false}}, "openai": {"o1": {"credit": 0, "isUnlimited": false}, "o3": {"credit": 0, "isUnlimited": false}, "gpt-4": {"credit": 0, "isUnlimited": false}, "gpt-5": {"credit": 0, "isUnlimited": false}, "tts-1": {"credit": 0, "isUnlimited": false}, "gpt-4o": {"credit": 0, "isUnlimited": false}, "sora-2": {"credit": 0, "isUnlimited": false}, "o1-mini": {"credit": 0, "isUnlimited": false}, "o3-mini": {"credit": 0, "isUnlimited": false}, "o4-mini": {"credit": 0, "isUnlimited": false}, "dall-e-2": {"credit": 0, "isUnlimited": false}, "dall-e-3": {"credit": 0, "isUnlimited": false}, "gpt-4__1": {"credit": 0, "isUnlimited": false}, "gpt-5__1": {"credit": 0, "isUnlimited": false}, "gpt-5__2": {"credit": 0, "isUnlimited": false}, "gpt-5__4": {"credit": 0, "isUnlimited": false}, "gpt-5__5": {"credit": 0, "isUnlimited": false}, "tts-1-hd": {"credit": 0, "isUnlimited": false}, "gpt-5-pro": {"credit": 0, "isUnlimited": false}, "whisper-1": {"credit": 0, "isUnlimited": false}, "gpt-5-mini": {"credit": 0, "isUnlimited": false}, "gpt-5-nano": {"credit": 0, "isUnlimited": false}, "o1-preview": {"credit": 0, "isUnlimited": false}, "sora-2-pro": {"credit": 0, "isUnlimited": false}, "davinci-002": {"credit": 0, "isUnlimited": false}, "gpt-4-turbo": {"credit": 0, "isUnlimited": false}, "gpt-4o-mini": {"credit": 0, "isUnlimited": false}, "gpt-image-1": {"credit": 0, "isUnlimited": false}, "gpt-image-2": {"credit": 0, "isUnlimited": false}, "gpt-5__2-pro": {"credit": 0, "isUnlimited": false}, "gpt-realtime": {"credit": 0, "isUnlimited": false}, "gpt-4__1-mini": {"credit": 0, "isUnlimited": false}, "gpt-4__1-nano": {"credit": 0, "isUnlimited": false}, "gpt-5__4-mini": {"credit": 0, "isUnlimited": false}, "gpt-5__4-nano": {"credit": 0, "isUnlimited": false}, "gpt-3__5-turbo": {"credit": 0, "isUnlimited": false}, "gpt-image-1__5": {"credit": 0, "isUnlimited": false}, "o3-deep-research": {"credit": 0, "isUnlimited": false}, "text-davinci-003": {"credit": 0, "isUnlimited": false}, "gpt-5-chat-latest": {"credit": 0, "isUnlimited": false}, "gpt-4-0125-preview": {"credit": 0, "isUnlimited": false}, "gpt-4-1106-preview": {"credit": 0, "isUnlimited": false}, "gpt-3__5-turbo-0125": {"credit": 0, "isUnlimited": false}, "gpt-3__5-turbo-1106": {"credit": 0, "isUnlimited": false}, "gpt-5__1-chat-latest": {"credit": 0, "isUnlimited": false}, "gpt-5__3-chat-latest": {"credit": 0, "isUnlimited": false}, "gpt-4o-search-preview": {"credit": 0, "isUnlimited": false}, "o4-mini-deep-research": {"credit": 0, "isUnlimited": false}, "text-embedding-3-large": {"credit": 0, "isUnlimited": false}, "text-embedding-3-small": {"credit": 0, "isUnlimited": false}, "text-embedding-ada-002": {"credit": 0, "isUnlimited": false}, "gpt-4o-mini-search-preview": {"credit": 0, "isUnlimited": false}, "gpt-4o-realtime-preview-2024-12-17": {"credit": 0, "isUnlimited": false}}, "pexels": {"pexels": {"credit": 0, "isUnlimited": false}}, "serper": {"serper": {"credit": 0, "isUnlimited": false}}, "vizard": {"ai-clip-vizard": {"credit": 0, "isUnlimited": false}}, "freepik": {"freepik": {"credit": 0, "isUnlimited": false}}, "minimax": {"music-01": {"credit": 0, "isUnlimited": false}}, "pixabay": {"pixabay": {"credit": 0, "isUnlimited": false}}, "topview": {"ad-marketing-video-topview": {"credit": 0, "isUnlimited": false}}, "captions": {"ai-captions": {"credit": 0, "isUnlimited": false}}, "clipdrop": {"clipdrop": {"credit": 0, "isUnlimited": false}}, "creatify": {"ad-marketing-video": {"credit": 0, "isUnlimited": false}}, "gamma_ai": {"gamma-ai": {"credit": 0, "isUnlimited": false}}, "pebblely": {"pebblely": {"credit": 0, "isUnlimited": false}}, "together": {"black-forest-labs/FLUX__1-schnell": {"credit": 0, "isUnlimited": false}}, "unsplash": {"unsplash": {"credit": 0, "isUnlimited": false}}, "anthropic": {"voyage-2": {"credit": 0, "isUnlimited": false}, "claude-2__0": {"credit": 0, "isUnlimited": false}, "claude-2__1": {"credit": 0, "isUnlimited": false}, "voyage-code-2": {"credit": 0, "isUnlimited": false}, "claude-fable-5": {"credit": 0, "isUnlimited": false}, "voyage-large-2": {"credit": 0, "isUnlimited": false}, "claude-opus-4-6": {"credit": 0, "isUnlimited": false}, "claude-opus-4-7": {"credit": 0, "isUnlimited": false}, "claude-opus-4-8": {"credit": 0, "isUnlimited": false}, "claude-sonnet-4-6": {"credit": 0, "isUnlimited": false}, "claude-3-opus-20240229": {"credit": 0, "isUnlimited": false}, "claude-opus-4-20250514": {"credit": 0, "isUnlimited": false}, "claude-3-haiku-20240307": {"credit": 0, "isUnlimited": false}, "claude-3-haiku-20241022": {"credit": 0, "isUnlimited": false}, "claude-3-sonnet-20240229": {"credit": 0, "isUnlimited": false}, "claude-opus-4-1-20250805": {"credit": 0, "isUnlimited": false}, "claude-opus-4-5-20251101": {"credit": 0, "isUnlimited": false}, "claude-sonnet-4-20250514": {"credit": 0, "isUnlimited": false}, "claude-3-5-sonnet-20240620": {"credit": 0, "isUnlimited": false}, "claude-3-5-sonnet-20241022": {"credit": 0, "isUnlimited": false}, "claude-3-7-sonnet-20250219": {"credit": 0, "isUnlimited": false}, "claude-sonnet-4-5-20250929": {"credit": 0, "isUnlimited": false}}, "deep_seek": {"deepseek-chat": {"credit": 0, "isUnlimited": false}, "deepseek-reasoner": {"credit": 0, "isUnlimited": false}}, "speechify": {"speechify": {"credit": 0, "isUnlimited": false}}, "synthesia": {"synthesia": {"credit": 0, "isUnlimited": false}}, "elevenlabs": {"isolator": {"credit": 0, "isUnlimited": false}, "eleven_v3": {"credit": 0, "isUnlimited": false}, "elevenlabs": {"credit": 0, "isUnlimited": false}, "elevenlabs-ai-music": {"credit": 0, "isUnlimited": false}, "elevenlabs-voice-chatbot": {"credit": 0, "isUnlimited": false}}, "perplexity": {"perplexity": {"credit": 0, "isUnlimited": false}}, "open_router": {"liquid/lfm-40b": {"credit": 0, "isUnlimited": false}, "x-ai/grok-beta": {"credit": 0, "isUnlimited": false}, "liquid/lfm-40b:free": {"credit": 0, "isUnlimited": false}, "mistralai/ministral-3b": {"credit": 0, "isUnlimited": false}, "mistralai/ministral-8b": {"credit": 0, "isUnlimited": false}, "thedrummer/rocinante-12b": {"credit": 0, "isUnlimited": false}, "anthropic/claude-3-5-haiku": {"credit": 0, "isUnlimited": false}, "inflection/inflection-3-pi": {"credit": 0, "isUnlimited": false}, "qwen/qwen-2__5-7b-instruct": {"credit": 0, "isUnlimited": false}, "anthracite-org/magnum-v2-72b": {"credit": 0, "isUnlimited": false}, "anthracite-org/magnum-v4-72b": {"credit": 0, "isUnlimited": false}, "eva-unit-01/eva-qwen-2__5-14b": {"credit": 0, "isUnlimited": false}, "anthropic/claude-3-5-haiku:beta": {"credit": 0, "isUnlimited": false}, "meta-llama/llama-3__2-1b-instruct": {"credit": 0, "isUnlimited": false}, "meta-llama/llama-3__2-3b-instruct": {"credit": 0, "isUnlimited": false}, "neversleep/llama-3__1-lumimaid-70b": {"credit": 0, "isUnlimited": false}, "anthropic/claude-3-5-haiku-20241022": {"credit": 0, "isUnlimited": false}, "inflection/inflection-3-productivity": {"credit": 0, "isUnlimited": false}, "meta-llama/llama-3__2-1b-instruct:free": {"credit": 0, "isUnlimited": false}, "meta-llama/llama-3__2-3b-instruct:free": {"credit": 0, "isUnlimited": false}, "nvidia/llama-3__1-nemotron-70b-instruct": {"credit": 0, "isUnlimited": false}, "anthropic/claude-3-5-haiku-20241022:beta": {"credit": 0, "isUnlimited": false}, "perplexity/llama-3__1-sonar-large-128k-chat": {"credit": 0, "isUnlimited": false}, "perplexity/llama-3__1-sonar-small-128k-chat": {"credit": 0, "isUnlimited": false}, "perplexity/llama-3__1-sonar-huge-128k-online": {"credit": 0, "isUnlimited": false}, "perplexity/llama-3__1-sonar-large-128k-online": {"credit": 0, "isUnlimited": false}, "perplexity/llama-3__1-sonar-small-128k-online": {"credit": 0, "isUnlimited": false}}, "plagiarism_check": {"plagiarismcheck": {"credit": 0, "isUnlimited": false}}, "stable_diffusion": {"sd3": {"credit": 0, "isUnlimited": false}, "core": {"credit": 0, "isUnlimited": false}, "ultra": {"credit": 0, "isUnlimited": false}, "sd3-large": {"credit": 0, "isUnlimited": false}, "sd3-turbo": {"credit": 0, "isUnlimited": false}, "sd3-medium": {"credit": 0, "isUnlimited": false}, "aws_bedrock": {"credit": 0, "isUnlimited": false}, "sd3__5-large": {"credit": 0, "isUnlimited": false}, "sd3__5-medium": {"credit": 0, "isUnlimited": false}, "image-to-video": {"credit": 0, "isUnlimited": false}, "sd3-large-turbo": {"credit": 0, "isUnlimited": false}, "sd3__5-large-turbo": {"credit": 0, "isUnlimited": false}, "stable-diffusion-v1-6": {"credit": 0, "isUnlimited": false}, "stable-diffusion-xl-1024-v1-0": {"credit": 0, "isUnlimited": false}}}', 'separated', 0.0000, NULL, NULL, NULL, 'Super', 'Admin', 'admin@magicai.test', NULL, 'super_admin', '$2y$10$hblGfKGZPfNfyaK1UncZWevl1lsvU1gBlhFbISC7yGWeKEKLHhare', 'assets/img/auth/default-avatar.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0.00, 0.00, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-07-24 09:01:14', '2026-07-24 21:47:02', NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, 1, 0, NULL, 0, NULL, '2026-07-24 21:47:02', 'completed', NULL);

-- Dumping structure for table magicai.users_activity
CREATE TABLE IF NOT EXISTS `users_activity` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `connection` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.users_activity: ~0 rows (approximately)
INSERT INTO `users_activity` (`id`, `email`, `type`, `connection`, `created_at`) VALUES
	(1, 'admin@magicai.test', 'super_admin', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-24 09:21:43'),
	(2, 'admin@magicai.test', 'super_admin', 'curl/8.21.0', '2026-07-24 09:22:40'),
	(3, 'admin@magicai.test', 'super_admin', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0', '2026-07-24 09:30:58'),
	(4, 'admin@magicai.test', 'super_admin', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-24 21:37:18');

-- Dumping structure for table magicai.user_affiliates
CREATE TABLE IF NOT EXISTS `user_affiliates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `amount` double NOT NULL DEFAULT '0',
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Waiting',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_affiliates_user_id_foreign` (`user_id`),
  CONSTRAINT `user_affiliates_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.user_affiliates: ~0 rows (approximately)

-- Dumping structure for table magicai.user_credits
CREATE TABLE IF NOT EXISTS `user_credits` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `credits` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.user_credits: ~0 rows (approximately)

-- Dumping structure for table magicai.user_docs_favorite
CREATE TABLE IF NOT EXISTS `user_docs_favorite` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `user_openai_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_docs_favorite_user_id_foreign` (`user_id`),
  KEY `user_docs_favorite_user_openai_id_foreign` (`user_openai_id`),
  CONSTRAINT `user_docs_favorite_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_docs_favorite_user_openai_id_foreign` FOREIGN KEY (`user_openai_id`) REFERENCES `user_openai` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.user_docs_favorite: ~0 rows (approximately)

-- Dumping structure for table magicai.user_fall
CREATE TABLE IF NOT EXISTS `user_fall` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `prompt` text COLLATE utf8mb4_unicode_ci,
  `prompt_image_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `response_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_fall_user_id_foreign` (`user_id`),
  CONSTRAINT `user_fall_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.user_fall: ~0 rows (approximately)

-- Dumping structure for table magicai.user_favorites
CREATE TABLE IF NOT EXISTS `user_favorites` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `openai_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_favorites_user_id_foreign` (`user_id`),
  KEY `user_favorites_openai_id_foreign` (`openai_id`),
  CONSTRAINT `user_favorites_openai_id_foreign` FOREIGN KEY (`openai_id`) REFERENCES `openai` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_favorites_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.user_favorites: ~0 rows (approximately)

-- Dumping structure for table magicai.user_heygen
CREATE TABLE IF NOT EXISTS `user_heygen` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `avatar_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.user_heygen: ~0 rows (approximately)

-- Dumping structure for table magicai.user_integrations
CREATE TABLE IF NOT EXISTS `user_integrations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `integration_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `credentials` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.user_integrations: ~0 rows (approximately)

-- Dumping structure for table magicai.user_music
CREATE TABLE IF NOT EXISTS `user_music` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `music_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `audio_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_music_user_id_foreign` (`user_id`),
  CONSTRAINT `user_music_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.user_music: ~0 rows (approximately)

-- Dumping structure for table magicai.user_openai
CREATE TABLE IF NOT EXISTS `user_openai` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `is_demo` tinyint(1) DEFAULT '0',
  `request_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_advanced_image` tinyint(1) NOT NULL DEFAULT '0',
  `team_id` bigint DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `openai_id` bigint unsigned DEFAULT NULL,
  `input` text COLLATE utf8mb4_unicode_ci,
  `response` text COLLATE utf8mb4_unicode_ci,
  `output` text COLLATE utf8mb4_unicode_ci,
  `hash` text COLLATE utf8mb4_unicode_ci,
  `credits` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `words` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `storage` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `folder_id` bigint unsigned DEFAULT NULL,
  `payload` json DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'COMPLETED',
  `engine` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_openai_openai_id_foreign` (`openai_id`),
  KEY `user_openai_folder_id_foreign` (`folder_id`),
  KEY `user_openai_user_id_updated_at_index` (`user_id`,`updated_at` DESC),
  KEY `idx_user_id_updated_at` (`user_id`,`updated_at`),
  KEY `idx_user_openai_user_team` (`user_id`,`team_id`),
  CONSTRAINT `user_openai_folder_id_foreign` FOREIGN KEY (`folder_id`) REFERENCES `folders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_openai_openai_id_foreign` FOREIGN KEY (`openai_id`) REFERENCES `openai` (`id`) ON DELETE SET NULL,
  CONSTRAINT `user_openai_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.user_openai: ~0 rows (approximately)

-- Dumping structure for table magicai.user_openai_chat
CREATE TABLE IF NOT EXISTS `user_openai_chat` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `team_id` bigint DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `chat_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `chatbot_id` bigint DEFAULT NULL,
  `openai_chat_category_id` bigint unsigned DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_credits` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_words` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_chatbot` tinyint NOT NULL DEFAULT '0',
  `website_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `reference_url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `doc_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `thread_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_pinned` tinyint(1) NOT NULL DEFAULT '0',
  `openai_vector_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `openai_file_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_empty` tinyint(1) NOT NULL DEFAULT '1',
  `is_guest` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_openai_chat_user_id_foreign` (`user_id`),
  KEY `user_openai_chat_openai_chat_category_id_foreign` (`openai_chat_category_id`),
  KEY `user_openai_chat_is_empty_index` (`is_empty`),
  CONSTRAINT `user_openai_chat_openai_chat_category_id_foreign` FOREIGN KEY (`openai_chat_category_id`) REFERENCES `openai_chat_category` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_openai_chat_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.user_openai_chat: ~0 rows (approximately)
INSERT INTO `user_openai_chat` (`id`, `team_id`, `user_id`, `chat_type`, `chatbot_id`, `openai_chat_category_id`, `title`, `total_credits`, `total_words`, `created_at`, `updated_at`, `is_chatbot`, `website_url`, `reference_url`, `doc_name`, `thread_id`, `is_pinned`, `openai_vector_id`, `openai_file_id`, `is_empty`, `is_guest`) VALUES
	(2, NULL, 1, NULL, NULL, 1, 'Default AI Chat Bot Chat', '0', '0', '2026-07-24 11:26:57', '2026-07-24 11:26:57', 0, '', '', '', NULL, 0, NULL, NULL, 1, 0),
	(3, NULL, 1, NULL, NULL, 1, 'Default AI Chat Bot Chat', '0', '0', '2026-07-24 11:27:01', '2026-07-24 11:27:01', 0, '', '', '', NULL, 0, NULL, NULL, 1, 0);

-- Dumping structure for table magicai.user_openai_chat_messages
CREATE TABLE IF NOT EXISTS `user_openai_chat_messages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_openai_chat_id` bigint unsigned DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `input` text COLLATE utf8mb4_unicode_ci,
  `response` text COLLATE utf8mb4_unicode_ci,
  `output` text COLLATE utf8mb4_unicode_ci,
  `hash` text COLLATE utf8mb4_unicode_ci,
  `credits` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `words` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `images` text COLLATE utf8mb4_unicode_ci,
  `pdfName` text COLLATE utf8mb4_unicode_ci,
  `pdfPath` text COLLATE utf8mb4_unicode_ci,
  `outputImage` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `realtime` tinyint(1) NOT NULL DEFAULT '0',
  `is_chatbot` tinyint NOT NULL DEFAULT '0',
  `used_skills` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_openai_chat_messages_user_openai_chat_id_foreign` (`user_openai_chat_id`),
  KEY `user_openai_chat_messages_user_id_foreign` (`user_id`),
  CONSTRAINT `user_openai_chat_messages_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_openai_chat_messages_user_openai_chat_id_foreign` FOREIGN KEY (`user_openai_chat_id`) REFERENCES `user_openai_chat` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.user_openai_chat_messages: ~0 rows (approximately)
INSERT INTO `user_openai_chat_messages` (`id`, `user_openai_chat_id`, `user_id`, `input`, `response`, `output`, `hash`, `credits`, `words`, `created_at`, `updated_at`, `images`, `pdfName`, `pdfPath`, `outputImage`, `realtime`, `is_chatbot`, `used_skills`) VALUES
	(2, 2, 1, NULL, 'First Initiation', 'Hi! I am Default AI Chat Bot, and I\'m here to answer all your questions', 'U1Wg3rLg3gtTDw3Yww0P5nViQ09dBdeznrBh84wZV1Asxn2vK52l53JIw6QX1roREHMOXhOQSC98ev2XjIfRrMWVI7PnbZwryStGSsRvWGOEWghtGPSmmDO9yvUtxprvB4fLWNDHUyqjm0ghzgM8c8nYObENT8auuhHdxYJMRlj2QXrFqCVNeRd4V900j6loZ7hru7anpEAXShKvJhyrFm4yerwkWW0zvQecRkVJvd23LS7llhivj9oBJZnMxMR7', '0', '0', '2026-07-24 11:26:57', '2026-07-24 11:26:57', NULL, NULL, NULL, NULL, 0, 0, NULL),
	(3, 3, 1, NULL, 'First Initiation', 'Hi! I am Default AI Chat Bot, and I\'m here to answer all your questions', '8uMDv3x58gDRbV4l5FgspARuWl6FMpXBU7W25dIpIs218YJuyqqk18ygOPQn8Xn7gPjLWmIMR13oLSNB9Gqx13xXN2mbyhsaIRraZ8F8GKbwZtJYaFvUlyqAXzrjLLZangB0vDApQSpliUpfTH3l4CLg4vAJrxCC3QDJDNcavDHOukk0cKWNd1kjqCk97wYa1sSke2yNVVPm8xkPVCfK4G3h5ldt8fYbdfyA22NplXE4hPft4rAWH81gWuTudXHQ', '0', '0', '2026-07-24 11:27:01', '2026-07-24 11:27:01', NULL, NULL, NULL, NULL, 0, 0, NULL);

-- Dumping structure for table magicai.user_orders
CREATE TABLE IF NOT EXISTS `user_orders` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `plan_id` bigint unsigned DEFAULT NULL,
  `payment_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` double DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Waiting',
  `country` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'United States of America',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'subscription',
  `affiliate_earnings` double NOT NULL DEFAULT '0',
  `tax_rate` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_value` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payload` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_orders_plan_id_foreign` (`plan_id`),
  KEY `user_orders_user_id_foreign` (`user_id`),
  CONSTRAINT `user_orders_plan_id_foreign` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE SET NULL,
  CONSTRAINT `user_orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.user_orders: ~0 rows (approximately)

-- Dumping structure for table magicai.user_support
CREATE TABLE IF NOT EXISTS `user_support` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Waiting for answer',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `ticket_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `priority` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Low',
  `category` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_support_user_id_foreign` (`user_id`),
  CONSTRAINT `user_support_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.user_support: ~0 rows (approximately)

-- Dumping structure for table magicai.user_support_messages
CREATE TABLE IF NOT EXISTS `user_support_messages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_support_id` bigint unsigned DEFAULT NULL,
  `sender` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `attachment` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_support_messages_user_support_id_foreign` (`user_support_id`),
  CONSTRAINT `user_support_messages_user_support_id_foreign` FOREIGN KEY (`user_support_id`) REFERENCES `user_support` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.user_support_messages: ~0 rows (approximately)

-- Dumping structure for table magicai.user_synthesia
CREATE TABLE IF NOT EXISTS `user_synthesia` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `avatar_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.user_synthesia: ~0 rows (approximately)

-- Dumping structure for table magicai.user_usage_credits
CREATE TABLE IF NOT EXISTS `user_usage_credits` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `model_key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `credit` int NOT NULL,
  `unit_price` decimal(8,2) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_usage_credits_user_id_foreign` (`user_id`),
  CONSTRAINT `user_usage_credits_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.user_usage_credits: ~0 rows (approximately)

-- Dumping structure for table magicai.webhookhistory
CREATE TABLE IF NOT EXISTS `webhookhistory` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `gatewaycode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `webhook_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `create_time` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resource_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `summary` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resource_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resource_state` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_payment` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount_total` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount_currency` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `incoming_json` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.webhookhistory: ~0 rows (approximately)

-- Dumping structure for table magicai.xero_tokens
CREATE TABLE IF NOT EXISTS `xero_tokens` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `id_token` text COLLATE utf8mb4_unicode_ci,
  `access_token` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_in` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refresh_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `auth_event_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tenant_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tenant_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tenant_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_date_utc` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_date_utc` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table magicai.xero_tokens: ~0 rows (approximately)

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
